import {readFile,writeFile,mkdir,readdir,lstat,realpath,rename,unlink,cp} from 'node:fs/promises';
import {resolve,join,dirname,relative,sep,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {validateManifest} from './package.mjs';
const TEXT_LIMIT=64*1024;
const blocked=new Set(['.git','.nelkdev','node_modules','dist','build']);
const editable=new Set(['.js','.ts','.json','.txt','.md','.svg','.css','.html']);
const packaged=new Set(['.js','.ts','.json','.txt','.svg','.png','.ttf']);
const hash=b=>createHash('sha256').update(b).digest('hex');
const ensure=(condition,message)=>{if(!condition)throw Error(message);};
const examples=join(dirname(fileURLToPath(import.meta.url)),'examples');
/** Trusted editor operations. Never reachable from the module's capability broker. */
export class DevWorkspace {
 constructor(engine){this.engine=engine;this.projects=new Map();this.revision=0;}
 project(id){const p=this.projects.get(id);ensure(p,'unknown-project');return p;}
 async open(path){
  const root=await realpath(resolve(path));ensure((await lstat(root)).isDirectory(),'project-not-directory');
  const old=[...this.projects.values()].find(p=>p.path===root);if(old)return old;
  ensure(this.projects.size<12,'maximum-twelve-projects');const p={id:hash(root).slice(0,24),path:root,name:root.split(sep).at(-1),moduleId:null,error:null};
  this.projects.set(p.id,p);await this.sync(p.id);return p;
 }
 async sync(id){
  const p=this.project(id);
  try{
   const m=JSON.parse(await readFile(join(p.path,'manifest.json'),'utf8'));p.moduleId=m.id;p.name=m.name??p.name;
   if(this.engine.paths.includes(p.path)){ensure(await this.engine.reload(),this.engine.message??'compile-failed');}
   else await this.engine.add(p.path);
   p.error=this.engine.errors.get(p.moduleId)??null;
  }catch(e){p.error=e.message;this.engine.log('build','editor',e.message);}
  this.revision++;this.engine.revision++;return {...p};
 }
 state(){return [...this.projects.values()].map(p=>({...p,error:p.error??this.engine.errors.get(p.moduleId)??null}));}
 async path(id,name,{missing=false}={}){
  ensure(typeof name==='string'&&name.length<=240&&!name.includes('\\')&&!name.includes(':')&&!name.startsWith('/'),'invalid-editor-path');
  const parts=name.split('/');ensure(parts.every(p=>p&&p!=='.'&&p!=='..'&&!blocked.has(p)&&(!p.startsWith('.')||p==='.gitignore')&&!/\.(pem|key|nelkmod)$/i.test(p)),'protected-editor-path');
  const root=this.project(id).path;const target=resolve(root,...parts);ensure(target.startsWith(root+sep),'outside-project');
  let current=root;for(const part of parts){current=join(current,part);try{ensure(!(await lstat(current)).isSymbolicLink(),'editor-symlink');}catch(e){if(missing&&e.code==='ENOENT')break;throw e;}}
  return target;
 }
 async tree(id){
  const root=this.project(id).path;const entries=[];
  const walk=async(dir,depth)=>{
   ensure(depth<=12&&entries.length<1000,'project-tree-limit');
   const list=(await readdir(dir,{withFileTypes:true})).sort((a,b)=>Number(b.isDirectory())-Number(a.isDirectory())||a.name.localeCompare(b.name));
   for(const item of list){if(blocked.has(item.name)||item.name.startsWith('.')&&item.name!=='.gitignore'||/\.(pem|key|nelkmod)$/i.test(item.name))continue;
    ensure(entries.length<1000,'project-tree-limit');const file=join(dir,item.name),name=relative(root,file).split(sep).join('/');
    if(item.isSymbolicLink()){entries.push({path:name,kind:'blocked',size:0});continue;}
    const stat=await lstat(file);entries.push({path:name,kind:item.isDirectory()?'folder':editable.has(extname(item.name))||item.name==='.gitignore'?'text':'binary',size:stat.size});
    if(item.isDirectory())await walk(file,depth+1);
   }
  };await walk(root,0);return entries;
 }
 async read(id,name){
  const file=await this.path(id,name);const stat=await lstat(file);
  ensure(stat.isFile()&&(editable.has(extname(file))||name==='.gitignore'),'file-not-editable');ensure(stat.size<=TEXT_LIMIT,'editor-text-limit-64-kib');
  const bytes=await readFile(file);const content=new TextDecoder('utf-8',{fatal:true}).decode(bytes);return {path:name,content,revision:hash(bytes)};
 }
 async atomic(file,content){
  const temp=join(dirname(file),'.sdk-save-'+randomUUID()+'.tmp');
  try{await writeFile(temp,content,{flag:'wx'});await rename(temp,file);}finally{await unlink(temp).catch(()=>{});}
 }
 async save(id,name,content,revision){
  ensure(typeof content==='string'&&Buffer.byteLength(content)<=TEXT_LIMIT,'editor-text-limit-64-kib');ensure(typeof revision==='string','missing-file-revision');
  const old=await this.read(id,name);ensure(old.revision===revision,'file-changed-externally: recarga el archivo antes de guardar');
  const file=await this.path(id,name);await this.atomic(file,content);await this.sync(id);return this.read(id,name);
 }
 async manifestUpdate(id,name,declare){
  if(!declare||!packaged.has(extname(name)))return null;
  const current=await this.read(id,'manifest.json');const m=JSON.parse(current.content);
  ensure(!m.files.includes(name),'file-already-declared');m.files.push(name);
  validateManifest({...m,entry:m.entry.replace(/\.ts$/,'.js'),files:m.files.map(f=>f.replace(/\.ts$/,'.js'))});
  return {content:JSON.stringify(m,null,2)+'\n',revision:current.revision};
 }
 async createFile(id,name,content='',declare=true){
  ensure(name!== 'manifest.json','manifest-already-exists');ensure(editable.has(extname(name)),'unsupported-new-text-file');ensure(typeof content==='string'&&Buffer.byteLength(content)<=TEXT_LIMIT,'editor-text-limit-64-kib');
  const file=await this.path(id,name,{missing:true});const update=await this.manifestUpdate(id,name,declare);
  await writeFile(file,content,{flag:'wx'});
  if(update)await this.save(id,'manifest.json',update.content,update.revision);else await this.sync(id);
  return this.read(id,name);
 }
 async createFolder(id,name){await mkdir(await this.path(id,name,{missing:true}),{recursive:false});this.revision++;this.engine.revision++;return true;}
 async importAsset(id,source,name,declare=true){
  const original=resolve(source);ensure(['.png','.ttf'].includes(extname(original).toLowerCase())&&extname(name).toLowerCase()===extname(original).toLowerCase(),'unsupported-import-asset');
  const stat=await lstat(original);ensure(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=8*1024*1024,'invalid-import-asset');
  const dest=await this.path(id,name,{missing:true}),update=await this.manifestUpdate(id,name,declare);
  const bytes=await readFile(original);await writeFile(dest,bytes,{flag:'wx'});
  if(update)await this.save(id,'manifest.json',update.content,update.revision);else await this.sync(id);
  return {path:name,size:bytes.length};
 }
 async createProject({parent,folder,id,name,template='basic'}){
  ensure(/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(folder),'invalid-project-folder');
  ensure(/^[a-z][a-z0-9]*(\.[a-z][a-z0-9-]*)+$/.test(id)&&id.length<=128,'invalid-module-id');
  ensure(typeof name==='string'&&name.trim()&&name.length<=256,'invalid-module-name');ensure(['basic','collections','skin','control-editor','basics','friends'].includes(template),'unknown-template');
  ensure(this.projects.size<12,'maximum-twelve-projects');
  const dir=join(await realpath(resolve(parent)),folder);await mkdir(dir,{recursive:false});
  if(template==='basic'){
   await mkdir(join(dir,'src'));await mkdir(join(dir,'assets'));
   await writeFile(join(dir,'src/index.js'),"export function createModule(host) {\n  return {\n    async activate() {},\n    async deactivate() {},\n    async contributions(context) {\n      if (context.surface !== 'settings') return [];\n      return [{ moduleId: "+JSON.stringify(id)+", id: 'hello', slot: 'SETTINGS_SECTION',\n        label: "+JSON.stringify(name)+", actionId: 'open', icon: 'standard:settings' }];\n    },\n    async dispatch(action, payload, context) {\n      if (action !== 'open') throw Error('unknown-action');\n      return { kind: 'panel', title: "+JSON.stringify(name)+", fields: [], rows: [], actions: [] };\n    }\n  };\n}\n",{flag:'wx'});
   await writeFile(join(dir,'manifest.json'),JSON.stringify({formatVersion:1,id,name,version:'0.1.0',sdkVersion:'0.2.0',platforms:['android'],entry:'src/index.js',bundledByDefault:false,dependencies:[],capabilities:[],files:['src/index.js']},null,2)+'\n',{flag:'wx'});
  }else{
   await cp(join(examples,template),dir,{recursive:true});
   const file=join(dir,'manifest.json');const m=JSON.parse(await readFile(file,'utf8')),old=m.id;m.id=id;m.name=name;m.bundledByDefault=false;
   await writeFile(file,JSON.stringify(m,null,2)+'\n');
   for(const f of m.files.filter(f=>f.endsWith('.js'))){const source=join(dir,f);await writeFile(source,(await readFile(source,'utf8')).replaceAll(old,id));}
  }
  await writeFile(join(dir,'.gitignore'),'node_modules/\ndist/\n.nelkdev/\n*.pem\n*.nelkmod\n',{flag:'wx'});
  return this.open(dir);
 }
}
