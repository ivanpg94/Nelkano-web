import {numberSize,encodeNumber,decodeNumber} from './game-mod-numbers.mjs';
import {randomUUID} from 'node:crypto';
const need=(v,message)=>{if(!v)throw Error(message)};
const keys=(v,required,optional=[])=>need(v&&typeof v==='object'&&!Array.isArray(v)&&required.every(k=>Object.hasOwn(v,k))&&Object.keys(v).every(k=>required.includes(k)||optional.includes(k)),'invalid-game-mod-object');
const integer=(v,name)=>{need(Number.isSafeInteger(v)&&v>=0,'invalid-memory-number: '+name);return v};
export const SEARCH_LIMITS={maxSearches:4,maxScanBytes:262144,maxSearchBytes:1048576,maxSearchResults:128};
/** Shared by the signed-module broker and the authenticated Studio inspector. Synthetic data only. */
export class GameModSearches {
 constructor(read,descriptor){this.read=read;this.descriptor=descriptor;this.searches=new Map()}
 target(value,mode,type,endian){if(['equal','notEqual'].includes(mode)){need(Object.hasOwn(value,'value'),'memory-search-value-required');return decodeNumber(encodeNumber(value.value,type,endian),type,endian)}need(!Object.hasOwn(value,'value'),'memory-search-unexpected-value');return null}
 snapshot(ref,spec){const bytes=Buffer.alloc(spec.length);for(let offset=0;offset<spec.length;offset+=32768){const length=Math.min(32768,spec.length-offset);this.read(ref,{ranges:[{space:spec.space,address:spec.address+offset,length}]}).ranges.forEach(row=>Buffer.from(row.data,'base64').copy(bytes,offset))}return bytes}
 summary(id,s){return {id,matchCount:s.candidates.length,scannedBytes:s.length,revision:s.revision,space:s.space,address:s.address,length:s.length,type:s.type,endian:s.endian,alignment:s.alignment,paged:true}}
 owned(owner,id){const s=this.searches.get(id);need(s&&s.owner===owner,'memory-search-unavailable');return s}
 call(owner,ref,method,value){
  if(method==='gameMod.searchStart'){
   keys(value,['space','address','length','type','mode'],['endian','alignment','value']);need(this.searches.size<4,'memory-search-count-limit');
   const address=integer(value.address,'address'),length=integer(value.length,'length'),size=numberSize(value.type);
   need(length>=size&&length<=262144,'memory-search-size-limit');need([...this.searches.values()].reduce((n,s)=>n+s.length,0)+length<=1048576,'memory-search-byte-limit');
   const d=this.descriptor(ref),space=d.spaces.find(s=>s.id===value.space);need(d.memoryRead&&space,'memory-search-unavailable');
   need(space.regions.some(r=>r.readable&&address>=r.start&&address+length<=r.start+r.length),'memory-region-denied');
   const endian=value.endian??space.byteOrder,alignment=value.alignment??size;need([1,2,4,8].includes(alignment),'memory-search-alignment');need(['equal','unknown'].includes(value.mode),'memory-search-mode');
   const target=this.target(value,value.mode,value.type,endian);decodeNumber(Buffer.alloc(size),value.type,endian);
   const spec={owner,space:value.space,address,length,type:value.type,endian,alignment,revision:1,candidates:[]},bytes=this.snapshot(ref,spec);
   for(let at=0;at+size<=length;at+=alignment)if(value.mode==='unknown'||decodeNumber(bytes.subarray(at,at+size),value.type,endian)===target)spec.candidates.push(at);
   spec.bytes=bytes;const id=randomUUID();this.searches.set(id,spec);return this.summary(id,spec);
  }
  if(method==='gameMod.searchClose'){keys(value,['id']);const s=this.searches.get(value.id);if(s?.owner!==owner)return false;this.searches.delete(value.id);return true}
  if(method==='gameMod.searchRefine'){
   keys(value,['id','mode'],['value']);const s=this.owned(owner,value.id),mode=value.mode;need(['equal','notEqual','changed','unchanged','increased','decreased'].includes(mode),'memory-search-mode');
   const target=this.target(value,mode,s.type,s.endian),bytes=this.snapshot(ref,s),size=numberSize(s.type);
   const candidates=s.candidates.filter(at=>{const next=bytes.subarray(at,at+size),before=s.bytes.subarray(at,at+size);
    if(mode==='changed'||mode==='unchanged')return mode==='changed'?!next.equals(before):next.equals(before);
    const current=decodeNumber(next,s.type,s.endian);if(mode==='equal')return current===target;if(mode==='notEqual')return current!==target;
    const old=decodeNumber(before,s.type,s.endian);return current!==null&&old!==null&&(mode==='increased'?current>old:current<old);
   });s.bytes=bytes;s.candidates=candidates;s.revision++;return this.summary(value.id,s);
  }
  if(method==='gameMod.searchRead'){
   keys(value,['id'],['offset','limit']);const s=this.owned(owner,value.id),offset=integer(value.offset??0,'offset'),limit=integer(value.limit??128,'limit'),size=numberSize(s.type);
   need(offset<=s.candidates.length&&limit>=1&&limit<=128,'memory-search-page');
   return {...this.summary(value.id,s),offset,hasMore:offset+limit<s.candidates.length,results:s.candidates.slice(offset,offset+limit).map(at=>({space:s.space,address:s.address+at,type:s.type,endian:s.endian,value:decodeNumber(s.bytes.subarray(at,at+size),s.type,s.endian),data:s.bytes.subarray(at,at+size).toString('base64')}))};
  }
  throw Error('unknown-memory-search-operation');
 }
 release(owner){for(const[id,s]of this.searches)if(s.owner===owner)this.searches.delete(id)}
 clear(){this.searches.clear()}
}
