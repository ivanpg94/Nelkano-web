import {createHash} from 'node:crypto';
const need=(v,m)=>{if(!v)throw Error(m);};const copy=v=>JSON.parse(JSON.stringify(v));
const hash=v=>createHash('sha256').update(v).digest('hex');
export class AccountFixtures{
 constructor(){this.users=[{uid:1,name:'Jugador de prueba',email:'demo@nelkano.test',password:hash('Nelkano123'),displayName:'Jugador de prueba',statusText:'Probando Nelkano',avatarColor:'#a414ff'},{uid:2,name:'Ana',email:'ana@nelkano.test',displayName:'Ana',statusText:'Jugando a Pokémon',avatarColor:'#38bdf8'},{uid:3,name:'Luis',email:'luis@nelkano.test',displayName:'Luis',statusText:'Disponible',avatarColor:'#22c55e'},{uid:4,name:'Marta',email:'marta@nelkano.test',displayName:'Marta',statusText:'',avatarColor:'#f59e0b'}];this.current=null;this.links=new Map([[1,{friends:[2],incoming:[3],outgoing:[]}]]);this.resources=new Map();}
 snapshot(){const u=this.current;return u?{uid:u.uid,signedIn:true,name:u.displayName,email:u.email,friends:true,role:'Usuario de prueba'}:{uid:0,signedIn:false};}
 linksFor(uid){if(!this.links.has(uid))this.links.set(uid,{friends:[],incoming:[],outgoing:[]});return this.links.get(uid);}
 user(uid){const u=this.users.find(x=>x.uid===uid);need(u,'unknown-user');return {uid:u.uid,friendshipId:u.uid,name:u.name,email:u.email,displayName:u.displayName,statusText:u.statusText,avatarColor:u.avatarColor,avatarUrl:'',initial:u.displayName.slice(0,1)};}
 call(owner,method,args){
  if(method==='account.snapshot')return this.snapshot();
  if(method==='account.login'){const v=args[0];need(typeof v?.email==='string'&&typeof v?.password==='string','invalid-credentials');const u=this.users.find(x=>x.email.toLowerCase()===v.email.trim().toLowerCase()&&x.password===hash(v.password));need(u,'invalid_credentials');this.current=u;return this.snapshot();}
  if(method==='account.register'){const v=args[0];need(v?.name?.length>=2&&v?.password?.length>=8&&v.password===v.password_confirm&&v.terms===true,'invalid-registration');need(!this.users.some(x=>x.email.toLowerCase()===v.email.toLowerCase()),'Este correo ya tiene una cuenta.');this.users.push({uid:Math.max(...this.users.map(x=>x.uid))+1,name:v.name,email:v.email,password:hash(v.password),displayName:v.name,statusText:'',avatarColor:'#a414ff'});return {ok:true,message:'Cuenta creada y activada en la simulación; no se envía ningún correo.'};}
  if(method==='account.logout'){this.current=null;this.resources.clear();return true;}
  if(method==='resources.pickImage'){need(this.current,'login-required');const id='simulation-'+owner;const preview='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==';this.resources.set(id,{owner,preview});return {resourceId:id,preview};}
  need(this.current,'login-required');const s=this.current;
  if(method==='network.image')return '';
  need(method==='network.request','unknown-account-operation');const r=args[0];need(r?.accountUid===s.uid,'stale-account');const url=new URL(r.path,'https://simulation.invalid');need(url.origin==='https://simulation.invalid','endpoint-not-allowed');const path=url.pathname,body=r.body??{};const links=this.linksFor(s.uid);
  if(r.method==='GET'&&path==='/api/nelkano/friends')return {status:200,body:Object.fromEntries(Object.entries(links).map(([k,v])=>[k,v.map(x=>this.user(x))]))};
  if(r.method==='GET'&&path==='/api/nelkano/friends/search'){const q=(url.searchParams.get('q')||'').toLowerCase();return {status:200,body:{users:this.users.filter(u=>u.uid!==s.uid&&(u.name.toLowerCase().includes(q)||u.email.toLowerCase().includes(q))).map(u=>this.user(u.uid))}};}
  if(r.method==='GET'&&path==='/api/nelkano/profile')return {status:200,body:{profile:this.user(s.uid)}};
  if(r.method==='POST'&&path==='/api/nelkano/profile'){need(body.displayName?.length>=2&&['#a414ff','#38bdf8','#22c55e','#f59e0b','#f43f5e'].includes(body.avatarColor),'invalid-profile');if(body.avatarResource)need(this.resources.get(body.avatarResource)?.owner===owner,'resource-owner-mismatch');s.displayName=body.displayName;s.statusText=body.statusText;s.avatarColor=body.avatarColor;return {status:200,body:{profile:this.user(s.uid)}};}
  if(r.method==='POST'&&path.startsWith('/api/nelkano/friends/')){const op=path.split('/').at(-1),uid=body.uid;need(uid!==s.uid&&this.users.some(x=>x.uid===uid),'unknown-user');if(op==='request'){need(!Object.values(links).some(a=>a.includes(uid)),'Ya hay una amistad o solicitud.');links.outgoing.push(uid);}else if(op==='accept'){need(links.incoming.includes(uid),'unknown-request');links.incoming=links.incoming.filter(x=>x!==uid);links.friends.push(uid);}else if(op==='reject'){links.incoming=links.incoming.filter(x=>x!==uid);links.outgoing=links.outgoing.filter(x=>x!==uid);}else if(op==='remove'){need(links.friends.includes(uid),'unknown-friend');links.friends=links.friends.filter(x=>x!==uid);}else throw Error('endpoint-not-allowed');return {status:200,body:{ok:true}};}
  throw Error('endpoint-not-allowed');
 }
}
