const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
export function base64(bytes){let s='';for(let i=0;i<bytes.length;i+=3){const n=(bytes[i]<<16)|((bytes[i+1]??0)<<8)|(bytes[i+2]??0);s+=alphabet[n>>>18]+alphabet[(n>>>12)&63]+(i+1<bytes.length?alphabet[(n>>>6)&63]:'=')+(i+2<bytes.length?alphabet[n&63]:'=')}return s}
export function unbase64(s){if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)||s.length%4)throw Error('Datos binarios inválidos');const b=[];for(let i=0;i<s.length;i+=4){const n=(alphabet.indexOf(s[i])<<18)|(alphabet.indexOf(s[i+1])<<12)|((alphabet.indexOf(s[i+2])&63)<<6)|(alphabet.indexOf(s[i+3])&63);b.push((n>>>16)&255);if(s[i+2]!=='=')b.push((n>>>8)&255);if(s[i+3]!=='=')b.push(n&255)}return Uint8Array.from(b)}
export const utf8=s=>Uint8Array.from(unescape(encodeURIComponent(s)),c=>c.charCodeAt(0));
export const text=b=>decodeURIComponent(escape(Array.from(b,c=>String.fromCharCode(c)).join('')));
export const u16=(b,o)=>b[o]|(b[o+1]<<8);
export const u32=(b,o)=>(b[o]|(b[o+1]<<8)|(b[o+2]<<16)|(b[o+3]<<24))>>>0;
export function put16(b,o,v){b[o]=v&255;b[o+1]=(v>>>8)&255}
export function put32(b,o,v){for(let i=0;i<4;i++)b[o+i]=(v>>>(8*i))&255}
