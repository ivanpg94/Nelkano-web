# GBA Online

Módulo opcional `nelkano.gba-online`, versión 0.1.0, SDK 0.2.0. Requiere Amigos. No viene dentro de la APK.

Conecta dos amigos con los papeles Host e Invitado. Mantiene la sesión, recoge mensajes y ofrece una base común para los módulos de cada juego. No interpreta la memoria Pokémon ni sincroniza el emulador entero.

## Usarlo

Importa el paquete desde Ajustes → Módulos. Instala también un adaptador de juego, por ejemplo Pokémon Online. Abre el juego y entra en Ajustes de emulación → CONEXIONES → GBA Online. Elige al amigo y el papel. El otro jugador debe elegir el papel contrario.

## Crear otro online

Declara `modules.hooks` y consume `game-adapters`, `sessions` y `events` de este módulo, versión 1.0.0. Publica una aportación a game-adapters y atiende estas operaciones en onHook:

- identify: recibe sesión, gameId y systemId. Devuelve compatible y compatibilityKey; transportSystem es opcional.
- capture: devuelve valid y los datos que deben conocer los otros jugadores.
- render: recibe sesión y peers. Tu módulo decide qué dibujar o cambiar.
- messages: recibe sesión y packets para los mensajes de juego.

sessions permite snapshot, connect, disconnect y send. connect recibe friendUid y role. send recibe type, payload y channel opcional; el proveedor añade sesión, emisor y secuencia. Un canal sustituye mensajes pendientes anteriores de ese mismo canal.

events avisa de conexión, desconexión, errores, mensajes y cambios de presencia. Guarda los datos del aviso; responde en una llamada posterior para evitar llamadas circulares.

## Desarrollo

`npx nelkmod example gba-online mi-gba-online` copia las fuentes. Abre Amigos, GBA Online y tu adaptador juntos en Studio. La red de Studio es simulada. Para la red real exporta e importa en la app.

El host conserva tokens, verifica los permisos de la cuenta y limita colas y tamaños. Solo se conecta a los endpoints de juego de nelkano.com. Las claves de firma quedan fuera del repositorio. Receta: src/nelkano/sdk/tooling/package-online.mjs.

La presencia se consulta con un intervalo solicitado de 100 ms. Subidas y recepción son independientes. Los cortes temporales reintentan; una sesión cerrada o permiso retirado termina la conexión. snapshot incluye sentPackets, receivedPackets, retryCount, lastSentAt y lastReceivedAt para diagnosticarla.
