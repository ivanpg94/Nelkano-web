// Physical controller targets; shared by the module and SDK templates.
export const systems=[
  {
    "key": "GAME_BOY",
    "label": "Game Boy / Game Boy Color",
    "shortLabel": "GB/GBC",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "GBA",
    "label": "Game Boy Advance",
    "shortLabel": "GBA",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "NDS",
    "label": "Nintendo DS",
    "shortLabel": "NDS",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "N3DS",
    "label": "N3DS",
    "shortLabel": "3DS",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "NES",
    "label": "NES / Famicom Disk System",
    "shortLabel": "NES/FDS",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "SNES",
    "label": "Super Nintendo",
    "shortLabel": "SNES",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "MEGADRIVE",
    "label": "Sega Mega Drive",
    "shortLabel": "MD",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 8,
        "label": "C",
        "icon": "C"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "MASTER_SYSTEM",
    "label": "Sega Master System",
    "shortLabel": "SMS",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 0,
        "label": "1",
        "icon": "1"
      },
      {
        "button": 1,
        "label": "2",
        "icon": "2"
      },
      {
        "button": 3,
        "label": "PAUSE",
        "icon": "PAUSE"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "GAME_GEAR",
    "label": "Sega Game Gear",
    "shortLabel": "GG",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 0,
        "label": "1",
        "icon": "1"
      },
      {
        "button": 1,
        "label": "2",
        "icon": "2"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "NEO_GEO_POCKET",
    "label": "Neo Geo Pocket / Color",
    "shortLabel": "NGP",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 3,
        "label": "OPTION",
        "icon": "OPTION"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "PS1",
    "label": "PlayStation",
    "shortLabel": "PS1",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 13,
        "label": "L2",
        "icon": "L2"
      },
      {
        "button": 9,
        "label": "L1",
        "icon": "L1"
      },
      {
        "button": 8,
        "label": "R1",
        "icon": "R1"
      },
      {
        "button": 14,
        "label": "R2",
        "icon": "R2"
      },
      {
        "button": 12,
        "label": "TRIANGLE",
        "icon": "TRIANGLE"
      },
      {
        "button": 11,
        "label": "SQUARE",
        "icon": "SQUARE"
      },
      {
        "button": 1,
        "label": "CIRCLE",
        "icon": "CIRCLE"
      },
      {
        "button": 0,
        "label": "CROSS",
        "icon": "CROSS"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      },
      {
        "button": 15,
        "label": "L3",
        "icon": "L3"
      },
      {
        "button": 17,
        "label": "R3",
        "icon": "R3"
      }
    ]
  },
  {
    "key": "CHIP8",
    "label": "CHIP-8",
    "shortLabel": "CHIP-8",
    "targets": [
      {
        "button": 17,
        "label": "1",
        "icon": "1"
      },
      {
        "button": 18,
        "label": "2",
        "icon": "2"
      },
      {
        "button": 19,
        "label": "3",
        "icon": "3"
      },
      {
        "button": 28,
        "label": "C",
        "icon": "C"
      },
      {
        "button": 20,
        "label": "4",
        "icon": "4"
      },
      {
        "button": 21,
        "label": "5",
        "icon": "5"
      },
      {
        "button": 22,
        "label": "6",
        "icon": "6"
      },
      {
        "button": 29,
        "label": "D",
        "icon": "D"
      },
      {
        "button": 23,
        "label": "7",
        "icon": "7"
      },
      {
        "button": 24,
        "label": "8",
        "icon": "8"
      },
      {
        "button": 25,
        "label": "9",
        "icon": "9"
      },
      {
        "button": 30,
        "label": "E",
        "icon": "E"
      },
      {
        "button": 26,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 16,
        "label": "0",
        "icon": "0"
      },
      {
        "button": 27,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 31,
        "label": "F",
        "icon": "F"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "RPG_MAKER",
    "label": "RPG Maker",
    "shortLabel": "RPG Maker",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      }
    ]
  },
  {
    "key": "SWITCH",
    "label": "Switch",
    "shortLabel": "Switch",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      },
      {
        "button": 13,
        "label": "ZL",
        "icon": "L2"
      },
      {
        "button": 14,
        "label": "ZR",
        "icon": "R2"
      }
    ]
  },
  {
    "key": "PSP",
    "label": "PSP",
    "shortLabel": "PSP",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      },
      {
        "button": 18,
        "label": "Stick arriba",
        "icon": "DP"
      },
      {
        "button": 19,
        "label": "Stick abajo",
        "icon": "DP"
      },
      {
        "button": 20,
        "label": "Stick izquierda",
        "icon": "DP"
      },
      {
        "button": 21,
        "label": "Stick derecha",
        "icon": "DP"
      }
    ]
  },
  {
    "key": "GAMECUBE",
    "label": "GameCube",
    "shortLabel": "GameCube",
    "targets": [
      {
        "button": 6,
        "label": "Arriba",
        "icon": "DP"
      },
      {
        "button": 7,
        "label": "Abajo",
        "icon": "DP"
      },
      {
        "button": 5,
        "label": "Izquierda",
        "icon": "DP"
      },
      {
        "button": 4,
        "label": "Derecha",
        "icon": "DP"
      },
      {
        "button": 9,
        "label": "L",
        "icon": "L"
      },
      {
        "button": 8,
        "label": "R",
        "icon": "R"
      },
      {
        "button": 11,
        "label": "X",
        "icon": "X"
      },
      {
        "button": 12,
        "label": "Y",
        "icon": "Y"
      },
      {
        "button": 0,
        "label": "A",
        "icon": "A"
      },
      {
        "button": 1,
        "label": "B",
        "icon": "B"
      },
      {
        "button": 2,
        "label": "SELECT",
        "icon": "SELECT"
      },
      {
        "button": 3,
        "label": "START",
        "icon": "START"
      },
      {
        "button": 10,
        "label": "Pantalla completa",
        "icon": "FS"
      },
      {
        "button": 18,
        "label": "Stick arriba",
        "icon": "DP"
      },
      {
        "button": 19,
        "label": "Stick abajo",
        "icon": "DP"
      },
      {
        "button": 20,
        "label": "Stick izquierda",
        "icon": "DP"
      },
      {
        "button": 21,
        "label": "Stick derecha",
        "icon": "DP"
      },
      {
        "button": 22,
        "label": "C-stick arriba",
        "icon": "DP"
      },
      {
        "button": 23,
        "label": "C-stick abajo",
        "icon": "DP"
      },
      {
        "button": 24,
        "label": "C-stick izquierda",
        "icon": "DP"
      },
      {
        "button": 25,
        "label": "C-stick derecha",
        "icon": "DP"
      }
    ]
  }
];
export function systemFor(key){let normalized=typeof key==='string'?key.trim().toUpperCase():'';if(normalized==='FAMICOM')normalized='NES';return systems.find(s=>s.key===normalized)??systems[0];}
