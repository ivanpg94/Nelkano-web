import {createModule as createLegacyModule} from './index.js';
export const moduleId='nelkano.basics';
/** The module describes flows; Android renders shared, themed primitives. */
export function createModule(host){
 const module=createLegacyModule(host);let active=false;
 const action=(actionId,label,payload={},confirm=false)=>({actionId,label,payload,confirm});
 const form=(title,fields,actions,rows=[])=>({kind:'panel',title,fields,rows,actions});
 async function selector(mode,context,payload={}){
  const model=await module.dispatch(mode==='remove'?'open-remove':'open',payload,context);
  const ids=payload.gameIds??model.selection;
  const operation=mode==='add'?'add':mode==='remove'?'remove':'filter';
  const choices=mode==='remove'?model.choices:mode==='add'?model.choices.filter(c=>c.id!==null):model.choices;
  return form(mode==='add'?'Añadir a colección':mode==='remove'?'Quitar de colección':'Colecciones',[],
   mode==='remove'?[]:[action('new','Crear colección',{gameIds:ids})],
   choices.map(c=>({id:c.id??'all',label:c.label,selected:mode==='filter'&&c.id===model.filterId,
    actions:[action(operation,c.label,{collectionId:c.id,...(operation==='filter'?{}:{gameIds:ids})})]})));
 }
 async function manage(context){
  const model=await module.dispatch('open',{},context);
  return form('Gestionar colecciones',[],[action('new','Crear colección'),action('export','Exportar colecciones'),action('import-backup','Importar colecciones')],
   model.collections.map(c=>({id:c.id,label:c.name,actions:c.name.toLowerCase()==='favoritos'?[]:[action('edit','Renombrar',{collectionId:c.id,name:c.name}),action('delete','Eliminar colección',{collectionId:c.id},true)]})));
 }
 return {activate:async()=>{await module.activate();await module.dispatch('ensure-default');active=true;},deactivate:async()=>{active=false;await module.deactivate();},
  contributions:async context=>{
   if(!active)return [];
   const items=(await module.contributions(context)).filter(c=>c.slot!=='GAME_LAUNCH_ACTION'&&(c.slot!=='LIBRARY_ACTION'||c.id==='filter-library')&&(c.slot!=='SAVE_ACTION'||!context.saveId)).map(c=>({...c,...(c.slot==='SETTINGS_SECTION'?{section:'Biblioteca'}:{}),label:c.slot==='LIBRARY_ACTION'?'Colecciones':c.label,icon:'assets/collection.png',description:'Organizar juegos y filtrar por colección',payload:c.gameIds?{gameIds:c.gameIds}:{}}));
   if(context.surface==='game'&&context.gameId){
    const state=await module.dispatch('export');const favorite=state.collections.find(c=>c.name.toLowerCase()==='favoritos');const checked=favorite?.gameIds.includes(context.gameId)??false;
    items.push({moduleId,id:'favorite-game',slot:'GAME_HEADER_ACTION',label:checked?'Quitar de favoritos':'Añadir a favoritos',actionId:'set-favorite',kind:'toggle',checked,icon:checked?'standard:favorite-filled':'standard:favorite-outline',payload:{gameIds:[context.gameId]}});
   }
   if(context.surface==='home'){
    const state=await module.dispatch('export');const favorite=state.collections.find(c=>c.name.toLowerCase()==='favoritos');
    if(favorite)items.push({moduleId,id:'favorites',slot:'HOME_SECTION',label:'Favoritos',actionId:'filter',icon:'assets/collection.png',payload:{collectionId:favorite.id,section:{kind:'game-carousel',gameIds:favorite.gameIds,emptyLabel:'Sin favoritos'}}});
   }
   return items;
  },
  onEvent:async event=>{
   if(event.type==='library-imported'||event.type==='filters-reset'){await module.dispatch('filter',{collectionId:null});return null;}
   if(event.type!=='data-changed')return null;
   // All means no restriction, never a cached whitelist of the current library.
   if((await module.dispatch('export')).filterId===null)return {filters:{}};
   return {filters:{games:(await module.dispatch('games')).map(g=>g.id),saves:(await module.dispatch('saves')).map(s=>s.id)}};
  },
  dispatch:async(operation,payload={},context={})=>{
   if(operation==='set-favorite'){await module.dispatch(operation,payload,context);return {kind:'action-result'};}
   if(operation==='open')return context.surface==='settings'?manage(context):selector('filter',context,payload);
   if(operation==='open-add'||operation==='open-remove')return selector(operation==='open-add'?'add':'remove',context,payload);
   if(operation==='new'||operation==='edit')return form(operation==='new'?'Crear colección':'Renombrar colección',
    [{id:'name',kind:'text',label:'Nombre',initial:payload.name??'',required:true}],
    [action(operation==='new'?'create':'rename',operation==='new'?'Crear':'Guardar',operation==='new'?(payload.gameIds?.length?{gameIds:payload.gameIds}:{}):{collectionId:payload.collectionId})]);
   if(operation==='export')return form('Exportar colecciones',[{id:'snapshot',kind:'json',label:'JSON',initial:JSON.stringify(await module.dispatch('export'),null,2)}],[]);
   if(operation==='import-backup'&&!payload.snapshot)return form('Importar colecciones',[{id:'snapshot',kind:'json',label:'JSON',initial:'',required:true}],[action('import-backup','Importar',{},true)]);
   try{await module.dispatch(operation,payload,context);}catch(e){
    const messages={'invalid-name':'Escribe un nombre válido para la colección.','duplicate-name':'Ya existe una colección con ese nombre.','no-games-selected':'Selecciona al menos un juego.','reserved-collection':'Favoritos es la colección predeterminada del módulo.','collection-not-found':'La colección ya no existe.'};
    throw new Error(messages[e.code]??e.message);
   }
   if(['filter','add','remove','create'].includes(operation))return {kind:'close-panel'};
   return manage(context);
  }};
}
