import {createPreferences} from './gamepad-preferences.js';
import {systems,systemFor} from './gamepad-systems.js';
const moduleId='nelkano.basics';
const keys={gb:'GAME_BOY',gbc:'GAME_BOY',gba:'GBA',nds:'NDS',n3ds:'N3DS','3ds':'N3DS',nes:'NES',snes:'SNES',md:'MEGADRIVE',sms:'MASTER_SYSTEM',gg:'GAME_GEAR',ngp:'NEO_GEO_POCKET',ngpc:'NEO_GEO_POCKET',ps1:'PS1',switch:'SWITCH',psp:'PSP',gamecube:'GAMECUBE',chip8:'CHIP8',rpgmaker:'RPG_MAKER'};
export function platformSettings(host){const preferences=createPreferences(host.storage);let state=null,editing='GAME_BOY';
 async function configure(){const game=await host.emulation.snapshot();const key=keys[game?.systemId]||editing;const allowed=new Set(systemFor(key).targets.map(t=>t.button));await host.input.configure(Object.fromEntries(Object.entries(state.bindings).filter(([bit])=>allowed.has(Number(bit)))),state.ps1Bindings);}
 async function change(action,payload={}){state=(await preferences.dispatch(action,payload)).value;editing=state.selectedSystem;await configure();}
 const section=(id,label)=>({id,label,presentation:'section',actions:[]});
 const buttons=(id,actions)=>({id,label:id,presentation:'actions',actions});
 const setting=(id,label,subtitle,value,badge,action)=>({id,label,...(subtitle?{subtitle}:{}),...(value?{value}:{}),...(badge?{badge}:{}),presentation:'setting',actions:action?[action]:[]});
 async function gamepad(){
  const input=await host.input.snapshot(),system=systemFor(editing),bindings=state.bindings;
  return {kind:'page',layout:'settings',title:'Controles',text:input.simulated?'Mando simulado. No usa Bluetooth ni archivos reales.':undefined,
   fields:[{id:'system',label:'Emulador',kind:'select',presentation:'tabs',initial:editing,options:systems.map(s=>({label:s.shortLabel,value:s.key})),onChangeAction:'gamepad-system'}],
   rows:[section('mapping-heading','Asignación de botones'),buttons('profiles',[
    {actionId:'gamepad-save-dialog',label:'Guardar configuración',submitFields:false},
    {actionId:'gamepad-load-dialog',label:'Cargar configuración',submitFields:false}]),
    ...system.targets.map(t=>({...setting('button-'+t.button,t.label,'Toca para reasignar',bindings[t.button]||'Auto',({SELECT:'SE',START:'ST',PAUSE:'Ⅱ',OPTION:'OP',TRIANGLE:'△',SQUARE:'□',CIRCLE:'○',CROSS:'×'}[t.icon]||t.icon),{actionId:'gamepad-capture',label:'Asignar',payload:{bit:t.button}}),...(['DP','FS','ST','L','R'].includes(t.icon)?{icon:'assets/control.png'}:{})})),
    buttons('defaults',[{actionId:'gamepad-reset',label:'Restaurar valores por defecto',submitFields:false}]),
    section('connection','Mando Bluetooth'),setting('bluetooth','Mando Bluetooth','Android Gamepad, Joystick y D-pad',input.devices.length?'Conectado':'Sin conectar','BT',{actionId:'gamepad-settings',label:'Abrir Bluetooth',submitFields:false}),
    ...input.devices.map(d=>setting('device-'+d.id,d.name,'Mando conectado','','BT')),
    section('backups','Archivos de configuración'),buttons('files',[{actionId:'gamepad-import-file',label:'Importar archivo',submitFields:false},{actionId:'gamepad-export-file',label:'Exportar archivo',submitFields:false}]),
    buttons('transfer',[{actionId:'gamepad-transfer',label:'Copiar / pegar asignaciones',submitFields:false}])],actions:[]};
 }
 async function screen(){
  const snapshot=await host.secondScreen.snapshot();
  return {kind:'page',layout:'settings',title:'Segunda pantalla',text:snapshot.simulated?'Vista simulada. No establece una conexión real.':undefined,fields:[],actions:[],rows:[
   section('receiver-heading','Receptor'),setting('receiver','Usar como segunda pantalla','Este dispositivo recibirá una pantalla',snapshot.receiver?'Sí':'No',null,{actionId:'second-mode',label:'Cambiar modo',submitFields:false}),
   section('sender-heading','Emisor'),{id:'status',label:snapshot.message||'Sin conectar',actions:[]},
   buttons('sender-actions',[{actionId:'second-discover',label:'Buscar pantallas',primary:true,submitFields:false},{actionId:'second-disconnect',label:'Desconectar',primary:true,submitFields:false}]),
   ...snapshot.devices.map(d=>setting('device-'+d.id,d.name,d.address||'Receptor disponible','Conectar',null,{actionId:'second-connect',label:'Conectar',payload:{id:d.id},submitFields:false})),
   ...(!snapshot.devices.length?[{id:'no-devices',label:'No hay receptores visibles',actions:[]}]:[]),
   ...(snapshot.state==='CONNECTED'?[buttons('swap',[{actionId:'second-swap',label:'Intercambiar pantallas',submitFields:false}])]:[]),
   section('remembered-heading','Dispositivos recordados'),
   ...snapshot.remembered.map(d=>setting('remembered-'+d.id,d.name||d.id,'Emparejamiento local','Olvidar',null,{actionId:'second-forget',label:'Olvidar',payload:{id:d.id},submitFields:false})),
   ...(!snapshot.remembered.length?[{id:'no-remembered',label:'Todavía no hay dispositivos recordados',actions:[]}]:[])]};
 }
 async function action(a,v={}){
  if(a==='platform-close')return {kind:'close-panel'};
  if(a.startsWith('gamepad-')){
   if(a==='gamepad-save-dialog')return {kind:'panel',title:'Guardar configuración',fields:[{id:'profileName',kind:'text',label:'Nombre',initial:'',required:true}],rows:[],actions:[{actionId:'gamepad-save-profile',label:'Guardar',primary:true},{actionId:'gamepad-open',label:'Cancelar',submitFields:false}]};
   if(a==='gamepad-load-dialog')return {kind:'panel',title:'Cargar configuración',text:state.profiles.length?undefined:'No hay configuraciones guardadas',fields:[],rows:state.profiles.map(p=>({id:p.name,label:p.name,actions:[{actionId:'gamepad-load-profile',label:'Cargar',payload:{name:p.name}}]})),actions:[{actionId:'gamepad-open',label:'Cancelar',submitFields:false}]};
   if(a==='gamepad-system'){if(!systems.some(s=>s.key===v.system))throw Error('Sistema inválido');await change('select-system',{system:v.system});}
   if(a==='gamepad-settings')await host.input.settings();
   if(a==='gamepad-reset'){await change('restore-defaults');}
   if(a==='gamepad-capture'||a==='gamepad-clear'){if(!systemFor(editing).targets.some(t=>t.button===v.bit))throw Error('Botón inválido');if(a==='gamepad-clear')await change('unassign',{button:v.bit});else{const captured=await host.input.capture();if(!captured.cancelled)await change('assign',{button:v.bit,token:captured.token});}}
   if(a==='gamepad-save-profile')await change('save-profile',{name:v.profileName});
   if(a==='gamepad-load-profile')await change('load-profile',{name:v.name});
   if(a==='gamepad-transfer')return {kind:'panel',title:'Asignaciones del mando',text:'Copia este JSON para exportar. Pega otro JSON y pulsa Importar para restaurar las asignaciones.',fields:[{id:'data',kind:'json',label:'Asignaciones',initial:JSON.stringify(state,null,2)}],rows:[],actions:[{actionId:'gamepad-import',label:'Importar',primary:true},{actionId:'gamepad-open',label:'Volver',submitFields:false}]};
   if(a==='gamepad-import-file'){const result=await host.input.importProfile();if(result.state)await change('import-backup',{state:result.state});}
   if(a==='gamepad-export-file')await host.input.exportProfile(state);
   if(a==='gamepad-import')await change('import-backup',{state:typeof v.data==='string'?JSON.parse(v.data):v.data});
   return gamepad();
  }
  if(a==='second-mode'){const snapshot=await host.secondScreen.snapshot();return {kind:'panel',title:'Usar como segunda pantalla',fields:[{id:'enabled',kind:'select',label:'Receptor',initial:snapshot.receiver?'yes':'no',options:[{label:'No',value:'no'},{label:'Sí',value:'yes'}],onChangeAction:'second-receiver'}],rows:[],actions:[{actionId:'second-open',label:'Cancelar',submitFields:false}]};}
  if(a.startsWith('second-')){const operation=a.slice(7);if(['discover','disconnect','swap'].includes(operation))await host.secondScreen[operation]();else if(operation==='connect'||operation==='forget')await host.secondScreen[operation](v.id);else if(operation==='receiver')await host.secondScreen.receiver(v.enabled==='yes');return screen();}
  throw Error('Acción desconocida');
 }
 return {activate:async()=>{state=(await preferences.read()).value;editing=state.selectedSystem;await configure()},deactivate:()=>host.input.release(),onEvent:async e=>{if(e.type==='session-started'||e.type==='session-closed')await configure()},contributions:()=>[{moduleId,id:'gamepad',slot:'SETTINGS_SECTION',section:'Controles',label:'Mando Bluetooth',description:'Conectar y asignar los botones de un mando',actionId:'gamepad-open',icon:'standard:settings'},{moduleId,id:'second-screen',slot:'SETTINGS_SECTION',section:'Pantalla',label:'Segunda pantalla',description:'Enviar una pantalla a otro dispositivo de la red local',actionId:'second-open',icon:'standard:screens'}],action,
 onHook:async r=>{if(r.hook==='gamepad'){if(r.operation==='snapshot')return {...await host.input.snapshot(),settings:state};if(r.operation==='set'){await change('import-backup',{state:r.value});return {saved:true}}}if(r.hook==='second-screen'){if(r.operation==='snapshot')return host.secondScreen.snapshot();if(['discover','disconnect','swap'].includes(r.operation))return host.secondScreen[r.operation]();if(['connect','forget'].includes(r.operation))return host.secondScreen[r.operation](r.value.id);if(['receiver','pair'].includes(r.operation))return host.secondScreen[r.operation](r.value.enabled);}throw Error('Operación no disponible');}};
}
