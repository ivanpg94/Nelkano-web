import {createModule as createCollections} from './collections/sdk.js';
import {streamingSettings} from './streaming.js';
import {platformSettings} from './platform-settings.js';
export const moduleId='nelkano.basics';
function createBasicFeatures(host){
 const platform=platformSettings(host);const streaming=streamingSettings(host);
 let active=false,autoSave=false;
 const controls=[['pause','Pausa','sys-pause'],['fullscreen','Full','sys-fullscreen'],['stretch','Estirar','sys-stretch'],['save','Guardar','sys-save'],['load','Cargar','sys-load'],['screens','Pantallas','sys-screen-mode']];
 async function execute(action,context,payload={}){const state=await host.emulation.snapshot();if(!state||!context.session||context.session.id!==state.session.id||context.session.generation!==state.session.generation)throw Error('La partida ya no estÃ¡ disponible.');const r=state.session,s=state.display.selectedSlot;
  if(action==='pause')await host.emulation.setPaused(r,!state.paused);
  else if(action==='fullscreen')await host.emulation.setFullscreen(r,!state.display.fullscreen);
  else if(action==='stretch')await host.emulation.setStretch(r,!state.display.stretch);
  else if(action==='save')await host.saves.save(r,s);
  else if(action==='load')await host.saves.load(r,s);
  else if(action==='reset')await host.emulation.reset(r);
  else if(action==='screens')return {kind:'panel',title:'Pantallas',fields:[],rows:[],actions:[...['Ambas','Superior','Inferior'].map((label,mode)=>({actionId:'player-screen-choice',label,payload:{mode}})),{actionId:'close-screen',label:'Cerrar'}]};
  else if(action==='screen-choice'){await host.emulation.setScreenMode(r,payload.mode);return {kind:'close-panel'};}
  return null;
 }
 async function restore(){const saved=await host.storage.read('autosave-v1');autoSave=saved.value?.enabled===true;await host.saves.setAutoSave(autoSave);}
 async function setAutoSave(enabled){
  if(typeof enabled!=='boolean')throw Error('El estado de autoguardado no es vÃ¡lido.');
  for(let attempt=0;attempt<4;attempt++){const saved=await host.storage.read('autosave-v1');if(await host.storage.compareAndSwap('autosave-v1',saved.revision,{enabled})){autoSave=enabled;await host.saves.setAutoSave(enabled);return;}}
  throw Error('No se pudo guardar el ajuste. IntÃ©ntalo de nuevo.');
 }
 return {
  async activate(){await restore();await platform.activate();await streaming.activate();active=true;},async deactivate(){active=false;await platform.deactivate();await streaming.deactivate();await host.saves.setAutoSave(false);},
  async onEvent(event){await platform.onEvent(event)},
  async onHook(request){if(!active)throw Error('Módulo desactivado');return request.hook==='streaming'?streaming.onHook(request):platform.onHook(request)},
  async contributions(context={}){
   if(!active)return [];
   if(context.surface==='settings')return [...platform.contributions(),...streaming.contributions().filter(c=>c.slot==='SETTINGS_SECTION'),{moduleId,id:'autosave',slot:'SETTINGS_SECTION',section:'Guardados',category:'general',label:'Autoguardados',description:'Se sobrescribe cada minuto jugando',actionId:'set-autosave',icon:'standard:save',kind:'toggle',checked:autoSave}];
   if(context.surface==='emulation'){
    const state=host.emulation?await host.emulation.snapshot():null;const out=[];
    if(state&&context.session?.id===state.session.id&&context.session?.generation===state.session.generation){
     for(const [id,label,controlId]of controls){if(id==='screens'&&!state.capabilities.includes('DUAL_SCREEN'))continue;if(['save','load'].includes(id)&&!state.capabilities.includes('SAVE_STATES'))continue;out.push({moduleId,id:'player-'+id,slot:'PLAYER_SYSTEM_BUTTON',label,actionId:'player-'+id,icon:id==='screens'?'standard:screens':'assets/'+id+'.png',payload:{controlId},enabled:id==='save'?state.canSave&&state.display.selectedSlot<6:id==='load'?state.slots.includes(state.display.selectedSlot):true});}
     for(const [id,label]of [['save','Guardar'],['load','Cargar'],['reset','Reiniciar']])out.push({moduleId,id:'menu-'+id,slot:'PLAYER_MENU',label,actionId:'player-'+id,payload:{menuAction:id},enabled:id==='reset'?state.capabilities.includes('RESET'):state.capabilities.includes('SAVE_STATES')&&(id==='save'?state.canSave&&state.display.selectedSlot<6:state.slots.includes(state.display.selectedSlot))});
    }
    return [...out,...streaming.contributions().filter(c=>c.slot==='EMULATION_SETTINGS_SECTION'),{moduleId,id:'autosave-player',slot:'EMULATION_SETTINGS_SECTION',label:'Autoguardados',description:'Se sobrescribe cada minuto jugando',actionId:'set-autosave',icon:'standard:save',kind:'toggle',checked:autoSave}];}
   const ids=context.surface==='game'&&context.gameId?[context.gameId]:context.surface==='library'?context.selection??[]:[];
   if(!ids.length)return [];
   const extra=[];if(context.surface==='game')extra.push({moduleId,id:'cover',slot:'GAME_ARTWORK_ACTION',label:'Seleccionar carÃ¡tula',actionId:'cover',icon:'assets/artwork.png'});if(context.surface==='game'&&host.saves.list){const saved=(await host.saves.list()).filter(s=>s.gameId===context.gameId).sort((a,b)=>a.slot-b.slot);const resume=saved.find(s=>s.slot===6)??saved[0];if(resume)extra.push({moduleId,id:'continue',slot:'GAME_LAUNCH_ACTION',label:'Continuar',actionId:'continue',payload:{primaryLaunch:true,gameId:context.gameId,slot:resume.slot}});}
   return [...extra,{moduleId,id:'delete-games',slot:context.surface==='game'?'GAME_LAUNCH_ACTION':'LIBRARY_SELECTION_ACTION',label:ids.length===1?'Eliminar juego':'Eliminar juegos',actionId:'delete',icon:'standard:delete',payload:{gameIds:ids}}];
  },
  async dispatch(action,payload={},context={}){
   if(!active)throw Error('AcciÃ³n no disponible.');
   if(action.startsWith('stream-'))return streaming.action(action,payload);
   if(action.startsWith('gamepad-')||action.startsWith('second-')||action==='platform-close')return platform.action(action,payload);
   if(action.startsWith('player-'))return execute(action.slice(7),context,payload);
   if(action==='close-screen')return {kind:'close-panel'};
   if(action==='cover'){const game=(await host.library.list()).find(g=>g.id===context.gameId);if(!game)throw Error('El juego ya no estÃ¡ disponible.');const images=(await host.saves.list()).filter(s=>s.gameId===game.id&&s.hasThumbnail).sort((a,b)=>a.slot-b.slot);return {kind:'panel',title:'Elegir imagen',fields:[],rows:[...images.map(s=>({id:s.id,label:s.slot===6?'Autoguardado':'S'+s.slot,subtitle:'Usar captura de esta partida',selected:game.coverSlot===s.slot,thumbnail:{gameId:game.id,slot:s.slot},actions:[{actionId:'cover-select',label:'Usar captura',payload:{gameId:game.id,slot:s.slot}}]}))],text:images.length?undefined:'Todavía no hay capturas guardadas para este juego.',actions:[{actionId:'cover-select',label:'Restablecer imagen',placement:'footer',payload:{gameId:game.id,slot:null}}]};}
   if(action==='cover-select'){if(payload.gameId!==context.gameId)throw Error('El juego ya no estÃ¡ disponible.');await host.library.setCover(payload.gameId,payload.slot);return {kind:'close-panel'};}
   if(action==='continue'){await host.library.launch(payload.gameId,payload.slot);return {kind:'close-panel'};}
   if(action==='set-autosave'){await setAutoSave(payload.checked);return null;}
   if(action!=='delete')throw Error('AcciÃ³n no disponible.');
   const ids=payload.gameIds;if(!Array.isArray(ids)||!ids.length||ids.some(id=>typeof id!=='string'))throw Error('Selecciona los juegos que quieres eliminar.');
   await host.library.requestDelete([...new Set(ids)]);return {kind:'close-panel'};
  }
 };
}

/** One identity and lifecycle; collection actions cannot collide with delete-game actions. */
export function createModule(host){
 const features=createBasicFeatures(host),collections=createCollections(host);
 const prefix='collections-';
 function collectionUi(value){
  if(Array.isArray(value))return value.map(collectionUi);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>
   [key,key==='actionId'&&typeof item==='string'?prefix+item:collectionUi(item)]));
  return value;
 }
 return {
  async activate(){await features.activate();try{await collections.activate();}catch(e){await features.deactivate();throw e;}},
  async deactivate(){try{await collections.deactivate();}finally{await features.deactivate();}},
  async contributions(context={}){
   const base=await features.contributions(context);
   const extra=['home','library','saves','settings','game'].includes(context.surface)?await collections.contributions(context):[];
   return [...base,...extra.map(c=>({...collectionUi(c),id:prefix+c.id}))];
  },
  async dispatch(action,payload={},context={}){
   return action.startsWith(prefix)?collectionUi(await collections.dispatch(action.slice(prefix.length),payload,context)):
    features.dispatch(action,payload,context);
  },
  async onEvent(event){await features.onEvent(event);return collections.onEvent(event);},
  onHook:request=>features.onHook(request)
 };
}
