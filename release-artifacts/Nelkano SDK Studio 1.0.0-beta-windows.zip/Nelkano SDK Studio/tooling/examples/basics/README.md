# Nelkano básicos

Módulo SDK 0.2.0, versión inicial 0.1.0. Añade Eliminar juego en la ficha y Eliminar juegos durante la selección de biblioteca. Requiere library.read y library.delete. requestDelete pide confirmación al host: cancelar no elimina nada; confirmar elimina copia importada, batería, estados y datos de ejecución privados, como el Android antiguo. No borra el archivo original del selector ni datos de otros módulos. No necesita Colecciones ni el editor.

Pendiente: renombrar. Elegir una carátula a partir de un guardado ya está implementado. La carpeta src permite añadir operaciones separadas a medida que existan puertos específicos en el SDK.

Empaquetado: node src/nelkano/sdk/tooling/bundle-basics.mjs. La clave Ed25519 se conserva fuera del repo en LocalAppData/Nelkano/SDK/signing/basics.pem.


## Autoguardados

Desactivados por defecto. Ajustes → General → Guardados → Autoguardados y ajustes de emulación. Preferencia en autosave-v1 mediante CAS. El módulo publica host.saves.setAutoSave(boolean), capacidad saves.autosave; el host no entrega archivos ni estado del core al módulo. AutoSaveOwner programa cada 60 segundos de juego continuo con sesión sin pausa y SAVE_STATES. SessionOwner comprueba referencia/generación, pausa y canSave antes de serializar el estado bajo el mismo mutex que el guardado manual. Slot reservado 6, separado de manuales 0–5; se sobrescribe, aparece como Autoguardado y puede cargarse. Pausa/cierre/revocación detienen el temporizador; reactivar recupera la preferencia. Studio simula el mismo ajuste y un guardado ficticio cada minuto de sesión sin pausa.

La actualización del módulo incluido se verifica contra el autor fijado por el APK y conserva activación/datos, aunque cambien capacidades sin incrementar versión. Los paquetes importados siguen necesitando la revisión de instalación. Nombre visible: Nelkano básicos; ID nelkano.basics, carpeta basics, versión 0.1.0 y SDK 0.2.0 permanecen.

## Funciones a través del SDK

Los botones Pausa, Full, Estirar, Guardar y Cargar y las acciones de menú Guardar/Cargar/Reiniciar pertenecen al módulo. Llaman host.emulation y host.saves con la referencia de la partida que recibió la acción. Continuar elige el automático o el manual de menor número y llama host.library.launch. Al desactivar el módulo se retiran sus aportaciones; los guardados se conservan.

El host mantiene la sesión, ejecuta el core y dibuja los componentes; no contiene las reglas de elección de Continuar. Las posiciones de los botones conservan sys-pause, sys-fullscreen, sys-stretch, sys-save y sys-load. No se añade ninguna función pendiente.

## Elegir imagen

GAME_ARTWORK_ACTION muestra el icono original sobre la carátula. Abre un panel con vista previa, Portada y capturas de guardados. library.cover permite library.setCover(gameId, slot); null restaura la portada. La imagen se copia para no cambiar cuando se sobrescriba el guardado. saves.read permite leer hasThumbnail y mostrar miniaturas; library.read permite consultar coverSlot. Studio usa una escena simulada.

## Mando, segunda pantalla y streaming

Mando reutiliza catálogo, tokens, ejes y perfiles. El puerto nativo recibe eventos sin pasar cada fotograma por JavaScript. ps1Bindings aplica máscaras PS1 y combinaciones, incluidos L3/R3. A físico es Cruz y B es Círculo. Importar archivo y Exportar archivo usan el selector de documentos de Android (JSON hasta 96 KiB). También permite copiar y pegar JSON. Se valida antes de guardar; cancelar o importar un respaldo inválido conserva las asignaciones.

Segunda pantalla reutiliza LAN/NSD, emparejamiento y WebRTC. Ambos dispositivos deben compartir red. La entrada táctil remota corresponde a la pantalla inferior.

Streaming reutiliza WebRTC, señalización y respaldo HTTP de imagen/audio de https://nelkano.com. Exige partida abierta, sesión y permiso de cuenta. Pide confirmación nativa para enviar vídeo/audio del juego; no utiliza el micrófono. Se detiene al cambiar partida/cuenta, desactivar el módulo o pasar a segundo plano. El respaldo usa WebP/JPEG con calidad adaptativa y PCM mono a 16 kHz en bloques de 500 ms, igual que la antigua. Cola limitada y una subida por tipo; el panel muestra contadores y fallos. Al detener se cortan captura y WebRTC y se cierra en servidor en segundo plano. Un registro sin PIN/tokens permite cerrar sesiones pendientes antes de otra emisión con la misma cuenta.

Ganchos 1.0.0:
- gamepad: snapshot y set con schemaVersion, selectedSystem, bindings, profiles y ps1Bindings.
- second-screen: snapshot/discover/connect/disconnect/receiver/pair/swap/forget.
- streaming: snapshot/configure/start/stop. configure guarda width/height/fps/videoBitrateKbps; start pide confirmación.

Studio simula dispositivos, emisión y selectores de perfiles; no conecta Bluetooth, LAN ni servidores ni escribe archivos de mando. Copiar/pegar JSON permite probar los respaldos. Falta validar mando, segunda pantalla y emisión entre dispositivos físicos.

## Mando Android: corrección actual

Incluye SNES con X/Y, gatillos L2/R2-ZL/ZR separados y L3/R3 PS1. Captura ejes LTRIGGER/RTRIGGER/BRAKE/GAS. Las asignaciones guardadas se conservan y un gatillo reasignado sustituye su función automática.

En interfaz: cruceta/stick para mover el foco, A/Start para aceptar, B/Select para volver y L/R para cambiar sección. Android conecta también los diálogos. En pantalla completa las entradas van al juego; pausa, ventanas y pérdida de foco las liberan. CHIP-8 admite mando en vista normal. Sticks digitales, sin inclinación proporcional ni presión analógica; 3DS/Switch mantienen la conversión a direcciones. La prueba con mando Bluetooth físico está pendiente.

Colecciones y Favoritos están integrados en src/collections: biblioteca, selección múltiple, gestión, importación/exportación y estrella en la ficha. Las acciones collections-* se separan de delete para que eliminar una colección no elimine juegos.
