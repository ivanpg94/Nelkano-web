# Acciones de Amigos

## Ganchos para otros módulos

Declara modules.hooks y consumes con provider nelkano.friends, hook y version 1.0.0. Usa optional:false si tu módulo no puede funcionar sin Amigos.

- friend-actions: contribute publica {label, scope?}. scope puede ser friends, incoming, outgoing o search; sin scope aparece en todos. Amigos llama a onHook con operation execute, contributionId y value {accountUid, friend, scope}. Devuelve {message} para mostrar el resultado. Tu módulo implementa la función; Amigos no crea mundos ni envía invitaciones por sí mismo.
- friends-data: invoke con operation snapshot devuelve la cuenta y las listas ya cargadas. refresh vuelve a consultar el servidor y requiere sesión válida. value es {}. La respuesta incluye revision, account, friends, incoming y outgoing. Los usuarios incluyen uid, name, statusText, avatarColor y avatarUrl, sin correo, contraseña ni tokens. Una lista vacía no demuestra que se haya consultado el servidor: usa refresh cuando necesites datos actuales.
- friends-events: contribute con {} registra el receptor. Amigos llama a onHook con operation changed y value que incluye el snapshot y type session-changed, friends-updated o profile-updated. Son avisos de operaciones del módulo, no presencia en tiempo real ni notificaciones push del servidor. No llames sincrónicamente de vuelta a Amigos desde ese callback; conserva los datos recibidos.

Amigos comprueba que el usuario siga en la lista, que la cuenta y revisión sigan siendo válidas y que el consumidor siga activo. Máximo 16 acciones y 8 receptores. Una acción antigua o de un módulo desactivado se rechaza. Los errores de un receptor no impiden la operación principal.

Ejemplo independiente: npx nelkmod example friends-hooks mi-integracion. Carga Amigos y esa carpeta juntos en Studio; al acceder aparece Invitar a mi mundo (ejemplo). Solo demuestra la llamada entre módulos, sin crear mundos ni enviar invitaciones reales. Se exporta e instala por separado; no viene activado en el teléfono.

Estos ganchos no extraen datos de emulación ni escriben memoria Pokémon. Eso corresponde a la futura integración de modules/online.
