import {u16,u32,put16,put32} from './binary.js';
import {characters,moveNames} from './catalogs.js';
const orders=['GAEM','GAME','GEAM','GEMA','GMAE','GMEA','AGEM','AGME','AEGM','AEMG','AMGE','AMEG','EGAM','EGMA','EAGM','EAMG','EMGA','EMAG','MGAE','MGEA','MAGE','MAEG','MEGA','MEAG'];
export function decodeText(b,o,n){let s='';for(let i=0;i<n;i++){const x=b[o+i];if(x===255)break;s+=x>=187&&x<=212?String.fromCharCode(65+x-187):x>=213&&x<=238?String.fromCharCode(97+x-213):x>=161&&x<=170?String(x-161):characters[x]??(x===0?' ':'')}return s.trim()}
function encodeText(b,o,n,s){b.fill(255,o,o+n);for(let i=0;i<Math.min(s.length,n);i++){const c=s[i];b[o+i]=/[A-Z]/.test(c)?c.charCodeAt(0)-65+187:/[a-z]/.test(c)?c.charCodeAt(0)-97+213:/[0-9]/.test(c)?c.charCodeAt(0)-48+161:Number(Object.keys(characters).find(k=>characters[k]===c)??0)}}
export function decodePokemon(raw,offset,party=true,catalog=null){if(offset<0||offset+(party?100:80)>raw.length)return null;const personality=u32(raw,offset),originalTrainerId=u32(raw,offset+4);if(!personality&&!originalTrainerId)return null;const decrypted=new Uint8Array(48);for(let i=0;i<12;i++)put32(decrypted,i*4,u32(raw,offset+32+i*4)^personality^originalTrainerId);let checksum=0;for(let i=0;i<48;i+=2)checksum=(checksum+u16(decrypted,i))&65535;if(checksum!==u16(raw,offset+28))return null;const blocks={};const order=orders[personality%24];for(let i=0;i<4;i++)blocks[order[i]]=decrypted.slice(i*12,i*12+12);const g=blocks.G,a=blocks.A,e=blocks.E,m=blocks.M;const internalSpecies=u16(g,0),nationalSpecies=catalog&&!catalog.standard&&!(catalog.firstTwo&&internalSpecies<=251)?0:internalSpecies>=277&&internalSpecies<=411?internalSpecies-25:internalSpecies;const speciesName=catalog?.names[internalSpecies]??'',speciesTarget=catalog?.target(speciesName)??'';const level=party?raw[offset+84]:1,currentHp=party?u16(raw,offset+86):-1,totalHp=party?u16(raw,offset+88):1;if(internalSpecies<1||internalSpecies>2048||(!nationalSpecies&&!speciesName)||level<1||level>100||totalHp<1||totalHp>2000||party&&currentHp>totalHp)return null;const iv=u32(m,4),moves=Array.from({length:4},(_,i)=>u16(a,i*2));return {personality,originalTrainerId,internalSpecies,nationalSpecies,level,experience:u32(g,4),nickname:decodeText(raw,offset+8,10),originalTrainerName:decodeText(raw,offset+20,7),heldItem:u16(g,2),friendship:g[9],nature:personality%25,shiny:((originalTrainerId&65535)^(originalTrainerId>>>16)^(personality&65535)^(personality>>>16))<8,egg:!!(iv&0x40000000),abilitySlot:iv>>>31,currentHp,moves,movePp:Array.from(a.slice(8,12)),movePpUps:Array.from({length:4},(_,i)=>(g[8]>>>(i*2))&3),ivs:Array.from({length:6},(_,i)=>(iv>>>(i*5))&31),evs:Array.from(e.slice(0,6)),stats:party?Array.from({length:6},(_,i)=>u16(raw,offset+88+i*2)):Array(6).fill(0),sourceIds:{internalSpecies,speciesName,heldItem:u16(g,2),moves},speciesDetails:{sourceId:internalSpecies,name:speciesName,targetId:speciesTarget,translationStatus:speciesName?'exact':'national_gen3'},moveDetails:moves.map(sourceId=>({sourceId,name:moveNames[sourceId-1]??'',targetId:(moveNames[sourceId-1]??'').replace(/[^a-zA-Z0-9]/g,'').toUpperCase(),translationStatus:sourceId===0||moveNames[sourceId-1]?'exact':'unresolved'})),translation:{species:speciesName?'exact':'national_gen3',heldItem:'national_gen3',moves:'national_gen3'}}}
export function encodePokemon(p,party=true,catalog=null){const national=Number(p.nationalSpecies??0);let species=Number(p.internalSpecies??0);if(catalog){species=catalog.internal(p.speciesDetails?.targetId)||catalog.internal(p.speciesDetails?.name);if(!species&&(p.speciesDetails?.name||p.speciesDetails?.targetId))return null;if(!species&&catalog.names[p.internalSpecies])species=p.internalSpecies}if(!catalog&&(p.speciesDetails?.name||p.speciesDetails?.targetId)){if(national<1||national>386)return null;species=national>251?national+25:national}if(species<1&&national>=1&&national<=386)species=national>251?national+25:national;if(species<1||species>2048)return null;const out=new Uint8Array(party?100:80),pid=Number(p.personality)>>>0,ot=Number(p.originalTrainerId)>>>0;put32(out,0,pid);put32(out,4,ot);encodeText(out,8,10,p.nickname??'');encodeText(out,20,7,p.originalTrainerName??'');const g=new Uint8Array(12),a=new Uint8Array(12),e=new Uint8Array(12),m=new Uint8Array(12);put16(g,0,species);put16(g,2,p.heldItem??0);put32(g,4,p.experience??0);g[8]=(p.movePpUps??[]).reduce((x,n,i)=>x|((Math.max(0,Math.min(3,n)))<<(i*2)),0);g[9]=p.friendship??0;for(let i=0;i<4;i++){put16(a,i*2,p.moves?.[i]??0);a[8+i]=p.movePp?.[i]??0}for(let i=0;i<6;i++)e[i]=Math.max(0,Math.min(255,p.evs?.[i]??0));let iv=(p.egg?0x40000000:0)|(p.abilitySlot?0x80000000:0);for(let i=0;i<6;i++)iv|=Math.max(0,Math.min(31,p.ivs?.[i]??0))<<(i*5);put32(m,4,iv);const blocks={G:g,A:a,E:e,M:m},plain=new Uint8Array(48),order=orders[pid%24];for(let i=0;i<4;i++)plain.set(blocks[order[i]],i*12);let sum=0;for(let i=0;i<48;i+=2)sum=(sum+u16(plain,i))&65535;put16(out,28,sum);for(let i=0;i<12;i++)put32(out,32+i*4,u32(plain,i*4)^pid^ot);if(party){put32(out,80,0);out[84]=Math.max(1,Math.min(100,p.level??1));const hp=Math.max(1,p.stats?.[0]??p.currentHp??1);put16(out,86,Math.max(0,Math.min(hp,p.currentHp??hp)));put16(out,88,hp);for(let i=1;i<6;i++)put16(out,88+i*2,Math.max(1,p.stats?.[i]??1))}return out}
export function stateLayout(state){if(u32(state,0)!==0x41534247||u32(state,4)<16||u32(state,4)>27)throw Error('Estado GBA incompatible');let at=8;for(let i=0;i<2;i++){const n=u32(state,at);if(n>1048576)throw Error('Estado GBA inválido');at+=4+n}at+=4+64+4+4+168+20+20+4+4+1+1+8+8+1+4;if(u32(state,4)>=27)at+=8;at+=8*5+0x4000;if(at+0x48000>state.length)throw Error('Estado GBA incompleto');return {ewramOffset:at,iwramOffset:at+0x40000}}
function trainerNameValid(raw,offset,name) {
 if(offset<0x20000||!name)return false;
 const letters=new Set();
 for(let i=0;i<7;i++) {
  const value=raw[offset+i];if(value===255)break;
  const letter=value>=187&&value<=238;
  if(!letter&&!(value>=161&&value<=170)&&value!==0&&![1,2,5,6,11,16,17,18,27].includes(value))return false;
  if(letter)letters.add((value-187)&31);
 }
 return letters.size>=2;
}
export function extract(ewram,iwram,family,catalog=null) {
 let trainer=null;
 for(let i=0;i<=iwram.length-4;i+=4) {
  const at=u32(iwram,i)-0x02000000;if(at<0||at+32>ewram.length)continue;
  const name=decodeText(ewram,at,7),gender=ewram[at+8],trainerId=u32(ewram,at+10);
  if(!trainerNameValid(ewram,at,name)||gender>1||!trainerId||ewram[at+16]>=60||ewram[at+17]>=60)continue;
  const score=name.length*10+(i>=0x4000?4:0);
  if(!trainer||score>trainer.score)trainer={name,gender,trainerId,score,appearance:(family==='emerald'?'emerald':'frlg')+(gender?'_female':'_male')};
 }
 const preferred=family==='emerald'?[0x244ec,0x244e4,0x244f0]:family==='frlg'?[0x24284,0x24280,0x24288]:[];
 function atParty(at) {
  const party=[];for(let i=0;i<6;i++){const p=decodePokemon(ewram,at+i*100,true,catalog);if(!p)break;party.push(p)}
  if(!party.length)return null;
  return {party,offset:at,score:party.length*100+party.reduce((n,p)=>n+(p.currentHp>0?4:0)+(p.level>=2?2:0),0)};
 }
 let best=null;
 for(const at of preferred){best=atParty(at);if(best)break}
 if(!best)for(let at=0x20000;at<=ewram.length-100;at+=4){const p=atParty(at);if(p){p.score-=Math.floor(Math.abs(at-0x24300)/64);if(!best||p.score>best.score)best=p}}
 if(!best)throw Error('No se pudo extraer el equipo de esta partida');
 const party=best.party,partyOffset=best.offset;
 const warnings=[];
 if(!trainer){trainer={name:'Trainer',gender:0,trainerId:party[0].originalTrainerId,appearance:family+'_male'};warnings.push('trainer_not_located')}
 delete trainer.score;
 function atStorage(at) {
  const names=at+4+14*30*80,wallpapers=names+14*9;
  if(at<0||wallpapers+14>ewram.length||ewram[at]>=14)return null;
  let terminated=0;
  for(let box=0;box<14;box++){if(ewram.slice(names+box*9,names+box*9+9).includes(255))terminated++;if(ewram[wallpapers+box]>15)return null}
  if(terminated<10)return null;
  const pokemon=[];
  for(let box=0;box<14;box++)for(let slot=0;slot<30;slot++){const p=decodePokemon(ewram,at+4+(box*30+slot)*80,false,catalog);if(p)pokemon.push({...p,box,slot})}
  return {offset:at,currentBox:ewram[at],pokemon};
 }
 let storage=null;
 for(const at of family==='emerald'?[0x29864,0x29800]:[0x29318,0x29314,0x29384,0x29800]){storage=atStorage(at);if(storage)break}
 if(!storage) {
  const candidates=new Set(),maximum=ewram.length-(4+14*30*80);
  for(let at=0x20000;at<=ewram.length-80;at+=4)if(decodePokemon(ewram,at,false,catalog))for(let slot=0;slot<420;slot++){const base=at-4-slot*80;if(base>=0x20000&&base<=maximum)candidates.add(base)}
  for(const at of candidates){if(Math.abs(at-partyOffset)<0x1000)continue;const p=atStorage(at);if(p&&p.pokemon.length>=2&&(!storage||p.pokemon.length>storage.pokemon.length))storage=p}
 }
 if(!storage){
  let score=0;
  // Localized ROMs and hacks can relocate even an empty PC. Confirm its names
  // and wallpapers rather than guessing a write address from a family hint.
  for(let at=0;at+33744<=ewram.length;at+=4){
   if(ewram[at]>=14||Math.abs(at-partyOffset)<0x1000)continue;
   const names=at+33604,labels=Array.from({length:14},(_,i)=>decodeText(ewram,names+i*9,9));
   if(!labels[0]||!labels[1])continue;
   const named=labels.filter(n=>n.length>=2&&n.length<=8&&/[A-Za-z]/.test(n)).length;
   if(named<10||named<=score)continue;
   const candidate=atStorage(at);if(candidate){storage=candidate;score=named}
  }
 }
 if(!storage)warnings.push('storage_not_located');
 return {trainer,party,partyOffset,storage,originStorage:{currentBox:storage?.currentBox??0,pokemon:storage?.pokemon??[]},returnCompatibility:catalog?{mode:'target_catalog',species:catalog.targetIds()}:{mode:'national_gen3',maxNational:386},extraction:{capabilities:{trainer:!warnings.includes('trainer_not_located'),party:true,storage:!!storage},warnings}};
}
export function applyReturn(ewram,origin,returned,family,catalog=null){const next=ewram.slice(),party=(returned.party??[]).map(p=>encodePokemon(p,true,catalog)).filter(Boolean).slice(0,6);if(!party.length)throw Error('El retorno no contiene ningún Pokémon compatible');next.fill(0,origin.partyOffset,origin.partyOffset+600);party.forEach((p,i)=>next.set(p,origin.partyOffset+i*100));const hints=family==='emerald'?[origin.partyOffset-3,0x244e9]:family==='frlg'?[0x24029]:[],count=hints.find(at=>ewram[at]===origin.party.length)??hints.find(at=>ewram[at]<=6)??-1;if(count>=0)next[count]=party.length;if(returned.originStorage){if(!origin.storage)throw Error('No se pudo localizar el PC de destino');const at=origin.storage.offset;next[at]=Math.max(0,Math.min(13,returned.originStorage.currentBox??0));next.fill(0,at+4,at+4+14*30*80);for(const p of returned.originStorage.pokemon??[]){if(!Number.isInteger(p.box)||!Number.isInteger(p.slot)||p.box<0||p.box>=14||p.slot<0||p.slot>=30)continue;const bytes=encodePokemon(p,false,catalog);if(bytes)next.set(bytes,at+4+(p.box*30+p.slot)*80)}}return next}
