// RFC 1950/1951 fixed-Huffman encoder. Bounded chains keep module work predictable.
const lengthBase=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
const lengthExtra=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
const distanceBase=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
const distanceExtra=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
const reverse=(value,n)=>{let out=0;for(let i=0;i<n;i++){out=(out<<1)|(value&1);value>>>=1}return out};
export function zlib(raw){
 const out=[0x78,0x01];let bits=0,count=0;
 const write=(value,n)=>{bits|=value<<count;count+=n;while(count>=8){out.push(bits&255);bits>>>=8;count-=8}};
 const symbol=value=>{const n=value<144?8:value<256?9:value<280?7:8,code=value<144?48+value:value<256?400+value-144:value<280?value-256:192+value-280;write(reverse(code,n),n)};
 write(3,3);
 const head=new Int32Array(65536).fill(-1),previous=new Int32Array(raw.length).fill(-1);
 const hash=i=>((raw[i]*251+raw[i+1])*251+raw[i+2])&65535;
 const insert=i=>{if(i+2<raw.length){const h=hash(i);previous[i]=head[h];head[h]=i}};
 for(let at=0;at<raw.length;){
  let best=0,distance=0,candidate=at+2<raw.length?head[hash(at)]:-1;
  for(let chain=0;candidate>=0&&at-candidate<=32768&&chain<64;chain++,candidate=previous[candidate]){
   if(raw[candidate+best]!==raw[at+best])continue;
   let n=0;const limit=Math.min(258,raw.length-at);
   while(n<limit&&raw[candidate+n]===raw[at+n])n++;
   if(n>=3&&n>best){best=n;distance=at-candidate;if(n===limit)break}
  }
  if(best<3){symbol(raw[at]);insert(at++);continue}
  let l=lengthBase.length-1;while(lengthBase[l]>best)l--;
  symbol(257+l);if(lengthExtra[l])write(best-lengthBase[l],lengthExtra[l]);
  let d=distanceBase.length-1;while(distanceBase[d]>distance)d--;
  write(reverse(d,5),5);if(distanceExtra[d])write(distance-distanceBase[d],distanceExtra[d]);
  for(let i=0;i<best;i++)insert(at+i);at+=best;
 }
 symbol(256);if(count)out.push(bits&255);
 let a=1,b=0;for(const v of raw){a=(a+v)%65521;b=(b+a)%65521}
 const sum=((b<<16)|a)>>>0;out.push(sum>>>24,(sum>>>16)&255,(sum>>>8)&255,sum&255);
 return out;
}
