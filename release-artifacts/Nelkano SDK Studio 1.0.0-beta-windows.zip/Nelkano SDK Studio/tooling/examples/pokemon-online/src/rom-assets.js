import {base64,unbase64,u16,u32,put32} from './binary.js';
const nameCharacters={0:' ',1:'\u00c0',2:'\u00c1',5:'\u00c8',6:'\u00c9',11:'\u00cd',16:'\u00d1',17:'\u00d2',18:'\u00d3',27:'\u00da',45:'&',83:'\u00ed',84:'%',85:'(',86:')',90:'\u00ed',91:'%',92:'(',93:')',171:'!',172:'?',173:'.',180:"'",181:'\u2642',182:'\u2640',184:',',186:'/'};
function decodeName(raw){let name='',terminated=false;for(const value of raw){if(value===255){terminated=true;break}const c=value>=187&&value<=212?String.fromCharCode(65+value-187):value>=213&&value<=238?String.fromCharCode(97+value-213):value>=161&&value<=170?String(value-161):nameCharacters[value];if(c===undefined)return '';name+=c}name=name.trim();return terminated&&/[A-Za-z0-9\u00c0-\u024f]/.test(name)&&/^[A-Za-z0-9\u00c0-\u024f .'\u2640\u2642?&-]+$/.test(name)?name:''}
import {indexedPng} from './sprites.js';
const target=value=>(value??'').replace(/\u2642/g,' MALE ').replace(/\u2640/g,' FEMALE ').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const encode=value=>Uint8Array.from([...value].map(c=>c.charCodeAt(0)-65+187).concat(255));
export class SpeciesCatalog {
 constructor(data){Object.assign(this,data)}
 target(value){return target(value)}
 internal(value){const id=target(value);return id?this.names.findIndex(n=>n&&target(n)===id):0}
 targetIds(){return [...new Set(this.names.filter(Boolean).map(target))]}
 static async read(rom) {
  const hits=await rom.find(encode('BULBASAUR'),1,256);let best=null;
  for(const hit of hits) {
   const base=hit-11;if(base<0)continue;
   const bytes=await rom.read(base,Math.min(32768,rom.size-base)),names=Array(2049).fill('');
   for(let i=1;i<names.length&&i*11+11<=bytes.length;i++) {
    const raw=bytes.subarray(i*11,i*11+11);if(!raw.includes(255))continue;
    const name=decodeName(raw);if(name)names[i]=name;
   }
   const score=['BULBASAUR','IVYSAUR','VENUSAUR','CHARMANDER'].reduce((n,x,i)=>n+(target(names[i+1])===x?1:0),0)+(target(names[25])==='PIKACHU'?2:0);
   if(score<4||best&&best.score>=score)continue;
   const match=(ids,wanted)=>ids.every((v,i)=>target(names[v])===wanted[i]);
   const firstTwo=match([1,4,25,150,151,152,251],['BULBASAUR','CHARMANDER','PIKACHU','MEWTWO','MEW','CHIKORITA','CELEBI']);
   const standard=firstTwo&&match([277,280,283,321,329,347,375,411],['TREECKO','TORCHIC','MUDKIP','MAKUHITA','ARON','NUMEL','MILOTIC','CHIMECHO']);
   best={score,names,firstTwo,standard,tableOffset:base};
  }
  return best?new SpeciesCatalog(best):null;
 }
}
/** Bounded ROM reads and pattern searches; no file paths, Node or native handles. */
export class RomView {
 constructor(host,session,size){this.host=host;this.session=session;this.size=size;this.cache=new Map()}
 async read(offset,length){
  if(offset<0||length<1||offset+length>this.size)throw Error('ROM range');
  const key=offset+':'+length;if(this.cache.has(key))return this.cache.get(key);
  const bytes=new Uint8Array(length);
  for(let at=0;at<length;at+=32768)bytes.set(unbase64((await this.host.gameRuntime.rom(this.session,{offset:offset+at,length:Math.min(32768,length-at)})).data),at);
  if(this.cache.size>=128)this.cache.delete(this.cache.keys().next().value);if(length<=32768)this.cache.set(key,bytes);
  return bytes;
 }
 async find(pattern,alignment=4,maximum=256){return (await this.host.gameRuntime.romSearch(this.session,{pattern:base64(pattern),alignment,maximum})).offsets}
 offset(pointer){const at=pointer-0x08000000;return at>=0&&at<this.size?at:-1}
 async ptr(at){return this.offset(u32(await this.read(at,4),0))}
}
const color=value=>{const r=value&31,g=(value>>>5)&31,b=(value>>>10)&31;return ((r<<3|r>>>2)<<16)|((g<<3|g>>>2)<<8)|(b<<3|b>>>2)};
const palette=bytes=>Array.from({length:16},(_,i)=>color(u16(bytes,i*2)));
function tiled(bytes,width,height){const out=new Uint8Array(width*height);for(let y=0;y<height;y++)for(let x=0;x<width;x++){const v=bytes[(Math.floor(y/8)*(width/8)+Math.floor(x/8))*32+(y&7)*4+Math.floor((x&7)/2)];out[y*width+x]=(v>>>((x&1)*4))&15}return out}
function lz(bytes,maximum){if(bytes[0]!==16)return null;const n=bytes[1]|bytes[2]<<8|bytes[3]<<16;if(n<1||n>maximum)return null;const out=new Uint8Array(n);let p=4,o=0;while(o<n&&p<bytes.length){const flags=bytes[p++];for(let bit=7;bit>=0&&o<n;bit--){if(!(flags&(1<<bit))){if(p>=bytes.length)return null;out[o++]=bytes[p++]}else{if(p+1>=bytes.length)return null;const a=bytes[p++],b=bytes[p++],distance=((a&15)<<8)|b,length=(a>>>4)+3;if(distance+1>o)return null;for(let i=0;i<length&&o<n;i++){out[o]=out[o-distance-1];o++}}}}return o===n?out:null}
async function decompress(rom,offset,maximum){if(offset<0)return null;return lz(await rom.read(offset,Math.min(32768,rom.size-offset)),maximum)}
async function spritePalette(rom,table,tag,compressed=false) {
 const pattern=Uint8Array.of(tag&255,tag>>>8,0,0),hits=await rom.find(pattern,4);let best=null;
 for(const hit of hits) {
  const entry=hit-4;if(entry<0||entry+8>rom.size||entry%4)continue;
  const raw=await rom.read(entry,8),data=rom.offset(u32(raw,0));if(data<0||data+32>rom.size)continue;
  if(compressed){const bytes=await decompress(rom,data,256);if(bytes?.length>=32&&(!best||Math.abs(entry-table)<best.distance))best={colors:palette(bytes),offset:entry,distance:Math.abs(entry-table)};continue}
  if(u16(raw,6))continue;
  let score=1;
  const start=Math.max(0,entry-256),end=Math.min(rom.size,entry+264),block=await rom.read(start,end-start);
  const valid=at=>at>=0&&at+8<=block.length&&!u16(block,at+6)&&rom.offset(u32(block,at))>=0;
  for(const d of [-1,1])for(let i=1;i<=32;i++){if(!valid(entry-start+d*i*8))break;score++}
  const distance=Math.abs(entry-table);
  if(!best||score>best.score||score===best.score&&distance<best.distance)best={colors:palette(await rom.read(data,32)),offset:entry,score,distance};
 }
 return best;
}
async function infoAt(rom,at){if(at<0||at+36>rom.size)return null;const bytes=await rom.read(at,36),width=u16(bytes,8),height=u16(bytes,10),size=u16(bytes,6);if(width<8||width>64||height<8||height>64||(width&7)||(height&7)||size<width*height/2||size>width*height*2||size>4096||[16,24,28].some(o=>rom.offset(u32(bytes,o))<0))return null;return {at,width,height,bytes}}
async function infoPointer(rom,at){return infoAt(rom,await rom.ptr(at))}
function graphicsId(ewram,anchor){let best=-1,score=-1;for(let at=0;at+36<=ewram.length;at+=4){if(!(ewram[at]&1)||!(ewram[at+2]&1)||ewram[at+4]>=64||ewram[at+6]>96)continue;const x=u16(ewram,at+16),y=u16(ewram,at+18),id=ewram[at+5];if(x<1||x>255||y<1||y>255||ewram[at+10]>63||ewram[at+9]>127)continue;const tracked=!!(ewram[at+1]&128);if(!id&&!tracked)continue;const s=(tracked?100:0)+(anchor&&anchor.mapGroup===ewram[at+10]&&anchor.mapNumber===ewram[at+9]?80:0);if(s>score){score=s;best=id}}return best}
async function graphicsTable(rom,id) {
 const hits=[];for(const size of [256,512,1024])hits.push(...await rom.find(Uint8Array.of(size&255,size>>>8,16,0,32,0),2,64));let best=null;const tried=new Set();
 for(const hit of hits) {
  const info=await infoAt(rom,hit-6);if(!info)continue;
  const pointer=new Uint8Array(4);put32(pointer,0,0x08000000+info.at);
  for(const at of await rom.find(pointer,4,16)) {
   if(tried.has(at))continue;let start=at,invalid=0;
   for(let p=at-4,steps=0;p>=0&&steps<255;p-=4,steps++){if(await infoPointer(rom,p))invalid=0;else invalid++;if(invalid>=5){start=p+invalid*4;break}start=p}
   while(start<at&&!await infoPointer(rom,start))start+=4;
   if(tried.has(start))continue;tried.add(start);
   let run=0;while(run<512&&start+run*4+4<=rom.size&&await infoPointer(rom,start+run*4))run++;
   if(run>=40&&(!best||run>best.run)&&await infoPointer(rom,start+id*4))best={start,run};
  }
  if(best)break;
 }
 return best?.start??-1;
}
async function animation(rom,table,id){const at=await rom.ptr(table+id*4);if(at<0)return [];const raw=await rom.read(at,Math.min(128,rom.size-at)),out=[];for(let o=0;o+4<=raw.length&&out.length<4;o+=4){const image=u16(raw,o);if(image>=32768)break;const flags=u16(raw,o+2);out.push({image,h:!!(flags&64),v:!!(flags&128)})}return out}
export async function overworld(rom,ewram,anchor) {
 const id=graphicsId(ewram,anchor);if(id<0)return null;const table=await graphicsTable(rom,id);if(table<0)return null;
 const info=await infoPointer(rom,table+id*4);if(!info)return null;
 const {width:w,height:h,bytes}=info,images=rom.offset(u32(bytes,28)),anims=rom.offset(u32(bytes,24)),colors=await spritePalette(rom,table,u16(bytes,2));
 if(!colors)return null;
 const frames=[];
 for(let row=0;row<4;row++){const idle=await animation(rom,anims,[0,2,3,1][row]),walk=await animation(rom,anims,[4,6,7,5][row]);if(!idle.length||!walk.length)return null;for(let col=0;col<4;col++){const f=col%2?walk[Math.floor(col/2)%walk.length]:idle[0],raw=await rom.read(images+f.image*8,8),at=rom.offset(u32(raw,0));if(at<0||u16(raw,4)!==w*h/2)return null;const pixels=tiled(await rom.read(at,w*h/2),w,h),flipped=new Uint8Array(w*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++)flipped[y*w+x]=pixels[(f.v?h-1-y:y)*w+(f.h?w-1-x:x)];frames.push(flipped)}}
 let minX=w,minY=h,maxX=-1,maxY=-1;for(const frame of frames)for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(frame[y*w+x]){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y)}
 if(maxX<minX)return null;const cw=maxX-minX+1,ch=maxY-minY+1,scale=Math.min(4,Math.floor(32/cw),Math.floor(48/ch));if(scale<1)return null;
 const sheet=new Uint8Array(128*192),ox=Math.floor((32-cw*scale)/2),oy=48-ch*scale;
 for(let f=0;f<16;f++)for(let y=0;y<ch;y++)for(let x=0;x<cw;x++)for(let dy=0;dy<scale;dy++)for(let dx=0;dx<scale;dx++)sheet[(Math.floor(f/4)*48+oy+y*scale+dy)*128+(f%4)*32+ox+x*scale+dx]=frames[f][(minY+y)*w+minX+x];
 return {image:indexedPng(128,192,sheet,colors.colors),graphicsId:id,graphicsTableOffset:table,sourceFrameWidth:w,sourceFrameHeight:h,frameWidth:32,frameHeight:48,columns:4,rows:4,source:'rom_object_event_graphics'};
}
async function entry(rom,at){if(at<0||at+8>rom.size)return null;const b=await rom.read(at,8),data=rom.offset(u32(b,0)),size=u16(b,4),tag=u16(b,6);return data>=0&&size>0?{data,size,tag,at}:null}
export async function trainerFront(rom,profile,gender) {
 const id=profile.id==='pokemon-aquamarine-demo'?gender===1?1:0:profile.family==='emerald'?gender===1?72:71:gender===1?136:135;
 let best=null;for(const size of [2048,4096])for(const hit of await rom.find(Uint8Array.of(size&255,size>>>8,id&255,id>>>8),2)) {
  const at=hit-4,e=await entry(rom,at);if(!e||e.tag!==id||!await decompress(rom,e.data,8192))continue;
  const start=at-id*8;if(start<0)continue;const table=await rom.read(start,Math.min(192*8,rom.size-start));let run=0,monotonic=0;for(let i=0;i<192&&i*8+8<=table.length;i++){const o=i*8;if(rom.offset(u32(table,o))<0||![2048,4096].includes(u16(table,o+4)))break;if(i&&u16(table,o+6)===u16(table,o-2)+1)monotonic++;run++}
  if(run<16||run===192||monotonic<Math.max(12,run-8))continue;const score=monotonic*10000-Math.abs(run-(profile.family==='emerald'?93:148))*250+run*10;if(!best||score>best.score)best={score,e,table:start};
 }
 if(!best)return null;const raw=await decompress(rom,best.e.data,8192);if(!raw||![2048,4096].includes(raw.length))return null;
 const colors=await spritePalette(rom,best.table,best.e.tag,true);if(!colors)return null;
 const h=raw.length===4096?128:64,pixels=tiled(raw,64,h),out=new Uint8Array(128*h*2);
 for(let y=0;y<h;y++)for(let x=0;x<64;x++)for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++)out[(y*2+dy)*128+x*2+dx]=pixels[y*64+x];
 return {image:indexedPng(128,h*2,out,colors.colors),trainerPicId:id,tableOffset:best.table,paletteOffset:colors.offset,sourceWidth:64,sourceHeight:h,frameCount:h/64,width:128,height:h*2,source:'rom_trainer_front_pic'};
}
export async function trainerBack(rom,profile,gender) {
 const sizes=profile.family==='emerald'?[8192,8192,10240,10240,8192,8192,8192,8192]:[10240,10240,8192,8192,8192,8192],id=gender===1?1:0;let found=null;
 for(const hit of await rom.find(Uint8Array.of(sizes[0]&255,sizes[0]>>>8,0,0),2)) {
  const start=hit-4;if(start<0)continue;const entries=[];
  for(let i=0;i<sizes.length;i++){const e=await entry(rom,start+i*8);if(!e||e.size!==sizes[i]||e.tag!==i||e.data+e.size>rom.size)break;entries.push(e)}
  if(entries.length!==sizes.length)continue;const at=start+sizes.length*8+id*8,b=await rom.read(at,8),data=rom.offset(u32(b,0));if(data<0||u16(b,4)!==id||u16(b,6))continue;
  const raw=await decompress(rom,data,4096)??await rom.read(data,32);if(raw.length<32)continue;found={e:entries[id],colors:palette(raw),table:start,paletteOffset:at};break;
 }
 if(!found)return null;const e=found.e,b=await rom.read(e.data,e.size),raw=b[0]===16&&(b[1]|b[2]<<8|b[3]<<16)===e.size?await decompress(rom,e.data,e.size):b;if(!raw)return null;const count=e.size/2048,out=new Uint8Array(800*160);
 for(let f=0;f<5;f++){const frame=tiled(raw.subarray(Math.min(f,count-1)*2048),64,64);for(let y=0;y<64;y++)for(let x=0;x<64;x++)for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++)out[(32+y*2+dy)*800+f*160+16+x*2+dx]=frame[y*64+x]}
 return {image:indexedPng(800,160,out,found.colors),trainerBackPicId:id,tableOffset:found.table,paletteOffset:found.paletteOffset,sourceFrameCount:count,frameCount:5,width:800,height:160,source:'rom_trainer_back_pic'};
}
