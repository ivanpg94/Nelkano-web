import {unbase64,u16,u32} from './binary.js';
import {captureSprite,screenSnapshot} from './sprites.js';
/** Map coordinates are shared; BG tile-buffer phase is private to each player. */
export class MapPositionTracker {
 constructor(){this.previous=null;this.point=null}
 track(state,x,y,footX,footY){
  const previous=this.previous,target={x:state.tileX*16,y:state.tileY*16};
  const same=previous&&previous.group===state.mapGroup&&previous.number===state.mapNumber;
  const delta=(a,b)=>((a-b+128)&255)-128;
  if(!same)this.point=target;
  else {
   const dx=delta(x,previous.x)+footX-previous.footX,dy=delta(y,previous.y)+footY-previous.footY;
   const next={x:this.point.x+dx,y:this.point.y+dy};
   // Restore/warp and a stopped avatar establish the exact tile anchor again.
   this.point=Math.abs(state.tileX-previous.tileX)>4||Math.abs(state.tileY-previous.tileY)>4||Math.abs(next.x-target.x)>48||Math.abs(next.y-target.y)>48?target:{x:Math.abs(dx)<.01?target.x:next.x,y:Math.abs(dy)<.01?target.y:next.y};
  }
  this.previous={group:state.mapGroup,number:state.mapNumber,tileX:state.tileX,tileY:state.tileY,x,y,footX,footY};
  return {...this.point};
 }
}
export class PokemonPresence {
 constructor(){this.objectAddress=0;this.spriteId=0;this.pointer=0;this.last=null;this.scrollX=null;this.scrollY=null;this.family='';this.sprite=null;this.spriteTime=0;this.battle=false;this.battleTime=0;this.diagnosticTime=0;this.valid=false;this.battleObservation=null;this.world=new MapPositionTracker()}
 async read(host,session,family,profile={}){
  this.family=family;this.valid=false;
  const read=async(address,length)=>unbase64((await host.gameRuntime.read(session,{ranges:[{address,length}]})).ranges[0].data);
  let iw=null;const length=family==='frlg'?0x8e0:32;
  const validPointer=p=>p>=0x02000000&&p+length<=0x02040000||p>=0x03000000&&p+length<=0x03008000;
  function parse(bytes) {
   let x=u16(bytes,0),y=u16(bytes,2),mapGroup=bytes[4],mapNumber=bytes[5];
   if(family==='frlg'){
    let best=null;
    for(let i=0;i<16;i++){const o=0x6a0+i*0x24;if(!(bytes[o]&1)||!(bytes[o+2]&1)||!bytes[o+5]||bytes[o+6]>96)continue;
     const tx=u16(bytes,o+16),ty=u16(bytes,o+18),group=bytes[o+10],number=bytes[o+9];
     if(tx<1||tx>255||ty<1||ty>255||group>63||number>127)continue;
     const score=(bytes[o+1]&128?-100:0)+Math.abs(tx-7)+Math.abs(ty-7);
     if(!best||score<best.score)best={x:tx,y:ty,mapGroup:group,mapNumber:number,score};
    }
    if(best)({x,y,mapGroup,mapNumber}=best);
   }
   return x>0&&x<=255&&y>0&&y<=255&&mapGroup<=63&&mapNumber<=127?{valid:true,gamePresence:family,mapGroup,mapNumber,tileX:x,tileY:y}:null;
  }
  let state=null;
  const parseObject=(objects,o)=>{
   const x=u16(objects,o+16),y=u16(objects,o+18),group=objects[o+10],number=objects[o+9];
   if((objects[o]&1)&&(objects[o+1]&128)&&(objects[o+2]&1)&&objects[o+4]<64&&objects[o+8]===255&&objects[o+6]<=96&&x>0&&x<=511&&y>0&&y<=511&&group<=63){
    this.spriteId=objects[o+4];return {valid:true,gamePresence:family,mapGroup:group,mapNumber:number,tileX:x,tileY:y};
   }
   return null;
  };
  const addresses=[this.objectAddress,profile.objectAddress,...(family==='frlg'?[0x02036e38,0x02036e40,0x02036e48]:family==='rs'?[0x030048a0,0x030048b0]:[0x02037350,0x02036ff0])].filter(Boolean);
  for(const address of [...new Set(addresses)]){state=parseObject(await read(address,36),0);if(state){this.objectAddress=address;break}}
  if(!state)iw=await read(0x03000000,0x8000);
  const candidates=state?[]:[family==='emerald'?0x5d8c:0x5008,0x5008,0x500c,0x5d8c].map(o=>u32(iw,o));if(this.pointer)candidates.push(this.pointer);
  for(const pointer of state?[]:[...new Set(candidates)]){if(!validPointer(pointer))continue;state=parse(await read(pointer,length));if(state){this.pointer=pointer;break}}
  if(!state){
   const ram=new Uint8Array(0x40000);
   for(let at=0;at<ram.length;at+=32768)ram.set(await read(0x02000000+at,32768),at);
   for(const [bytes,base] of [[ram,0x02000000],[iw,0x03000000]]){for(let at=0;at<=bytes.length-36;at+=4){state=parseObject(bytes,at);if(state){this.objectAddress=base+at;break}}if(state)break}
   for(let at=0;!state&&at<=iw.length-4;at+=4){const p=u32(iw,at);if(!validPointer(p))continue;const bytes=p>=0x03000000?iw.subarray(p-0x03000000,p-0x03000000+length):ram.subarray(p-0x02000000,p-0x02000000+length);state=parse(bytes);if(state){this.pointer=p;break}}
  }
  if(state&&family==='frlg'){const header=await read(0x02036dfc,28),layout=u16(header,18);if(layout>0&&layout<4096){state.mapGroup=0x70|((layout>>>8)&15);state.mapNumber=layout&255}}
  if(!state)return {valid:false};const spriteBase=family==='frlg'?0x0202063c:family==='rs'?0x02020004:0x02020630;const result=await host.gameRuntime.read(session,{ranges:[{address:0x04000000,length:32},{address:0x05000200,length:512},{address:0x06010000,length:32768},{address:0x07000000,length:1024},{address:spriteBase+this.spriteId*68,length:8}]});const [io,palette,vram,oam,softwareSprite]=result.ranges.map(r=>unbase64(r.data));const sprite=captureSprite(oam,vram,palette,u16(io,0),{attr0:u16(softwareSprite,0),attr1:u16(softwareSprite,2),attr2:u16(softwareSprite,4)});this.sprite=sprite;
  let direction=this.last?.direction??2;if(this.last&&state.mapGroup===this.last.mapGroup&&state.mapNumber===this.last.mapNumber){const dx=state.tileX-this.last.tileX,dy=state.tileY-this.last.tileY;if(Math.abs(dx)>Math.abs(dy))direction=dx<0?3:dx>0?4:direction;else if(dy)direction=dy<0?1:2}
  const footX=sprite?.footX??120,footY=sprite?.footY??88;let worldPixelX=-1,worldPixelY=-1;
  if(family==='frlg'){
   this.scrollX=u16(io,0x14)&255;this.scrollY=u16(io,0x16)&255;
   const point=this.world.track(state,this.scrollX,this.scrollY,footX,footY);worldPixelX=point.x;worldPixelY=point.y;
  }
  state={...state,positionProtocol:family==='frlg'?'map-pixels-v2':'tiles-v1',direction,worldPixelX,worldPixelY,cameraX:this.scrollX??0,cameraY:this.scrollY??0,playerScreenX:Math.max(0,Math.min(1,footX/240)),playerScreenY:Math.max(0,Math.min(1,footY/160)),spritePngBase64:sprite?.image??'',spriteWidth:sprite?.width??0,spriteHeight:sprite?.height??0,moving:!!this.last&&(Math.abs(this.last.worldPixelX-worldPixelX)>.1||Math.abs(this.last.worldPixelY-worldPixelY)>.1||this.last.tileX!==state.tileX||this.last.tileY!==state.tileY),battleScreen:false};if(Date.now()-this.battleTime>=1000){try{this.battleObservation=await screenSnapshot(host,session);this.battle=this.battleObservation.battleScreen&&!sprite?.overworld;this.battleObservation={...this.battleObservation,battleScreen:this.battle,overworldSprite:!!sprite?.overworld};this.battleTime=Date.now()}catch{}}state.battleScreen=this.battle;this.last=state;this.valid=true;return state
 }
 async diagnose(host,peers,nodes){
  const now=Date.now();if(now-this.diagnosticTime<2000)return;this.diagnosticTime=now;
  const minimal=p=>p?Object.fromEntries(['positionProtocol','valid','gamePresence','mapGroup','mapNumber','tileX','tileY','worldPixelX','worldPixelY','cameraX','cameraY','battleScreen','spriteWidth','spriteHeight','updatedAtMs'].filter(k=>k in p).map(k=>[k,p[k]])):null;
  const entry={time:now,valid:this.valid,local:minimal(this.last),battle:this.battleObservation,received:peers.length,drawn:nodes.length,visibleAtCapture:nodes.filter(n=>{const x=n.x-(n.camera?.x??0),y=n.y-(n.camera?.y??0);return x>-n.width&&x<240+n.width&&y>-n.height&&y<160+n.height}).length,peers:peers.map(p=>({state:minimal(p),reason:!this.last?'no-local-state':this.last.battleScreen?'local-battle':p.gamePresence!==this.last.gamePresence?'different-game':p.mapGroup!==this.last.mapGroup||p.mapNumber!==this.last.mapNumber?'different-map':p.battleScreen?'remote-battle':'drawn'}))};
  try{const d=await host.storage.read('presence-diagnostics');await host.storage.compareAndSwap('presence-diagnostics',d.revision,{latest:entry,history:[...(d.value?.history??[]).slice(-23),entry]})}catch{}
 }
 render(peers){
  const local=this.last;if(!local||!this.valid||local.battleScreen)return [];
  return peers.filter(p=>p.gamePresence===local.gamePresence&&p.mapGroup===local.mapGroup&&p.mapNumber===local.mapNumber&&!p.battleScreen).slice(0,16).map(p=>{
   const pixels=local.positionProtocol==='map-pixels-v2'&&p.positionProtocol==='map-pixels-v2'&&Number.isFinite(p.worldPixelX)&&Number.isFinite(p.worldPixelY);
   let x=local.playerScreenX*240+(pixels?p.worldPixelX-local.worldPixelX:(p.tileX-local.tileX)*16);
   let y=local.playerScreenY*160+(pixels?p.worldPixelY-local.worldPixelY:(p.tileY-local.tileY)*16);
   const camera=local.gamePresence==='frlg'?{xAddress:0x04000014,yAddress:0x04000016,x:local.cameraX,y:local.cameraY,modulus:256}:null;
   if(camera){x+=camera.x;y+=camera.y}
   return {id:String(p.peerId??p.displayName??''),x,y,...(camera?{camera}:{}),width:Math.max(1,Math.min(128,Number(p.spriteWidth)||16)),height:Math.max(1,Math.min(128,Number(p.spriteHeight)||32)),image:typeof p.spritePngBase64==='string'&&p.spritePngBase64.length<=32768&&p.spritePngBase64.startsWith('iVBORw0KGgo')?p.spritePngBase64:'',label:String(p.displayName??'').slice(0,64)};
  });
 }
}
