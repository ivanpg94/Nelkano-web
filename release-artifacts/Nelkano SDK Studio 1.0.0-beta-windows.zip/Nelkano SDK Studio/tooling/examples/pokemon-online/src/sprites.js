import {zlib} from './deflate.js';
import {base64,unbase64,u16,u32} from './binary.js';
const sizes=[[8,8,16,16,32,32,64,64],[16,8,32,8,32,16,64,32],[8,16,8,32,16,32,32,64]];
const be=n=>[(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255];
function crc(bytes){let c=-1;for(const b of bytes){c^=b;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (c^-1)>>>0}
function chunk(name,data){const type=Array.from(name,c=>c.charCodeAt(0));return [...be(data.length),...type,...data,...be(crc([...type,...data]))]}
export function indexedPng(width,height,pixels,palette){const raw=[];for(let y=0;y<height;y++){raw.push(0);for(let x=0;x<width;x++)raw.push(pixels[y*width+x])}const z=zlib(raw);const rgb=palette.flatMap(c=>[(c>>>16)&255,(c>>>8)&255,c&255]),alpha=palette.map((_,i)=>i===0?0:255);return base64(Uint8Array.from([137,80,78,71,13,10,26,10,...chunk('IHDR',[...be(width),...be(height),8,3,0,0,0]),...chunk('PLTE',rgb),...chunk('tRNS',alpha),...chunk('IDAT',z),...chunk('IEND',[])]))}
export function captureSprite(oam,vram,palette,display,preferred=null){const oneDim=!!(display&64);let best=null;for(let i=0;i<128;i++){const a=u16(oam,i*8),b=u16(oam,i*8+2),c=u16(oam,i*8+4);if(!(a&0x0100)&&(a&0x0200)||((a>>>10)&3)>=2)continue;const shape=a>>>14,size=b>>>14;if(shape>=3)continue;const [w,h]=sizes[shape].slice(size*2,size*2+2);let x=b&511,y=a&255;if(x>=240)x-=512;if(y>=160)y-=256;if(x+w<=0||x>=240||y+h<=0||y>=160)continue;const color256=!!(a&0x2000),bank=(c>>>12)&15,base=c&1023,indices=new Uint8Array(w*h);let opaque=0;for(let py=0;py<h;py++)for(let px=0;px<w;px++){const fx=b&0x1000?w-1-px:px,fy=b&0x2000?h-1-py:py,tile=base+Math.floor(fy/8)*(oneDim?(w/8)*(color256?2:1):32)+Math.floor(fx/8)*(color256?2:1),offset=tile*32+(fy%8)*(color256?8:4)+Math.floor((fx%8)/(color256?1:2));const val=vram[offset]??0;const index=color256?val:((val>>>((fx&1)*4))&15);indices[py*w+px]=index;if(index)opaque++}if(opaque<8)continue;const footX=x+w*.5,footY=y+h*.86,dx=footX-120,dy=footY-88;const preferredScore=preferred&&a===preferred.attr0&&b===preferred.attr1?-1000000-(c===preferred.attr2?500000:0):0;const score=preferredScore+dx*dx*.45+dy*dy*.18+(w>32||h>32?260:0)+(a&0x0100?180:0)+(w>=16&&w<=32&&h>=24&&h<=32?-220:0)+(footY<74?420:0)-(footY>=88?Math.min(220,(footY-88)*7.5):0);if(!best||score<best.score){const colors=[];for(let j=0;j<(color256?256:16);j++){const col=u16(palette,(color256?j:bank*16+j)*2);const red=((col&31)<<3)|((col&31)>>>2),green=(((col>>>5)&31)<<3)|(((col>>>5)&31)>>>2),blue=(((col>>>10)&31)<<3)|(((col>>>10)&31)>>>2);colors.push((red<<16)|(green<<8)|blue)}best={score,width:w,height:h,footX,footY,pixels:indices,palette:colors,overworld:preferredScore<0&&w>=16&&w<=32&&h===32&&!(a&0x0100)}}}if(best){let minX=best.width,minY=best.height,maxX=-1,maxY=-1;for(let y=0;y<best.height;y++)for(let x=0;x<best.width;x++)if(best.pixels[y*best.width+x]){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y)}const width=maxX-minX+1,height=maxY-minY+1,pixels=new Uint8Array(width*height);for(let y=0;y<height;y++)pixels.set(best.pixels.subarray((minY+y)*best.width+minX,(minY+y)*best.width+minX+width),y*width);best={...best,width,height,pixels,image:indexedPng(width,height,pixels,best.palette)}}return best}

/** Same battle colour tests as the old client, sampled at half resolution. */
export async function screenSnapshot(host,session){
 const frame=await host.gameRuntime.frame(session,{width:120,height:80}),bytes=unbase64(frame.argb);
 let red=0,bright=0,white=0,pale=0,dark=0;
 for(let y=0;y<80;y++)for(let x=0;x<120;x++){
  const rgb=u32(bytes,(y*120+x)*4)&0xffffff,r=rgb>>>16,g=(rgb>>>8)&255,b=rgb&255;
  if(y>=48){if(r>140&&g<130&&b<125)red++;if(r>210&&g>210&&b>180)bright++;if(x>=73&&y>=56&&r>205&&g>205&&b>190)white++;if(r<90&&g<90&&b<120)dark++}
  if(y>=10&&y<48&&r>170&&g>210&&b>150)pale++;
 }
 return {battleScreen:red>87&&bright>112&&dark>30||red>45&&white>225&&pale>875,counts:{red,bright,white,pale,dark}};
}
