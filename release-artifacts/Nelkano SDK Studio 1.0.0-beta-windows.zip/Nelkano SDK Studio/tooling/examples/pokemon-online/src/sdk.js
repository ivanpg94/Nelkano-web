// Online is opened from emulator settings; it does not add buttons over the game.
import {base64,unbase64,utf8,text} from './binary.js';
import {sha256} from './hash.js';
import {resolveProfile} from './profiles.js';
import {RomView,SpeciesCatalog,overworld,trainerFront,trainerBack} from './rom-assets.js';
import {PokemonPresence} from './presence.js';
import {stateLayout,extract,applyReturn,decodePokemon} from './gen3.js';
const id='nelkano.pokemon-online',gba='nelkano.gba-online';
const action=(label,actionId,payload={},extra={})=>({label,actionId,payload,submitFields:false,...extra});
export function createModule(host){let profile=null,profileSession='',presence=new PokemonPresence(),origin=null,active=false,lastState=null;
 async function identify(v){const library=await host.library.list(),game=library.find(g=>g.id===v.gameId);if(!game)return {compatible:false};if(v.systemId==='rpgmaker'){const n=game.title.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[_-]+/g,' ');return {compatible:n.includes('pokemon nelkano'),compatibilityKey:'pokemon-nelkano-rpgmaker',transportSystem:'rpgmaker'}}if(v.systemId!=='gba')return {compatible:false};if(profileSession!==v.session.id+':'+v.session.generation){const header=unbase64((await host.gameRuntime.rom(v.session,{offset:0xa0,length:16})).data);profile=resolveProfile(game.id,header);profileSession=v.session.id+':'+v.session.generation;presence=new PokemonPresence()};return {compatible:!!profile,compatibilityKey:profile?.compatibilityKey??'',transportSystem:'gba'}}
 async function readCheckpoint(c){const bytes=new Uint8Array(c.size);for(let offset=0;offset<c.size;offset+=32768){const value=await host.gameRuntime.checkpointRead({checkpointId:c.checkpointId,offset,length:Math.min(32768,c.size-offset)});bytes.set(unbase64(value.data),offset)}return bytes}
 async function writeProject(gameId,path,bytes){for(let offset=0;offset<bytes.length;offset+=32768)await host.gameRuntime.projectWrite({gameId,path,data:base64(bytes.slice(offset,offset+32768)),offset,final:offset+32768>=bytes.length})}
 async function readProject(gameId,path){const first=await host.gameRuntime.projectRead({gameId,path,offset:0,length:32768}),bytes=new Uint8Array(first.size);bytes.set(unbase64(first.data));for(let offset=32768;offset<bytes.length;offset+=32768)bytes.set(unbase64((await host.gameRuntime.projectRead({gameId,path,offset,length:Math.min(32768,bytes.length-offset)})).data),offset);return bytes}
 async function ensureWorldImport(current,verify=false){
  if(!origin||current?.gameId!==origin.targetGameId||current.systemId!=='rpgmaker')return false;
  if(!(await host.gameRuntime.projectActive(current.session,{gameId:origin.targetGameId})).active)return false;
  if(origin.pendingImport===false&&!verify)return true;
  const matches=async()=>{const value=await host.gameRuntime.invoke(current.session,{receiver:'NelkanoBridge',method:'origin_metadata'});return /[\"]sessionId[\"]\s*(?:=>|:)\s*[\"]([^\"]+)[\"]/.exec(value.result)?.[1]===origin.sessionId};
  if(!await matches()){
   const imported=await host.gameRuntime.invoke(current.session,{receiver:'NelkanoBridge',method:'import_pending_session'});
   if(imported.result!=='true'||!await matches())return false;
  }
  const stored=await host.storage.read('origin');
  if(stored.value?.sessionId!==origin.sessionId)throw Error('El traslado ha cambiado');
  origin={...origin,pendingImport:false};
  if(!await host.storage.compareAndSwap('origin',stored.revision,origin))throw Error('El traslado ha cambiado');
  await host.gameRuntime.subscribe(current.session,false);return true;
 }
 async function goWorld(){
  const current=await host.emulation.snapshot();
  if(!current||current.systemId!=='gba'||!(await identify({session:current.session,gameId:current.gameId,systemId:current.systemId})).compatible)
   throw Error('Inicia una partida Pokémon GBA compatible');
  const games=await host.library.list();
  const targetGame=games.find(g=>g.systemId==='rpgmaker'&&g.title.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[_-]+/g,' ').includes('pokemon nelkano'));
  if(!targetGame)throw Error('Importa primero el proyecto Pokémon Nelkano en la biblioteca');
  if(profile.family==='rs')throw Error('Este perfil admite presencia Online; el traslado al mundo todavía no está disponible');
  const wasPaused=current.paused;await host.emulation.setPaused(current.session,true);
  try{
   const checkpoint=await host.gameRuntime.checkpoint(current.session),state=await readCheckpoint(checkpoint),layout=stateLayout(state);
   const ram=state.slice(layout.ewramOffset,layout.ewramOffset+0x40000),iwram=state.slice(layout.iwramOffset,layout.iwramOffset+0x8000);
   const header=await host.gameRuntime.rom(current.session,{offset:0xa0,length:16}),rom=new RomView(host,current.session,header.size);
   const catalog=await SpeciesCatalog.read(rom),decoded=extract(ram,iwram,profile.family,catalog);
   const source=games.find(g=>g.id===current.gameId),sessionId=Date.now().toString(16);
   const document={schemaVersion:1,sessionId,origin:{system:'gba',family:profile.family,romName:source.title,romHash:source.id,sessionId},trainer:decoded.trainer,party:decoded.party,originStorage:decoded.originStorage,returnCompatibility:decoded.returnCompatibility,extraction:{...decoded.extraction,profileId:profile.id??'',family:profile.family,confidence:catalog?'exact':'standard_assumed',partyOffset:decoded.partyOffset,storageOffset:decoded.storage?.offset??-1}};
   const anchor=await presence.read(host,current.session,profile.family);
   const visual=anchor.valid?await overworld(rom,ram,anchor):null;
   if(visual){
    const digest=sha256(unbase64(visual.image)),visualId='g3p-'+digest.slice(0,24),charset='nelkano_origin_'+digest.slice(0,12);
    const {image,...metadata}=visual;
    document.trainer.originVisual={...metadata,visualId,charset,pngBase64:image,romHash:source.id,profileId:profile.id??'',family:profile.family,variant:'ON_FOOT',confidence:'exact'};
    document.trainer.originSprite=document.trainer.originVisual;
    await writeProject(targetGame.id,'Graphics/Characters/'+charset+'.png',unbase64(image));
   }
   const rocket=(source.title+' '+(profile.label??'')).toLowerCase().replace(/\s/g,'').includes('teamrocket');
   const front=rocket?null:await trainerFront(rom,profile,decoded.trainer.gender),back=await trainerBack(rom,profile,rocket?0:decoded.trainer.gender);
   for(const [value,key,prefix]of [[front,'originBattleVisual','nelkano_battle_'],[back,'originBattleBackVisual','nelkano_battle_back_']]){
    if(!value)continue;
    const {image,...metadata}=value,visualId=(key==='originBattleVisual'?'g3bf-':'g3bb-')+sha256(unbase64(image)).slice(0,24);
    document.trainer[key]={...metadata,visualId,pngBase64:image,romHash:source.id,profileId:profile.id??'',family:profile.family,confidence:'exact'};
    const bytes=unbase64(image);
    await writeProject(targetGame.id,'Graphics/Trainers/'+prefix+visualId+'.png',bytes);
    await writeProject(targetGame.id,'Save/Graphics/Trainers/'+prefix+visualId+'.png',bytes);
   }
   await writeProject(targetGame.id,'Save/nelkano_session.json',utf8(JSON.stringify(document)));
   origin={pendingImport:true,checkpoint,sourceGameId:current.gameId,targetGameId:targetGame.id,family:profile.family,sessionId,catalog:catalog?{names:catalog.names,firstTwo:catalog.firstTwo,standard:catalog.standard}:null};
   const old=await host.storage.read('origin');
   if(!await host.storage.compareAndSwap('origin',old.revision,origin))throw Error('La sesión de traslado ha cambiado');
   await host.gameRuntime.projectLaunch({gameId:targetGame.id});
   const world=await host.emulation.snapshot();await host.gameRuntime.subscribe(world.session,true);await ensureWorldImport(world);
   return {kind:'close-panel'};
  }catch(e){
   if((await host.emulation.snapshot())?.session.id===current.session.id&&!wasPaused)await host.emulation.setPaused(current.session,false);
   throw e;
  }
 }
 async function returnGba(){origin=(await host.storage.read('origin')).value;if(!origin)throw Error('No hay una partida GBA de origen');const current=await host.emulation.snapshot();if(!current||current.gameId!==origin.targetGameId)throw Error('Abre primero el mundo Pokémon Nelkano de esta sesión');if(!await ensureWorldImport(current,true))throw Error('El mundo está preparando la partida. Espera unos segundos y vuelve a intentarlo.');const prepared=await host.gameRuntime.invoke(current.session,{receiver:'NelkanoBridge',method:'prepare_return_data'});if(prepared.result!=='true')throw Error('El mundo no pudo preparar el retorno. Revisa el equipo y el banco Nelkano.');const saved=await host.gameRuntime.invoke(current.session,{receiver:'Game',method:'save'});if(saved.result!=='true')throw Error('No se pudo guardar el mundo antes de volver');const returned=JSON.parse(text(await readProject(origin.targetGameId,'Save/nelkano_return.json')));if((returned.sessionId??returned.origin?.sessionId)!==origin.sessionId)throw Error('El retorno pertenece a otra sesión');const state=await readCheckpoint(origin.checkpoint),layout=stateLayout(state),ram=state.slice(layout.ewramOffset,layout.ewramOffset+0x40000),decoded=extract(ram,state.slice(layout.iwramOffset,layout.iwramOffset+0x8000),origin.family,origin.catalog?new SpeciesCatalog(origin.catalog):null),next=applyReturn(ram,decoded,returned,origin.family,origin.catalog?new SpeciesCatalog(origin.catalog):null);let checkpoint=origin.checkpoint;for(let offset=0;offset<next.length;offset+=32768){const before=ram.slice(offset,offset+32768),after=next.slice(offset,offset+32768);if(before.some((v,i)=>v!==after[i]))checkpoint=await host.gameRuntime.checkpointPatch({checkpointId:checkpoint.checkpointId,offset:layout.ewramOffset+offset,data:base64(after),expected:base64(before)})};await host.library.launch(origin.sourceGameId);const source=await host.emulation.snapshot();await host.emulation.setPaused(source.session,true);try{await host.gameRuntime.restore(source.session,checkpoint);await host.emulation.setPaused(source.session,false)}catch(e){await host.gameRuntime.restore(source.session,origin.checkpoint);throw e};return {kind:'close-panel'}}
 async function panel(){const current=await host.emulation.snapshot();const value=current?await identify({session:current.session,gameId:current.gameId,systemId:current.systemId}):{compatible:false};return {kind:'panel',title:'Pokémon Online',message:value.compatible?'':'Inicia una partida Pokémon compatible',fields:[],rows:[],actions:current?.systemId==='rpgmaker'?[action('Volver a la partida GBA','return'),action('Cerrar','close')]:[action('Abrir Pokémon Nelkano','world',{}, {primary:true}),action('Cerrar','close')]}}
 return {async activate(){active=true;origin=(await host.storage.read('origin')).value;await host.hooks.contribute(gba,'game-adapters','pokemon',{label:'Pokémon Gen 3'});await host.hooks.contribute(gba,'events','pokemon',{})},async deactivate(){active=false;const s=await host.emulation.snapshot();if(s)await host.gameRuntime.overlay(s.session,[])},async contributions(c){if(!active||c.surface!=='emulation'||!c.session)return [];const running=await host.emulation.snapshot();if(!running||running.session.id!==c.session.id||running.session.generation!==c.session.generation)return [];if(c.systemId==='rpgmaker'&&(origin?.targetGameId!==c.gameId||!(await host.gameRuntime.projectActive(c.session,{gameId:c.gameId})).active))return [];if(!(await identify({session:c.session,gameId:c.gameId,systemId:c.systemId})).compatible||profile?.family==='rs')return [];return [{moduleId:id,id:'world',slot:'EMULATION_SETTINGS_SECTION',label:c.systemId==='gba'?'Pokémon Nelkano':'Volver a GBA',actionId:'open',icon:'assets/online.png',section:'CONEXIONES'}]},async dispatch(name){if(name==='close')return {kind:'close-panel'};if(name==='world')return goWorld();if(name==='return')return returnGba();return panel()},async onEvent(e){if(e.type==='runtime-tick'||e.type==='session-started'){const current=await host.emulation.snapshot();if(origin&&current?.gameId===origin.targetGameId&&current.systemId==='rpgmaker'&&origin.pendingImport!==false){if(e.type==='session-started')await host.gameRuntime.subscribe(current.session,true);await ensureWorldImport(current)}}if(e.type==='session-reset'||e.type==='save-loaded'){profileSession='';presence=new PokemonPresence()}},async onHook(r){if(r.hook==='game-adapters'){if(r.operation==='identify')return identify(r.value);if(r.operation==='capture'){if(r.value.systemId==='rpgmaker')return {valid:await ensureWorldImport(await host.emulation.snapshot()),gamePresence:'',mapGroup:-1,mapNumber:-1,tileX:-1,tileY:-1};lastState=await presence.read(host,r.value.session,profile.family,profile);for(const c of await host.hooks.list(id,'pokemon-events'))try{await host.hooks.invokeContributor('pokemon-events',c.moduleId,c.id,'changed',{state:lastState,profileId:profile.id??profile.family})}catch{};return lastState};if(r.operation==='messages')return {};if(r.operation==='render'){const current=await host.emulation.snapshot();const nodes=current?.systemId==='gba'?presence.render(r.value.peers):[];await host.gameRuntime.overlay(r.value.session,nodes);if(current?.systemId==='gba')await presence.diagnose(host,r.value.peers,nodes);return {}}}if(r.hook==='events')return {};if(r.hook==='pokemon-state'){if(r.operation==='snapshot')return {profile,state:lastState};if(r.operation==='party'){const current=await host.emulation.snapshot();if(profile?.family==='rs')throw Error('La lectura del equipo no está disponible para este perfil');if(current?.systemId!=='gba'||!profile)throw Error('No hay una partida Pokémon GBA');const address=0x02000000+(profile.family==='emerald'?0x244ec:0x24284),bytes=unbase64((await host.gameRuntime.read(current.session,{ranges:[{address,length:600}]})).ranges[0].data),party=[];for(let i=0;i<6;i++){const p=decodePokemon(bytes,i*100,true);if(!p)break;party.push(p)}return {party}}}throw Error('Gancho no disponible')}}
}
