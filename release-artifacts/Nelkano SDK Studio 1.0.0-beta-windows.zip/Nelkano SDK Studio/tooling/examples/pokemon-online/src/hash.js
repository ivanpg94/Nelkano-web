const rotate=(value,n)=>(value>>>n)|(value<<(32-n));
const primes=[];for(let n=2;primes.length<64;n++){if(primes.every(p=>p*p>n||n%p))primes.push(n)}
const k=Uint32Array.from(primes,p=>(Math.cbrt(p)%1)*0x100000000);
const initial=Uint32Array.from(primes.slice(0,8),p=>(Math.sqrt(p)%1)*0x100000000);
export function sha256(bytes){
 const n=Math.ceil((bytes.length+9)/64)*64,input=new Uint8Array(n);input.set(bytes);input[bytes.length]=128;
 const view=new DataView(input.buffer);view.setUint32(n-8,Math.floor(bytes.length/0x20000000));view.setUint32(n-4,(bytes.length*8)>>>0);
 const hash=initial.slice(),words=new Uint32Array(64);
 for(let at=0;at<n;at+=64){
  for(let i=0;i<16;i++)words[i]=view.getUint32(at+i*4);
  for(let i=16;i<64;i++){const a=words[i-15],b=words[i-2];words[i]=(words[i-16]+(rotate(a,7)^rotate(a,18)^(a>>>3))+words[i-7]+(rotate(b,17)^rotate(b,19)^(b>>>10)))>>>0}
  let [a,b,c,d,e,f,g,h]=hash;
  for(let i=0;i<64;i++){const t=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^((~e)&g))+k[i]+words[i])>>>0,u=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t)>>>0;d=c;c=b;b=a;a=(t+u)>>>0}
  [a,b,c,d,e,f,g,h].forEach((v,i)=>hash[i]=(hash[i]+v)>>>0);
 }
 return Array.from(hash,x=>x.toString(16).padStart(8,'0')).join('');
}
