# Pokémon Online

Módulo opcional `nelkano.pokemon-online`, versión 0.1.0, SDK 0.2.0. Requiere GBA Online y, a través de él, Amigos. No viene dentro de la APK.

La lectura Pokémon, mapas, sprites, equipo, PC y retorno están en JavaScript dentro de este módulo. Android y Desktop aportan accesos genéricos a la sesión y al core.

## Usarlo

Importa GBA Online y después Pokémon Online. Abre una ROM compatible de Esmeralda o Rojo Fuego/Verde Hoja. Ajustes de emulación → CONEXIONES → GBA Online conecta con tu amigo. Cada jugador sigue ejecutando su ROM; se comparten presencia y mensajes. No es cable link.

Para entrar al mundo importa el proyecto Pokémon Nelkano en la biblioteca y abre Ajustes de emulación → CONEXIONES → Pokémon Nelkano. Se conserva una copia del estado GBA y se prepara una copia privada del proyecto, con entrenador, equipo, PC y gráficos. El módulo confirma que el mundo ha importado la sesión y que sigue en su copia privada. Volver a GBA, en los ajustes de emulación del mundo, prepara los datos actuales del mundo, guarda su banco y restaura GBA aplicando los cambios compatibles. El checkpoint original se conserva.

## Ganchos

Consume game-adapters, sessions y events de GBA Online. Publica:

- pokemon-state/snapshot: perfil y última presencia leída.
- pokemon-state/party: equipo de la partida GBA actual.
- pokemon-events: aportaciones reciben changed con state y profileId.

Un módulo que lea o altere directamente memoria debe declarar sus permisos. Las referencias id/generation antiguas y las escrituras con bytes esperados distintos se rechazan.

## Desarrollo y límites

`npx nelkmod example pokemon-online mi-pokemon-online` copia las fuentes. Carga Amigos, GBA Online y Pokémon Online en Studio. El visor usa un entrenador, equipo y mundo ficticios; no ejecuta ROMs ni Ruby ni conecta al servidor.

Los formatos y reglas se han trasladado del código conservado en modules/online. La comparación offline de Esmeralda y Rojo Fuego españoles da el mismo catálogo y los mismos píxeles en los cinco gráficos del oráculo. Esto no certifica todos los hacks ni el juego online completo.

La app anterior permanece intacta. No se incluyen ROMs ni el proyecto Pokémon Nelkano en el paquete. Receta de firma: src/nelkano/sdk/tooling/package-online.mjs; oráculos: scripts/qa/OnlineModuleOracle.java y scripts/qa/online-asset-parity.mjs.

Rojo Fuego/Verde Hoja proyecta los jugadores remotos desde coordenadas de mundo. La cámara se corrige con los registros GBA de cada fotograma, sin esperar a otro paquete de red. Las posiciones remotas se interpolan durante 100 ms; no se manda una captura de pantalla en cada presencia.
