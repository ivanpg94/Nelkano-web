# Parches

SDK 0.2.0, módulo 0.1.0. IPS y VCDIFF/xdelta para GBA/NDS: el motor nativo reutiliza modules/rompatch. Publica una copia en la biblioteca y conserva la ROM original. No hay soporte BPS, UPS ni PPF.

Permisos resources.patch, library.read y modules.hooks. Puerto host.patches.pick()/apply(). Referencias privadas por módulo, diez minutos de validez, máximo 64 MiB por parche.

Gancho apply-patch 1.0.0: formats y apply({gameId,title?}); apply abre el selector bajo el propietario Parches. No acepta referencias de otro módulo. Studio simula solo el formulario/selector y rechaza aplicar binarios. Libro local: /sdk-de-nelkano/parches.
