export const moduleId='nelkano.patches';
export function createModule(host){let active=false,selection=null;
 async function form(query=''){
  const games=(await host.library.list()).filter(g=>['gba','nds'].includes(g.systemId)).sort((a,b)=>a.title.toLowerCase().localeCompare(b.title.toLowerCase()));
  if(!games.length)throw Error('Importa primero el juego NDS o GBA original.');
  const visible=games.filter(g=>g.title.toLowerCase().includes(query.toLowerCase()));
  return {kind:'panel',id:'patch-game-picker',title:'Selecciona el juego a parchear',text:(selection?.name||'')+'\n\nSelecciona el juego original. Se añadirá una copia parcheada a la biblioteca.\n\nIPS no permite verificar la ROM original. Elige la versión exacta del juego que requiere el parche.',
   fields:[{id:'query',label:'Buscar juegos NDS o GBA',kind:'text',initial:query,onChangeAction:'search',onChangeMinLength:0}],
   rows:visible.map(g=>({id:g.id,presentation:'list',label:g.title+' ['+g.systemId.toUpperCase()+']',actions:[{actionId:'apply',label:'Seleccionar',payload:{gameId:g.id},submitFields:false}]})),
   actions:[{actionId:'close',label:'Cancelar',placement:'footer',submitFields:false}]};
 }
 async function apply(v){if(!selection)throw Error('Selecciona el parche');return host.patches.apply({gameId:v.gameId,resourceId:selection.resourceId,...(v.title?.trim()?{title:v.title.trim()}:{})});}
 return {activate:async()=>{active=true},deactivate:async()=>{active=false;selection=null},contributions:async c=>!active?[]:c.surface==='settings'?[{moduleId,id:'patches',slot:'SETTINGS_SECTION',section:'Biblioteca',label:'Parches',description:'Crear una copia modificada con IPS o xdelta',actionId:'open'}]:c.surface==='game'&&['gba','nds'].includes(c.systemId)?[{moduleId,id:'patch-game',slot:'GAME_LAUNCH_ACTION',label:'Aplicar parche',actionId:'open'}]:[],dispatch:async(a,v={},c)=>{
  if(a==='close'){selection=null;return {kind:'close-panel'}}
  if(a==='search')return form(v.query||'');
  if(a==='apply'){await apply(v);selection=null;return {kind:'close-panel'}}
  const result=await host.patches.pick();
  if(result.cancelled)return {kind:'close-panel'};
  selection=result;return form();
 },onHook:async r=>{if(!active||r.hook!=='apply-patch')throw Error('hook-unavailable');if(r.operation==='formats')return {formats:['IPS','VCDIFF'],systems:['gba','nds'],createsCopy:true};if(r.operation==='apply'){const picked=await host.patches.pick();if(picked.cancelled)return {cancelled:true};return host.patches.apply({gameId:r.value.gameId,title:r.value.title,resourceId:picked.resourceId})};throw Error('unknown-hook-operation')},onEvent:async()=>null};}
