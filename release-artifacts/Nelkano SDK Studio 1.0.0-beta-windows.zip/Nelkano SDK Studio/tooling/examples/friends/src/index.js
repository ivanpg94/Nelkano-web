const copy=x=>JSON.parse(JSON.stringify(x));
const positive=x=>Number.isSafeInteger(x)&&x>0;
const str=(x,max=4000)=>{if(typeof x!=='string'||x.length>max)throw new Error('invalid-text');return x;};
export const moduleId='nelkano.friends';
export const avatarColors=Object.freeze(['#a414ff','#38bdf8','#22c55e','#f59e0b','#f43f5e']);
export function parseFriend(value){
 if(!value||!positive(value.uid))throw new Error('invalid-user');
 const field=(camel,snake)=>str(value[camel]??value[snake]??'');
 const friend={uid:value.uid,friendshipId:value.friendshipId??value.friendship_id??0,name:field('name'),email:field('email'),status:field('status'),displayName:field('displayName','display_name'),statusText:field('statusText','status_text'),avatarUrl:field('avatarUrl','avatar_url'),avatarColor:field('avatarColor','avatar_color'),initial:field('initial')};
 if(!Number.isSafeInteger(friend.friendshipId)||friend.friendshipId<0)throw new Error('invalid-friendship');
 friend.label=friend.displayName||friend.name||friend.email||`Usuario ${friend.uid}`;
 friend.avatarInitial=(friend.initial||friend.label||'?').substring(0,1).toUpperCase();
 friend.avatarColor=avatarColors.includes(friend.avatarColor.toLowerCase())?friend.avatarColor.toLowerCase():avatarColors[0];
 return friend;
}
function group(values){if(!Array.isArray(values)||values.length>10000)throw new Error('invalid-friends');const list=values.map(parseFriend);if(new Set(list.map(x=>x.uid)).size!==list.length)throw new Error('duplicate-users');return list;}
function snapshot(value){return {friends:group(value?.friends??[]),incoming:group(value?.incoming??[]),outgoing:group(value?.outgoing??[])};}
export function createModule(host){
 if(!host?.account?.snapshot||!host.account.updateDisplayName||!host.network?.request||!host.storage?.read||!host.storage.compareAndSwap||!host.clock?.now||!host.clock.schedule||!host.clock.cancel||!host.images?.read||!host.images.invalidate)throw new Error('missing-capability');
 let active=false,lifecycle=0,owner=null,lists={friends:[],incoming:[],outgoing:[]},loadedAt=null,revision=0,loadError='',search={query:'',users:[],loading:false,error:'',generation:0},timer=null,profile=null,refreshing=null,mutation=false;
 const now=()=>{const time=host.clock.now();if(!Number.isSafeInteger(time)||time<0)throw new Error('invalid-clock');return time;};
 async function cancelTimer(){if(timer){await host.clock.cancel(timer);timer=null;}}
 async function reset(){await cancelTimer();lists={friends:[],incoming:[],outgoing:[]};loadedAt=null;profile=null;loadError='';revision++;search={query:'',users:[],loading:false,error:'',generation:search.generation+1};}
 async function account(){
  const info=await host.account.snapshot();
  const next=positive(info?.uid)?info.uid:null;
  if(next!==owner){await reset();owner=next;}
  if(!next)throw new Error('login-required');if(info.friends!==true)throw new Error('permission-denied');return info;
 }
 async function request(method,path,body,uid){
  const epoch=lifecycle;const result=await host.network.request({method,path,body:body??null,accountUid:uid,timeoutMs:8000,maxResponseBytes:8*1024*1024});
  if(!active||epoch!==lifecycle||(await account()).uid!==uid)throw new Error('stale-account');
  if(!Number.isInteger(result?.status)||!result.body||typeof result.body!=='object'||Array.isArray(result.body))throw new Error('invalid-response');
  if(result.status<200||result.status>=300)throw new Error(typeof result.body.message==='string'?str(result.body.message):`HTTP ${result.status}`);
  return result.body;
 }
 async function persist(uid,data,time,invalidated=false){
  for(let i=0;i<4;i++){const doc=await host.storage.read(`friends-${uid}`);if(!Number.isSafeInteger(doc?.revision)||doc.revision<0)throw new Error('invalid-storage-response');const ok=await host.storage.compareAndSwap(`friends-${uid}`,doc.revision,{schemaVersion:1,owner:uid,loadedAt:time,invalidated,lists:copy(data)});if(ok===true)return;if(ok!==false)throw new Error('invalid-storage-response');}throw new Error('storage-conflict');
 }
 async function refresh(force=false){
  const uid=(await account()).uid;
  if(refreshing){if(refreshing.uid===uid)return refreshing.promise;throw new Error('refresh-pending');}
  const time=now();
  if(!force&&loadedAt!==null&&time>=loadedAt&&time-loadedAt<300000)return panel();
  if(!force&&loadedAt===null){
   const doc=await host.storage.read(`friends-${uid}`),value=doc?.value;
   if(value!==null&&value!==undefined){if(value.schemaVersion!==1||value.owner!==uid||!Number.isSafeInteger(value.loadedAt)||value.loadedAt<0)throw new Error('invalid-cache');const cached=snapshot(value.lists);
    if(value.invalidated!==true&&time>=value.loadedAt&&time-value.loadedAt<300000){lists=cached;loadedAt=value.loadedAt;revision++;return panel();}}
  }
  const promise=(async()=>{
   try{const data=snapshot(await request('GET','/api/nelkano/friends',null,uid));const timestamp=now();lists=data;loadedAt=timestamp;revision++;loadError='';
    try{await persist(uid,data,timestamp);}catch(error){loadError=`cache: ${error.message}`;}return panel();
   }catch(error){loadError=error.message;throw error;}finally{refreshing=null;}
  })();refreshing={uid,promise};return promise;
 }
 function row(friend,actions){return {...copy(friend),avatar:{url:friend.avatarUrl,initial:friend.avatarInitial,color:friend.avatarColor},actions:actions.map(action=>({actionId:action,payload:{uid:friend.uid,revision}}))};}
 function panel(language='en'){
  return {kind:'friends-page',title:language==='es'?'Amigos':'Friends',revision,loadedAt,error:loadError,loading:!!refreshing,
   sections:[{id:'friends',items:lists.friends.map(f=>row(f,['remove']))},{id:'incoming',items:lists.incoming.map(f=>row(f,['accept','reject']))},{id:'outgoing',items:lists.outgoing.map(f=>row(f,['cancel']))}],
   search:{...copy(search),users:search.users.map(f=>row(f,['invite']))},profileAction:'profile-open'};
 }
 async function schedule(query){
  await account();const safe=str(query,256).trim(),previous=timer;timer=null;const generation=search.generation+1;search={query:safe,users:[],loading:safe.length>=2,error:'',generation};
  if(previous)await host.clock.cancel(previous);
  if(generation!==search.generation||!active)return {ignored:true};
  if(safe.length>=2){const next=await host.clock.schedule({moduleId,afterMs:350,generation});if(typeof next!=='string'||!next)throw new Error('invalid-timer');if(generation!==search.generation||!active){await host.clock.cancel(next);return {ignored:true};}timer=next;}return panel();
 }
 async function runSearch(generation){
  const uid=(await account()).uid,query=search.query;
  if(generation!==search.generation||query.length<2)return {ignored:true};
  try{const data=await request('GET',`/api/nelkano/friends/search?q=${encodeURIComponent(query)}`,null,uid);if(generation!==search.generation)return {ignored:true};search.users=group(data.users??[]).filter(f=>f.uid!==uid);search.loading=false;search.error='';revision++;return panel();}
  catch(error){if(generation===search.generation){search.loading=false;search.error=error.message;}throw error;}
 }
 async function action(action,payload){
  const uid=(await account()).uid;
  if(mutation)throw new Error('mutation-pending');if(refreshing)throw new Error('refresh-pending');if(payload.revision!==revision)throw new Error('stale-action');
  const source=action==='invite'?search.users:action==='remove'?lists.friends:action==='cancel'?lists.outgoing:lists.incoming;
  const friend=source.find(f=>f.uid===payload.uid);if(!friend||friend.uid===uid)throw new Error('unknown-user');
  mutation=true;revision++;loadedAt=null;
  const id=action==='invite'?friend.uid:(friend.friendshipId||friend.uid),endpoint=action==='invite'?'request':action==='cancel'?'reject':action;
  try{await persist(uid,{friends:[],incoming:[],outgoing:[]},now(),true);await request('POST',`/api/nelkano/friends/${endpoint}`,{id,uid:id,friendshipId:id},uid);
   try{return {updated:true,page:await refresh(true)};}catch(error){return {updated:true,refreshError:error.message};}
  }finally{mutation=false;}
 }
 async function profileOpen(){const info=await account(),result=await request('GET','/api/nelkano/profile',null,info.uid),data=result.profile??{};profile={owner:info.uid,role:info.role??'',displayName:str(data.displayName??info.name??''),statusText:str(data.statusText??''),avatarColor:avatarColors.includes(data.avatarColor?.toLowerCase())?data.avatarColor.toLowerCase():avatarColors[0],avatarUrl:str(data.avatarUrl??''),avatar:null};return profilePanel();}
 function profilePanel(){return {kind:'profile-editor',values:copy(profile),readOnly:['owner','role'],colors:copy(avatarColors),actions:['profile-avatar','profile-save','open']};}
 async function avatar(payload){const uid=(await account()).uid;if(!profile||profile.owner!==uid)throw new Error('profile-not-open');const image=await host.images.read({resourceId:payload.resourceId,maxBytes:4*1024*1024,mimeTypes:['image/png','image/jpeg','image/webp']});
  if(!image||!Number.isInteger(image.size)||image.size<=0||image.size>4*1024*1024||!['image/png','image/jpeg','image/webp'].includes(image.mime)||typeof image.base64!=='string'||image.base64.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/.test(image.base64)||image.base64.length/4*3-(image.base64.endsWith('==')?2:image.base64.endsWith('=')?1:0)!==image.size)throw new Error('invalid-avatar');
  if(!active||(await account()).uid!==uid||profile?.owner!==uid)throw new Error('stale-account');profile.avatar={base64:image.base64,mime:image.mime,size:image.size,name:str(image.name??'',256)};return profilePanel();}
 async function profileSave(payload){
  const info=await account();if(!profile||profile.owner!==info.uid)throw new Error('profile-not-open');if(mutation)throw new Error('mutation-pending');if(refreshing)throw new Error('refresh-pending');
  const displayName=str(payload.displayName,256).trim(),statusText=str(payload.statusText).trim(),avatarColor=str(payload.avatarColor,32).toLowerCase();
  if(displayName.length<2)throw new Error('name-too-short');if(!avatarColors.includes(avatarColor))throw new Error('invalid-color');
  if(Object.keys(payload).some(k=>!['displayName','statusText','avatarColor'].includes(k)))throw new Error('read-only-field');
  const body={displayName,statusText,avatarColor};if(profile.avatar){body.avatarBase64=profile.avatar.base64;body.avatarMime=profile.avatar.mime;}
  mutation=true;try{await persist(info.uid,{friends:[],incoming:[],outgoing:[]},now(),true);const result=await request('POST','/api/nelkano/profile',body,info.uid);const updated=result.profile??{};
   profile={...profile,displayName:str(updated.displayName??displayName),statusText:str(updated.statusText??statusText),avatarColor:updated.avatarColor??avatarColor,avatarUrl:updated.avatarUrl??profile.avatarUrl,avatar:null};loadedAt=null;revision++;
   const warnings=[];try{await host.images.invalidate(info.uid);}catch(error){warnings.push(error.message);}try{await host.account.updateDisplayName(info.uid,profile.displayName);}catch(error){warnings.push(error.message);}
   return {saved:true,profile:profilePanel(),warnings};
  }finally{mutation=false;}
 }
 return {activate:async()=>{if(!active)lifecycle++;active=true;},deactivate:async()=>{active=false;lifecycle++;await reset();owner=null;},
  contributions:async(context={})=>active&&context.surface==='navigation'?[{moduleId,id:'friends',slot:'NAVIGATION_ITEM',label:context.language==='es'?'Amigos':'Friends',actionId:'open'}]:[],
  onEvent:async event=>{if(!active||event?.type!=='timer'||event.subscription!==timer||event.generation!==search.generation)return {ignored:true};timer=null;return runSearch(event.generation);},
  dispatch:async(actionName,payload={},context={})=>{
   if(!active)throw new Error('module-inactive');
   if(actionName==='open'){try{await refresh(payload.force!==false);return panel(context.language);}catch(error){if(['login-required','permission-denied'].includes(error.message))return {kind:'account-required',reason:error.message,actionId:'account.login'};throw error;}}
   if(actionName==='refresh')return refresh(payload.force===true);
   if(actionName==='get'){await account();return panel(context.language);}
   if(actionName==='search')return schedule(payload.query);
   if(['invite','accept','reject','remove','cancel'].includes(actionName))return action(actionName,payload);
   if(actionName==='accepted'){await refresh(false);return copy(lists.friends);}
   if(actionName==='profile-open')return profileOpen();
   if(actionName==='profile-avatar')return avatar(payload);
   if(actionName==='profile-save')return profileSave(payload);
   throw new Error('unknown-action');
  }
 };
}