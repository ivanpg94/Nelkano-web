# Amigos

Módulo nelkano.friends, versión 0.1.0, SDK 0.2.0. La entrada del paquete es src/sdk.js.

Añade Amigos junto al buscador de biblioteca y Cuenta en Ajustes generales. Incluye páginas de acceso y registro, búsqueda al escribir, solicitudes recibidas/enviadas, aceptar, rechazar, cancelar y eliminar amistades con confirmación. El perfil permite editar nombre visible, estado, color y seleccionar una imagen mediante un recurso del host. El rol es de solo lectura.

## Estado

SDK Studio ejecuta el flujo con cuentas ficticias. Acceso: demo@nelkano.test / Nelkano123. Puedes crear otras cuentas de prueba. No envía correos ni solicitudes a Internet; las cuentas y amistades se reinician al cerrar el servidor de Studio. La foto seleccionada es una imagen simulada.

Android conecta con https://nelkano.com: acceso, registro con activación por correo, búsqueda, solicitudes, amistades y perfil con foto. La sesión se cifra con Android Keystore; el host renueva los tokens y valida los permisos firmados. JavaScript no recibe tokens ni rutas privadas. El registro muestra el mensaje del servidor, también si falla el envío del correo. No usar cuentas reales en Studio.

## Desarrollo

Abre esta carpeta en SDK Studio o crea un proyecto con Amigos (simulación). Exporta desde Studio para generar el .nelkmod con tu clave de desarrollo.

Permisos: account.session, network.account y resources.image. Tokens y ficheros privados quedan fuera de JavaScript. Los tipos actuales están en src/nelkano/sdk/typescript/src/index.ts. modules/sdk/friends-host.d.ts y src/index.js conservan el contrato de investigación anterior; no son el contrato del paquete nuevo. index.js aporta parseFriend y avatarColors; su createModule antiguo no se invoca.

Prueba: node --test src/nelkano/sdk/tooling/test/friends-sdk.test.mjs. Ejecuta la entrada real en QuickJS y comprueba registro, acceso, solicitudes, perfil, salida y permisos con fixtures. Capturas del visor: outputs/friends-qa. El adaptador Android se comprobó en el emulador del PC con respuestas firmadas controladas: cifrado/restauración, renovación tras 401, permisos, subida de foto y cierre de sesión. No se ha probado una cuenta real de producción.

## Ganchos para otros módulos

Declara modules.hooks y consumes con provider nelkano.friends, hook y version 1.0.0. Usa optional:false si tu módulo no puede funcionar sin Amigos.

- friend-actions: contribute publica {label, scope?}. scope puede ser friends, incoming, outgoing o search; sin scope aparece en todos. Amigos llama a onHook con operation execute, contributionId y value {accountUid, friend, scope}. Devuelve {message} para mostrar el resultado. Tu módulo implementa la función; Amigos no crea mundos ni envía invitaciones por sí mismo.
- friends-data: invoke con operation snapshot devuelve la cuenta y las listas ya cargadas. refresh vuelve a consultar el servidor y requiere sesión válida. value es {}. La respuesta incluye revision, account, friends, incoming y outgoing. Los usuarios incluyen uid, name, statusText, avatarColor y avatarUrl, sin correo, contraseña ni tokens. Una lista vacía no demuestra que se haya consultado el servidor: usa refresh cuando necesites datos actuales.
- friends-events: contribute con {} registra el receptor. Amigos llama a onHook con operation changed y value que incluye el snapshot y type session-changed, friends-updated o profile-updated. Son avisos de operaciones del módulo, no presencia en tiempo real ni notificaciones push del servidor. No llames sincrónicamente de vuelta a Amigos desde ese callback; conserva los datos recibidos.

Amigos comprueba que el usuario siga en la lista, que la cuenta y revisión sigan siendo válidas y que el consumidor siga activo. Máximo 16 acciones y 8 receptores. Una acción antigua o de un módulo desactivado se rechaza. Los errores de un receptor no impiden la operación principal.

Ejemplo independiente: npx nelkmod example friends-hooks mi-integracion. Carga Amigos y esa carpeta juntos en Studio; al acceder aparece Invitar a mi mundo (ejemplo). Solo demuestra la llamada entre módulos, sin crear mundos ni enviar invitaciones reales. Se exporta e instala por separado; no viene activado en el teléfono.

Estos ganchos no extraen datos de emulación ni escriben memoria Pokémon. Eso corresponde a la futura integración de modules/online.
