// Authoring snapshot of the legacy catalog.
export default {
  "key": "N3DS",
  "label": "3DS",
  "items": [
    {
      "id": "screen",
      "label": "Pantalla",
      "kind": "SCREEN",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 160,
      "heightDp": 120,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5004776120185852,
          "y": 0.2669871151447296,
          "scale": 0.75,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-pause",
      "label": "Pausa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "PAUSE",
      "icon": "emu_action_pause",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-auto",
      "label": "Auto",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "AUTO",
      "icon": "emu_action_auto",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-record",
      "label": "Grabar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "RECORD",
      "icon": "emu_action_record",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-replay",
      "label": "Reproducir",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "REPLAY",
      "icon": "emu_action_replay",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fullscreen",
      "label": "Pantalla completa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FULLSCREEN",
      "icon": "emu_action_fullscreen",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-stretch",
      "label": "Estirar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "STRETCH",
      "icon": "emu_action_stretch",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-save",
      "label": "Guardar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "SAVE",
      "icon": "emu_action_save",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-load",
      "label": "Cargar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "LOAD",
      "icon": "emu_action_load",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-screen-mode",
      "label": "Pantallas",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "SCREEN_MODE",
      "icon": "emu_runtime_screens",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fps",
      "label": "FPS",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FPS",
      "icon": null,
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        }
      }
    },
    {
      "id": "dpad",
      "label": "Cruceta",
      "kind": "DPAD",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 112,
      "heightDp": 112,
      "defaults": {
        "PORTRAIT": {
          "x": 0.2089473158121109,
          "y": 0.7894737124443054,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.18000000715255737,
          "y": 0.7599999904632568,
          "scale": 1.25,
          "visible": true
        }
      }
    },
    {
      "id": "l",
      "label": "L",
      "kind": "INPUT",
      "input": "L",
      "action": null,
      "icon": "button_l",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.16736836731433868,
          "y": 0.5526316165924072,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.18421053886413574,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "r",
      "label": "R",
      "kind": "INPUT",
      "input": "R",
      "action": null,
      "icon": "button_r",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.832631528377533,
          "y": 0.5526316165924072,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7631579637527466,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "x",
      "label": "X",
      "kind": "INPUT",
      "input": "X",
      "action": null,
      "icon": "button_x",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7799999713897705,
          "y": 0.6600000262260437,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7653366327285767,
          "y": 0.6436159610748291,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "y",
      "label": "Y",
      "kind": "INPUT",
      "input": "Y",
      "action": null,
      "icon": "button_y",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6399999856948853,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6993131637573242,
          "y": 0.7535886764526367,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "a",
      "label": "A",
      "kind": "INPUT",
      "input": "A",
      "action": null,
      "icon": "button_a",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9200000166893005,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8309622406959534,
          "y": 0.7535886764526367,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "b",
      "label": "B",
      "kind": "INPUT",
      "input": "B",
      "action": null,
      "icon": "button_b",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7799999713897705,
          "y": 0.8600000143051147,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7653366327285767,
          "y": 0.8440806269645691,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "select",
      "label": "SELECT",
      "kind": "INPUT",
      "input": "SELECT",
      "action": null,
      "icon": "button_select",
      "widthDp": 72,
      "heightDp": 32,
      "defaults": {
        "PORTRAIT": {
          "x": 0.38999998569488525,
          "y": 0.949999988079071,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.44736844301223755,
          "y": 0.9157894849777222,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "start",
      "label": "START",
      "kind": "INPUT",
      "input": "START",
      "action": null,
      "icon": "button_start",
      "widthDp": 72,
      "heightDp": 32,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6200000047683716,
          "y": 0.949999988079071,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5526316165924072,
          "y": 0.9157894849777222,
          "scale": 1,
          "visible": true
        }
      }
    }
  ],
  "ratios": {
    "PORTRAIT": 0.8333333134651184,
    "LANDSCAPE": 3
  }
};
