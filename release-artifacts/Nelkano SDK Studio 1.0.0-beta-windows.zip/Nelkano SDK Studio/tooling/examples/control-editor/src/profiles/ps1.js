// Authoring snapshot of the legacy catalog.
export default {
  "key": "PS1",
  "label": "PS1",
  "items": [
    {
      "id": "screen",
      "label": "Pantalla",
      "kind": "SCREEN",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 160,
      "heightDp": 120,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.2800000011920929,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0.5415789484977722,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-pause",
      "label": "Pausa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "PAUSE",
      "icon": "emu_action_pause",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-auto",
      "label": "Auto",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "AUTO",
      "icon": "emu_action_auto",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-record",
      "label": "Grabar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "RECORD",
      "icon": "emu_action_record",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-replay",
      "label": "Reproducir",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "REPLAY",
      "icon": "emu_action_replay",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fullscreen",
      "label": "Pantalla completa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FULLSCREEN",
      "icon": "emu_action_fullscreen",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-stretch",
      "label": "Estirar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "STRETCH",
      "icon": "emu_action_stretch",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-save",
      "label": "Guardar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "SAVE",
      "icon": "emu_action_save",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-load",
      "label": "Cargar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "LOAD",
      "icon": "emu_action_load",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fps",
      "label": "FPS",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FPS",
      "icon": null,
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        }
      }
    },
    {
      "id": "dpad",
      "label": "Cruceta",
      "kind": "DPAD",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 112,
      "heightDp": 112,
      "defaults": {
        "PORTRAIT": {
          "x": 0.14971812069416046,
          "y": 0.7373979687690735,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.18421053886413574,
          "y": 0.7078947424888611,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "left-stick",
      "label": "Joystick izquierdo",
      "kind": "JOYSTICK",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 54,
      "heightDp": 54,
      "defaults": {
        "PORTRAIT": {
          "x": 0.37211737036705017,
          "y": 0.8596961498260498,
          "scale": 1.25,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.31578949093818665,
          "y": 0.8326315879821777,
          "scale": 1.25,
          "visible": true
        }
      }
    },
    {
      "id": "right-stick",
      "label": "Joystick derecho",
      "kind": "JOYSTICK",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 54,
      "heightDp": 54,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6000000238418579,
          "y": 0.8600000143051147,
          "scale": 1.25,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6842105388641357,
          "y": 0.8326315879821777,
          "scale": 1.25,
          "visible": true
        }
      }
    },
    {
      "id": "l2",
      "label": "L2",
      "kind": "INPUT",
      "input": "L2",
      "action": null,
      "icon": "emu_button_l2",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.11999999731779099,
          "y": 0.5600000023841858,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.15789474546909332,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "l1",
      "label": "L1",
      "kind": "INPUT",
      "input": "L1",
      "action": null,
      "icon": "emu_button_l1",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.3199999928474426,
          "y": 0.5600000023841858,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.2879082262516022,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "r1",
      "label": "R1",
      "kind": "INPUT",
      "input": "R1",
      "action": null,
      "icon": "emu_button_r1",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6800000071525574,
          "y": 0.5600000023841858,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7382684350013733,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "r2",
      "label": "R2",
      "kind": "INPUT",
      "input": "R2",
      "action": null,
      "icon": "emu_button_r2",
      "widthDp": 66,
      "heightDp": 34,
      "defaults": {
        "PORTRAIT": {
          "x": 0.8799999952316284,
          "y": 0.5600000023841858,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8684210777282715,
          "y": 0.5,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "triangle",
      "label": "TRIANGLE",
      "kind": "INPUT",
      "input": "TRIANGLE",
      "action": null,
      "icon": "emu_button_triangle",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.8132637143135071,
          "y": 0.6503156423568726,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.815571129322052,
          "y": 0.665971040725708,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "square",
      "label": "SQUARE",
      "kind": "INPUT",
      "input": "SQUARE",
      "action": null,
      "icon": "emu_button_square",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.672840416431427,
          "y": 0.7506783604621887,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7627213001251221,
          "y": 0.7494736909866333,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "circle",
      "label": "CIRCLE",
      "kind": "INPUT",
      "input": "CIRCLE",
      "action": null,
      "icon": "emu_button_circle",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9527316093444824,
          "y": 0.7506783604621887,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8684210777282715,
          "y": 0.7494736909866333,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "cross",
      "label": "CROSS",
      "kind": "INPUT",
      "input": "CROSS",
      "action": null,
      "icon": "emu_button_cross",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.8132637143135071,
          "y": 0.8504365682601929,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.815571129322052,
          "y": 0.8329765200614929,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "select",
      "label": "SELECT",
      "kind": "INPUT",
      "input": "SELECT",
      "action": null,
      "icon": "button_select",
      "widthDp": 72,
      "heightDp": 32,
      "defaults": {
        "PORTRAIT": {
          "x": 0.3697870671749115,
          "y": 1,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.4300000071525574,
          "y": 0.9399999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "start",
      "label": "START",
      "kind": "INPUT",
      "input": "START",
      "action": null,
      "icon": "button_start",
      "widthDp": 72,
      "heightDp": 32,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6000047326087952,
          "y": 1,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5899999737739563,
          "y": 0.9399999976158142,
          "scale": 1,
          "visible": true
        }
      }
    }
  ],
  "ratios": {
    "PORTRAIT": 1.3333333730697632,
    "LANDSCAPE": 1.3333333730697632
  }
};
