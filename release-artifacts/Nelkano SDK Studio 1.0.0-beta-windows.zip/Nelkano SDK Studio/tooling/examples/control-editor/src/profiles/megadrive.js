// Authoring snapshot of the legacy catalog.
export default {
  "key": "MEGADRIVE",
  "label": "MD",
  "items": [
    {
      "id": "screen",
      "label": "Pantalla",
      "kind": "SCREEN",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 160,
      "heightDp": 120,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.2800000011920929,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-pause",
      "label": "Pausa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "PAUSE",
      "icon": "emu_action_pause",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-auto",
      "label": "Auto",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "AUTO",
      "icon": "emu_action_auto",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-record",
      "label": "Grabar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "RECORD",
      "icon": "emu_action_record",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-replay",
      "label": "Reproducir",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "REPLAY",
      "icon": "emu_action_replay",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fullscreen",
      "label": "Pantalla completa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FULLSCREEN",
      "icon": "emu_action_fullscreen",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-stretch",
      "label": "Estirar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "STRETCH",
      "icon": "emu_action_stretch",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-save",
      "label": "Guardar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "SAVE",
      "icon": "emu_action_save",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-load",
      "label": "Cargar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "LOAD",
      "icon": "emu_action_load",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fps",
      "label": "FPS",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FPS",
      "icon": null,
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": false
        }
      }
    },
    {
      "id": "dpad",
      "label": "Cruceta",
      "kind": "DPAD",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 112,
      "heightDp": 112,
      "defaults": {
        "PORTRAIT": {
          "x": 0.1599999964237213,
          "y": 0.800000011920929,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.18000000715255737,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "a",
      "label": "A",
      "kind": "INPUT",
      "input": "A",
      "action": null,
      "icon": "button_a",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.6247368454933167,
          "y": 0.815789520740509,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7105263471603394,
          "y": 0.8326315879821777,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "b",
      "label": "B",
      "kind": "INPUT",
      "input": "B",
      "action": null,
      "icon": "button_b",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7797725796699524,
          "y": 0.79156494140625,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7894737124443054,
          "y": 0.7494736909866333,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "c",
      "label": "C",
      "kind": "INPUT",
      "input": "C",
      "action": null,
      "icon": "emu_button_c",
      "widthDp": 48,
      "heightDp": 48,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9573683738708496,
          "y": 0.7631579041481018,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8631078004837036,
          "y": 0.6659461259841919,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "start",
      "label": "START",
      "kind": "INPUT",
      "input": "START",
      "action": null,
      "icon": "button_start",
      "widthDp": 72,
      "heightDp": 32,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.949999988079071,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.5,
          "y": 0.9399999976158142,
          "scale": 1,
          "visible": true
        }
      }
    }
  ],
  "ratios": {
    "PORTRAIT": 1.4285714626312256,
    "LANDSCAPE": 1.4285714626312256
  }
};
