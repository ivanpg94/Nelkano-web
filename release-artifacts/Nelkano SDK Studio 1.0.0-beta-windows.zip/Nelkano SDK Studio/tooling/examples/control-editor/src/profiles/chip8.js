// Authoring snapshot of the legacy catalog.
export default {
  "key": "CHIP8",
  "label": "CHIP-8",
  "items": [
    {
      "id": "screen",
      "label": "Pantalla",
      "kind": "SCREEN",
      "input": null,
      "action": null,
      "icon": null,
      "widthDp": 160,
      "heightDp": 120,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5,
          "y": 0.2800000011920929,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.49660682678222656,
          "y": 0.286653071641922,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-pause",
      "label": "Pausa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "PAUSE",
      "icon": "emu_action_pause",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-auto",
      "label": "Auto",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "AUTO",
      "icon": "emu_action_auto",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-record",
      "label": "Grabar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "RECORD",
      "icon": "emu_action_record",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-replay",
      "label": "Reproducir",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "REPLAY",
      "icon": "emu_action_replay",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.054999999701976776,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.03500000014901161,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-fullscreen",
      "label": "Pantalla completa",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "FULLSCREEN",
      "icon": "emu_action_fullscreen",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.03999999910593033,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-stretch",
      "label": "Estirar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "STRETCH",
      "icon": "emu_action_stretch",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.11500000208616257,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-save",
      "label": "Guardar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "SAVE",
      "icon": "emu_action_save",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.1899999976158142,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "sys-load",
      "label": "Cargar",
      "kind": "SYSTEM_ACTION",
      "input": null,
      "action": "LOAD",
      "icon": "emu_action_load",
      "widthDp": 50,
      "heightDp": 30,
      "defaults": {
        "PORTRAIT": {
          "x": 0.9449999928474426,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.9649999737739563,
          "y": 0.26499998569488525,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-1",
      "label": "1",
      "kind": "INPUT",
      "input": "CHIP8_1",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.23000000417232513,
          "y": 0.6800000071525574,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6623180508613586,
          "y": 0.44147011637687683,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-2",
      "label": "2",
      "kind": "INPUT",
      "input": "CHIP8_2",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.4100000262260437,
          "y": 0.6800000071525574,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7621428966522217,
          "y": 0.44147011637687683,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-3",
      "label": "3",
      "kind": "INPUT",
      "input": "CHIP8_3",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5900000333786011,
          "y": 0.6800000071525574,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8628435134887695,
          "y": 0.44147011637687683,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-c",
      "label": "C",
      "kind": "INPUT",
      "input": "CHIP8_C",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7700000405311584,
          "y": 0.6800000071525574,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.962668240070343,
          "y": 0.44147011637687683,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-4",
      "label": "4",
      "kind": "INPUT",
      "input": "CHIP8_4",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.23000000417232513,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6623180508613586,
          "y": 0.5922757387161255,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-5",
      "label": "5",
      "kind": "INPUT",
      "input": "CHIP8_5",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.4100000262260437,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7621428966522217,
          "y": 0.5922757387161255,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-6",
      "label": "6",
      "kind": "INPUT",
      "input": "CHIP8_6",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5900000333786011,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8628435134887695,
          "y": 0.5922757387161255,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-d",
      "label": "D",
      "kind": "INPUT",
      "input": "CHIP8_D",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7700000405311584,
          "y": 0.7599999904632568,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.962668240070343,
          "y": 0.5922757387161255,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-7",
      "label": "7",
      "kind": "INPUT",
      "input": "CHIP8_7",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.23000000417232513,
          "y": 0.8400000333786011,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6623180508613586,
          "y": 0.7416977882385254,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-8",
      "label": "8",
      "kind": "INPUT",
      "input": "CHIP8_8",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.4100000262260437,
          "y": 0.8400000333786011,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7621428966522217,
          "y": 0.7416977882385254,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-9",
      "label": "9",
      "kind": "INPUT",
      "input": "CHIP8_9",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5900000333786011,
          "y": 0.8400000333786011,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8628435134887695,
          "y": 0.7416977882385254,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-e",
      "label": "E",
      "kind": "INPUT",
      "input": "CHIP8_E",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7700000405311584,
          "y": 0.8400000333786011,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.962668240070343,
          "y": 0.7416977882385254,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-a",
      "label": "A",
      "kind": "INPUT",
      "input": "CHIP8_A",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.23000000417232513,
          "y": 0.9200000166893005,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.6623180508613586,
          "y": 0.8925034403800964,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-0",
      "label": "0",
      "kind": "INPUT",
      "input": "CHIP8_0",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.4100000262260437,
          "y": 0.9200000166893005,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.7621428966522217,
          "y": 0.8925034403800964,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-b",
      "label": "B",
      "kind": "INPUT",
      "input": "CHIP8_B",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.5900000333786011,
          "y": 0.9200000166893005,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.8628435134887695,
          "y": 0.8925034403800964,
          "scale": 1,
          "visible": true
        }
      }
    },
    {
      "id": "key-f",
      "label": "F",
      "kind": "INPUT",
      "input": "CHIP8_F",
      "action": null,
      "icon": null,
      "widthDp": 42,
      "heightDp": 42,
      "defaults": {
        "PORTRAIT": {
          "x": 0.7700000405311584,
          "y": 0.9200000166893005,
          "scale": 1,
          "visible": true
        },
        "LANDSCAPE": {
          "x": 0.962668240070343,
          "y": 0.8925034403800964,
          "scale": 1,
          "visible": true
        }
      }
    }
  ],
  "ratios": {
    "PORTRAIT": 2,
    "LANDSCAPE": 2
  }
};
