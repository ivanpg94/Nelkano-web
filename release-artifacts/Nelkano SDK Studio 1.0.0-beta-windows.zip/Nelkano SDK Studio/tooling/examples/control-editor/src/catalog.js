// Profiles split into editable files below Studio’s 64 KiB text limit.
import profile0 from './profiles/game_boy.js';
import profile1 from './profiles/gba.js';
import profile2 from './profiles/nds.js';
import profile3 from './profiles/n3ds.js';
import profile4 from './profiles/nes.js';
import profile5 from './profiles/megadrive.js';
import profile6 from './profiles/master_system.js';
import profile7 from './profiles/game_gear.js';
import profile8 from './profiles/neo_geo_pocket.js';
import profile9 from './profiles/ps1.js';
import profile10 from './profiles/chip8.js';
import profile11 from './profiles/rpg_maker.js';
import profile12 from './profiles/switch.js';
import profile13 from './profiles/psp.js';
import profile14 from './profiles/gamecube.js';
export const profiles=[profile0,profile1,profile2,profile3,profile4,profile5,profile6,profile7,profile8,profile9,profile10,profile11,profile12,profile13,profile14];
