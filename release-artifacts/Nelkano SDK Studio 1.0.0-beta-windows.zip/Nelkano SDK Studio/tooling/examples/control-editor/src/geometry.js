import {profiles} from './catalog.js';
const f=Math.fround,round=x=>Math.floor(f(x)+.5),clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),copy=x=>JSON.parse(JSON.stringify(x));
export function profileFor(key){const name=typeof key==='string'?key.trim().toUpperCase():'';return copy(profiles.find(p=>p.key===(name==='FAMICOM'?'NES':name))??profiles[0]);}
export function defaultsFor(key,orientation,fpsVisibleByDefault=false){if(!['PORTRAIT','LANDSCAPE'].includes(orientation)||typeof fpsVisibleByDefault!=='boolean')throw new Error('invalid-orientation');const profile=profileFor(key);return Object.fromEntries(profile.items.map(item=>{const value=copy(item.defaults[orientation]);if(item.action==='FPS')value.visible=fpsVisibleByDefault;return [item.id,value];}));}
export function sanitizeValue(value){if(!value||![value.x,value.y,value.scale].every(Number.isFinite)||typeof value.visible!=='boolean')throw new Error('invalid-control-value');return {x:f(clamp(value.x,0,1)),y:f(clamp(value.y,0,1)),scale:f(clamp(value.scale,.5,2)),visible:value.visible};}
export function legacyValues(preferences,key,orientation,fpsVisibleByDefault=false){if(!preferences||typeof preferences!=='object'||Array.isArray(preferences))throw new Error('invalid-legacy');const profile=profileFor(key),values=defaultsFor(key,orientation,fpsVisibleByDefault);for(const item of profile.items){const prefix=`emulation-controls-v2.${profile.key}.${orientation.toLowerCase()}.${item.id}`,value=values[item.id];for(const field of ['x','y','scale','visible'])if(Object.prototype.hasOwnProperty.call(preferences,prefix+'.'+field))value[field]=preferences[prefix+'.'+field];values[item.id]=sanitizeValue(value);}return values;}
export function separateInputs(boxes,width,height,gap){
 for(let pass=0;pass<64;pass++){let moved=false;
  for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],b=boxes[j];if(a[2]+gap<=b[0]||b[2]+gap<=a[0]||a[3]+gap<=b[1]||b[3]+gap<=a[1])continue;
   let bestAxis=-1,bestSign=0,bestDistance=2147483647;
   for(let axis=0;axis<2;axis++)for(const sign of [-1,1]){const limit=axis===0?width:height,distance=sign<0?a[axis+2]+gap-b[axis]:b[axis+2]+gap-a[axis],space=sign<0?a[axis]+limit-b[axis+2]:limit-a[axis+2]+b[axis];if(distance>0&&distance<=space&&distance<bestDistance){bestAxis=axis;bestSign=sign;bestDistance=distance;}}
   if(bestAxis<0)continue;const limit=bestAxis===0?width:height,roomA=bestSign<0?a[bestAxis]:limit-a[bestAxis+2],roomB=bestSign<0?limit-b[bestAxis+2]:b[bestAxis];let moveA=Math.min(roomA,Math.trunc((bestDistance+1)/2)),moveB=Math.min(roomB,bestDistance-moveA);moveA+=bestDistance-moveA-moveB;a[bestAxis]+=bestSign*moveA;a[bestAxis+2]+=bestSign*moveA;b[bestAxis]-=bestSign*moveB;b[bestAxis+2]-=bestSign*moveB;moved=true;
  }if(!moved)return;
 }
}
export function fourButtonIds(key){return key==='PS1'?['triangle','square','circle','cross']:key==='PSP'?['y','x','a','b']:['NDS','N3DS','SWITCH','RPG_MAKER','GAMECUBE'].includes(key)?['x','y','a','b']:[];}
function applyFourButtonLayout(profile,values,result,width,height,density){
 const ids=fourButtonIds(profile.key),orientation=height>width?'PORTRAIT':'LANDSCAPE';if(!ids.length)return;
 const stock=id=>{const v=values[id],d=profile.items.find(i=>i.id===id)?.defaults[orientation];return result[id]&&v&&d&&['x','y','scale','visible'].every(k=>v[k]===d[k]);};
 if(!ids.every(stock))return;
 if(!profile.items.filter(i=>!['SCREEN','SYSTEM_ACTION'].includes(i.kind)&&i.defaults[orientation].visible).every(i=>stock(i.id)))return;
 const place=(id,x,y)=>{const b=result[id];if(!b)return;const w=b[2]-b[0],h=b[3]-b[1];b[0]=Math.floor(x-w/2+.5);b[1]=Math.floor(y-h/2+.5);b[2]=b[0]+w;b[3]=b[1]+h;};
 if(orientation==='PORTRAIT'){
  const boxes=ids.map(id=>result[id]),center=(b,a)=>(b[a]+b[a+2])/2,half=Math.max(...boxes.map(b=>Math.max(b[2]-b[0],b[3]-b[1])))/2,radius=Math.max((center(boxes[2],0)-center(boxes[1],0))/2,half*2+Math.max(1,round(f(4*f(density)))));
  if(width<2*(radius+half)||height<2*(radius+half))return;
  const x=clamp((center(boxes[1],0)+center(boxes[2],0))/2,radius+half,width-radius-half),y=clamp((center(boxes[1],1)+center(boxes[2],1))/2,radius+half,height-radius-half);
  place(ids[0],x,y-radius);place(ids[1],x-radius,y);place(ids[2],x+radius,y);place(ids[3],x,y+radius);
  const stick=result['stick-right'];if(stick&&boxes.some(a=>a[0]<stick[2]&&stick[0]<a[2]&&a[1]<stick[3]&&stick[1]<a[3])){const h=stick[3]-stick[1];stick[1]=Math.max(0,Math.min(...boxes.map(b=>b[1]))-Math.floor(4*density+.5)-h);stick[3]=stick[1]+h;}return;
 }
 const w=width/density,h=height/density;if(w<560||h<220||!profile.items.filter(i=>!['SCREEN','SYSTEM_ACTION'].includes(i.kind)&&i.defaults.LANDSCAPE.visible).every(i=>stock(i.id)))return;
 const dp=(id,x,y)=>place(id,x*density,y*density),half=(id,a)=>result[id]?(result[id][a+2]-result[id][a])/density/2:0,x=w-128,y=h-80;
 dp(ids[0],x,y-52);dp(ids[1],x-52,y);dp(ids[2],x+52,y);dp(ids[3],x,y+52);
 const dpadHalf=half('dpad',0),dpadX=dpadHalf+4,dpadTop=h-2*dpadHalf-4;dp('dpad',dpadX,h-dpadHalf-4);
 const leftPair=result.l2?['l2','l1']:result.zl?['zl','l']:['l'],rightPair=result.r2?['r1','r2']:result.zr?['r','zr']:['r'];
 const leftShoulderX=leftPair.length===1?dpadX:Math.max(dpadX,72);
 leftPair.forEach((id,i)=>dp(id,leftShoulderX+(leftPair.length===1?0:i===0?-35:35),dpadTop-4-half(id,1)));
 rightPair.forEach((id,i)=>dp(id,x+(rightPair.length===1?0:i===0?-35:35),h-156-4-half(id,1)));
 const leftStick=['left-stick','stick-left'].find(id=>result[id]),rightStick=['right-stick','stick-right'].find(id=>result[id]);
 if(leftStick)dp(leftStick,dpadX+dpadHalf+4+half(leftStick,0),h-half(leftStick,1)-4);
 if(rightStick)dp(rightStick,x-52-24-4-half(rightStick,0),h-half(rightStick,1)-4);
 const leftLimit=leftStick?dpadX+dpadHalf+8+2*half(leftStick,0):dpadX+dpadHalf+4,rightLimit=rightStick?x-52-24-8-2*half(rightStick,0):x-52-24-4,fits=rightLimit-leftLimit>=148,menuCenter=fits?(leftLimit+rightLimit)/2:w/2,menuY=h-(fits?20:130);
 dp('select',menuCenter-38,menuY);dp('start',menuCenter+38,menuY);
}
export function inputLayout(key,values,width,height,density){
 if(![width,height].every(x=>Number.isSafeInteger(x)&&x>0&&x<=32768)||!Number.isFinite(density)||density<=0||density>16)throw new Error('invalid-canvas');const result={},visible=[];
 for(const item of profileFor(key).items){if(['SCREEN','SYSTEM_ACTION'].includes(item.kind))continue;const value=values[item.id];if(!value)continue;sanitizeValue(value);const w=Math.max(1,round(f(f(item.widthDp*f(value.scale))*f(density)))),h=Math.max(1,round(f(f(item.heightDp*f(value.scale))*f(density)))),x=Math.max(0,Math.min(width-w,round(f(f(f(value.x)*width)-f(w*.5))))),y=Math.max(0,Math.min(height-h,round(f(f(f(value.y)*height)-f(h*.5)))));const box=[x,y,x+w,y+h];result[item.id]=box;if(value.visible)visible.push(box);}
 const gap=Math.max(1,round(f(4*f(density))));separateInputs(visible,width,height,gap);
 applyFourButtonLayout(profileFor(key),values,result,width,height,density);
 return result;
}
export function project(box,scale,left,top){if(!Array.isArray(box)||box.length!==4||![...box,scale,left,top].every(Number.isFinite))throw new Error('invalid-projection');return [round(f(f(left)+f(box[0]*f(scale)))),round(f(f(top)+f(box[1]*f(scale)))),round(f(f(left)+f(box[2]*f(scale)))),round(f(f(top)+f(box[3]*f(scale))))];}
export function separateSystemButtons(boxes,height,gap){const order=boxes.map((_,i)=>i).sort((a,b)=>boxes[a][1]-boxes[b][1]),overlaps=(a,b)=>a[0]<b[2]&&b[0]<a[2],move=(box,top)=>{box[3]+=top-box[1];box[1]=top;};
 for(let i=0;i<order.length;i++){const box=boxes[order[i]];let top=box[1];for(let j=0;j<i;j++){const previous=boxes[order[j]];if(overlaps(box,previous))top=Math.max(top,previous[3]+gap);}move(box,top);}
 for(let i=order.length-1;i>=0;i--){const box=boxes[order[i]];let bottom=Math.min(height,box[3]);for(let j=i+1;j<order.length;j++){const next=boxes[order[j]];if(overlaps(box,next))bottom=Math.min(bottom,next[1]-gap);}move(box,bottom-(box[3]-box[1]));}
}
export function grid(width,height){if(![width,height].every(Number.isFinite))throw new Error('invalid-grid');const w=f(Math.max(1,f(width))),h=f(Math.max(1,f(height)));const columns=w<=h?24:Math.max(1,round(f(f(w/h)*24))),rows=w<=h?Math.max(1,round(f(f(h/w)*24))):24,cellSize=f(Math.min(f(w/columns),f(h/rows)));return {columns,rows,cellSize,left:f(f(w-f(columns*cellSize))*.5),top:f(f(h-f(rows*cellSize))*.5),width:w,height:h};}
export function snap(grid,value,axis){if(!Number.isFinite(value)||!['x','y'].includes(axis))throw new Error('invalid-snap');const origin=axis==='x'?grid.left:grid.top,limit=axis==='x'?grid.width:grid.height;return f(clamp(f(origin+f(round(f(f(f(value)-origin)/grid.cellSize))*grid.cellSize)),0,limit));}
export function previewViewport(width,height,referenceWidth,referenceHeight){if(![width,height,referenceWidth,referenceHeight].every(x=>Number.isFinite(x)&&x>0))throw new Error('invalid-viewport');const scale=f(Math.min(f(width/referenceWidth),f(height/referenceHeight)));return {virtualWidth:f(referenceWidth),virtualHeight:f(referenceHeight),scale,left:f(f(f(width)-f(referenceWidth*scale))*.5),top:0};}
export function legacyViewport(width,height,portrait=width<=height){const w=f(Math.max(1,f(width))),h=f(Math.max(1,f(height))),virtualWidth=portrait?w:f(h*f(1.58)),virtualHeight=portrait?f(w*f(1.58)):h;return previewViewport(w,h,virtualWidth,virtualHeight);}
export function fitScreen(availableWidth,availableHeight,ratio){const w=Math.max(1,availableWidth),h=Math.max(1,availableHeight);if(!Number.isFinite(ratio)||ratio<=0)throw new Error('invalid-ratio');const scale=f(Math.min(f(w/f(ratio)),h));return [Math.max(1,round(f(scale*f(ratio)))),Math.max(1,round(scale))];}
