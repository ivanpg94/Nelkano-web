# Editor de controles

Módulo integrado en Android nuevo y SDK Studio como paquete firmado. Android antiguo permanece independiente. La asignación de botones físicos y mandos Bluetooth se encuentra en el módulo gamepad.

Incluye doce perfiles, ambas orientaciones, selector, borradores por perfil, guardar/cancelar/reset, selección múltiple, movimiento de grupos, siete escalas de 0.5 a 2, rejilla con snapping, zoom de 1 a 4 con pan, previsualización y visibilidad de botones. Calcula layouts jugables mediante la acción layout sin abrir el editor. Conserva los identificadores y acciones de pantalla/FPS. El descriptor visual incluye 42 recursos: los 31 PNG originales, ocho PNG de runtime adicionales y tres vectores convertidos a SVG con geometría y colores originales.

Guarda todos los perfiles visitados en una operación CAS durable. Detecta conflictos sobre los perfiles editados y conserva modificaciones concurrentes en otros perfiles. Los fallos de escritura mantienen el borrador; los fallos de presentación tras guardar permiten retry-apply sin repetir la escritura. Importa las claves emulation-controls-v2 con valores explícitos y mantiene el FPS predeterminado dinámico donde no había preferencia. La importación no escribe en SharedPreferences.

Contrato en sdk/control-editor-host.d.ts. El host aporta almacenamiento, métricas y aplicación de atributos por dueño. El módulo contiene el catálogo, geometría y lógica de edición; src/sdk.js adapta la lógica al SDK 0.2.0; el host compartido representa el lienzo y aplica los atributos al jugador, conservando el input nativo.

## Verificación

22 pruebas Node: catálogo, geometría, gestos, persistencia, fallos, conflictos y ejecución desde ZIP firmado. Se comparan 96 layouts de doce sistemas y dos orientaciones con ejecución independiente de Java original, tanto predeterminados como personalizados y con/sin cabecera. También se verifica cada hash de los 34 recursos originales del catálogo. Estos casos acreditan paridad geométrica con el algoritmo antiguo; no garantizan ausencia de colisiones en distribuciones imposibles.

 tools/legacy-reference.mjs ejecuta siete clases originales puras bajo build/legacy-reference. Sustituye únicamente R y los tipos de preferencias sin Android. test/legacy-reference.json registra resultados y SHA-256. tools/assets.mjs prepara los recursos originales para autoría; no se consulta Android al ejecutar el paquete.

Manifest y paquete de desarrollo nelkano.control-editor-0.1.0.nelkmod, SDK 0.2.0. Queda pendiente integrar y verificar el renderer/input reales de plataforma; no se afirma paridad visual ni prueba física Android.

## Editor de controles y lienzo declarativo

El módulo incluido nelkano.control-editor (0.1.0) usa SDK 0.2.0. Su lógica vive en modules/control-editor; el APK incorpora un .nelkmod firmado, desactivable e importable. Mantiene doce perfiles, vertical/horizontal, selección múltiple, movimiento en grupo, tamaños 0.5–2, visibilidad, cuadrícula y ajuste, zoom 1–4, desplazamiento y vista previa. Guardar confirma todos los perfiles visitados e iconos elegidos en un CAS; Cancelar conserva el diseño guardado.

Capacidad environment.display: host.environment.snapshot() devuelve width/height en píxeles, density, touchSlop y fpsVisibleByDefault. Studio devuelve métricas ficticias. No proporciona acceso a una ventana nativa.

Capacidad presentation.control-layouts: host.presentation.applyControlLayouts({moduleId,revision,profiles,layouts,icons?}) publica una capa propia. layouts usa claves PROFILE|PORTRAIT o PROFILE|LANDSCAPE y cada control admite x/y normalizados [0,1], scale [0.5,2], visible boolean. icons asocia ID de control con {moduleId,path}; el broker exige PNG declarado propio o aportado al proveedor. Se rechazan propietarios ajenos, revisiones anteriores y valores no válidos. releaseControlLayouts(moduleId) retira la capa propia; desactivar, desinstalar o fallar retira sus efectos y conserva datos. Si coinciden varias capas, la elección por perfil es determinista según el ID de módulo; se recomienda activar un único editor para cada perfil.

Respuesta dispatch: {kind:'control-editor',title,profile,orientation,profiles,nodes,viewport,grid,preview,scaleLevels,scaleLevel}. Un nodo contiene id,label,kind SCREEN/DPAD/JOYSTICK/INPUT/SYSTEM_ACTION,bounds [left,top,right,bottom] en píxeles del lienzo,value {x,y,scale,visible},selected,shown,opacity,asset e iconOwner opcional. viewport contiene virtualWidth/virtualHeight,scale,left/top; el módulo responde a resize(width,height). El host valida límites y recursos antes de mostrar el lienzo compartido por Android y Studio. No ejecuta callbacks UI del módulo. Las acciones del lienzo son switch(profile,orientation), drag(id,phase,x,y), select(id,toggle), scale-begin/scale(level)/scale-end, visibility, grid, reset, zoom, preview, save y cancel.

El editor publica icons y system-buttons 1.0.0. Un consumidor declara modules.hooks y consumes con provider nelkano.control-editor, hook, version y optional. icons acepta {target,icon,label}; target identifica el control (por ejemplo a o sys-pause). system-buttons acepta {actionId,icon,label,target?}. El editor conserva las elecciones por autor + módulo + ID. Si desaparece el consumidor, usa el icono predeterminado y retira sus botones, conservando la elección para una futura reactivación.

Para ejecutar un botón aportado, el proveedor usa host.hooks.invokeContributor(hook,moduleId,id,operation,value). Solo puede llamar a un consumidor que haya aportado ese ID a uno de sus propios ganchos. El broker comprueba identidad, disponibilidad y esquemas input/output; llama onHook del consumidor con hook,operation,value,contributionId y caller. No necesita conocer por adelantado IDs de futuros consumidores. Se mantiene el rechazo de llamadas circulares/runtime ocupado.

Crea una copia autónoma con npx nelkmod example control-editor mi-editor o la plantilla Editor de controles de Studio. La copia usa example.control-editor y una clave propia; puede coexistir, pero desactiva otros editores para probar su capa. Los perfiles se separan en src/profiles/*.js para poder abrirlos y editarlos en Studio. Guarda, verifica, exporta y prueba en Android nuevo. La receta interna bundle-control-editor.mjs empaqueta la copia incluida, con clave de desarrollo fuera del repositorio; sync-control-example.mjs sincroniza la plantilla desde las fuentes canónicas.

La asignación de teclas físicas/Bluetooth corresponde a gamepad y sigue pendiente. El lienzo no implementa funciones de grabación, reproducción ni autoguardado: los botones del catálogo solo ejecutan funciones disponibles en el jugador o acciones aportadas por otros módulos. Los SVG del catálogo se conservan en el paquete; el renderer utiliza etiquetas para ellos porque aún no decodifica SVG como icono. Studio no ejecuta ROMs ni hardware. SDK, APK y módulo mantienen sus versiones por petición de Ivan.


Apariencia del editor, 2026-10-04: renderer compartido con cabecera/título/Guardar, pestañas de sistemas, orientación/Vista y herramientas inferiores. Deslizador de siete niveles, cuadrícula/Sys/restaurar; selección con borde y lienzo azul oscuro sin etiqueta. Sys mantiene tarjetas e indicador, con accesos a iconos y visibilidad de controles de juego. Studio escala toda la pantalla lógica 420×800/800×420 al visor, conservando proporciones. Ocho PNG de runtime copiados como fuentes autónomas del módulo; el antiguo permanece sin cambios. Libro local importado y exportado; versiones conservadas.

El gancho system-buttons admite target para reutilizar un control existente. Su ejecución pasa {context} a onHook del consumidor; context.session identifica la partida. El consumidor puede utilizar las operaciones públicas de emulación y guardado con sus permisos, sin modificar el editor.

El perfil RPG Maker incluye `sys-keyboard` (Teclado), con posición, tamaño y visibilidad por orientación. En Android abre y cierra el teclado nativo para introducir texto, borrar y confirmar con Enter. No se anuncia como una operación de emulación del SDK ni como teclado virtual de Desktop/Studio.
