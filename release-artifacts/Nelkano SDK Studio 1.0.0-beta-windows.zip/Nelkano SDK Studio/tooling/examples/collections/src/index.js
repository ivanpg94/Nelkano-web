import {
  CollectionError, clone, emptyState, validateState, gameIds, normalizeName,
  ensureCollection, findCollection, isBaseFavorites, importLegacy, importBackup, matchesGame,
} from "./model.js";

export const moduleId = "nelkano.collections";
const storageKey = "collections-v1";
const error = code => { throw new CollectionError(code); };
const labels = {
  es: { title: "Colecciones", create: "Crear colección", add: "Añadir a colección", remove: "Quitar de colección", filter: "Filtrar por colección", all: "Todas", manage: "Gestionar colecciones", name: "Nombre", rename: "Renombrar", delete: "Eliminar colección", export: "Exportar colecciones", import: "Importar colecciones" },
  en: { title: "Collections", create: "Create collection", add: "Add to collection", remove: "Remove from collection", filter: "Filter by collection", all: "All", manage: "Manage collections", name: "Name", rename: "Rename", delete: "Delete collection", export: "Export collections", import: "Import collections" },
};

/** Host ports are drafts defined in modules/sdk/collections-host.d.ts. */
export function createModule(host) {
  if (!host?.storage?.read || !host.storage.compareAndSwap || !host.library?.list || !host.saves?.list) error("missing-capability");
  let active = false;
  let queue = Promise.resolve();
  // All lifecycle, reads and writes are serialized. Failed operations do not poison the queue.
  function serial(operation) {
    const task = queue.then(operation);
    queue = task.catch(() => {});
    return task;
  }
  async function read() {
    const document = await host.storage.read(storageKey);
    if (!document || !Number.isSafeInteger(document.revision) || document.revision < 0) error("invalid-storage-response");
    return { revision: document.revision, state: document.value === null ? emptyState() : clone(validateState(document.value)) };
  }
  async function write(operation) {
    for (let attempt = 0; attempt < 4; attempt++) {
      const { revision, state } = await read();
      const result = operation(state);
      validateState(state);
      if (await host.storage.compareAndSwap(storageKey, revision, state)) return clone(result ?? null);
    }
    error("storage-conflict");
  }
  function requireActive() { if (!active) error("module-inactive"); }
  async function snapshotGames() {
    const games = await host.library.list();
    if (!Array.isArray(games)) error("invalid-library-response");
    gameIds(games.map(game => game.id));
    return clone(games);
  }
  async function selected(ids) {
    const requested = gameIds(ids);
    if (!requested.length) error("no-games-selected");
    const known = new Set((await snapshotGames()).map(game => game.id));
    if (requested.some(id => !known.has(id))) error("game-not-found");
    return requested;
  }
  function contribution(id, slot, label, actionId, extra = {}) {
    return { moduleId, id, slot, label, actionId, ...extra };
  }
  function panel(state, context, language) {
    const text = labels[language] ?? labels.es;
    const selection = gameIds(context.selection ?? (context.gameId ? [context.gameId] : []));
    return {
      kind: "collection-panel", moduleId, id: "collections", title: text.title,
      fields: [{ id: "name", kind: "text", label: text.name }],
      selection, filterId: state.filterId,
      choices: [{ id: null, label: text.all }, ...state.collections.map(item => ({ id: item.id, label: item.name }))],
      collections: state.collections.map(item => ({ ...clone(item), actions: [
        { actionId: "rename", label: text.rename, collectionId: item.id },
        { actionId: "delete", label: text.delete, collectionId: item.id, confirmationRequired: true },
      ] })),
      actions: [
        { actionId: "create", label: text.create }, { actionId: "filter", label: text.filter },
        ...(selection.length ? [{ actionId: "add", label: text.add, gameIds: selection }, { actionId: "remove", label: text.remove, gameIds: selection }] : []),
        { actionId: "export", label: text.export }, { actionId: "import-backup", label: text.import },
      ],
    };
  }
  return {
    activate: () => serial(async () => { await read(); active = true; }),
    // Persistent memberships and the shared filter survive disable/re-enable.
    // An inactive module supplies no contributions or filtered results.
    deactivate: () => serial(async () => { active = false; }),
    contributions: (context = {}) => serial(async () => {
      if (!active) return [];
      const { state } = await read();
      const text = labels[context.language] ?? labels.es;
      const result = [];
      if (context.surface === "library") {
        result.push(contribution("create", "LIBRARY_ACTION", text.create, "open"));
        result.push(contribution("filter-library", "LIBRARY_ACTION", text.filter, "open", { selectedCollectionId: state.filterId }));
        const selection = gameIds(context.selection ?? []);
        if (selection.length) {
          result.push(contribution("add", "LIBRARY_SELECTION_ACTION", text.add, "open-add", { gameIds: selection }));
          if (state.collections.some(item => item.gameIds.some(id => selection.includes(id)))) {
            result.push(contribution("remove", "LIBRARY_SELECTION_ACTION", text.remove, "open-remove", { gameIds: selection }));
          }
        }
      }
      if (context.surface === "game" && context.gameId) result.push(contribution("game", "GAME_LAUNCH_ACTION", text.title, "open", { gameIds: [context.gameId] }));
      if (context.surface === "saves") result.push(contribution("filter-saves", "SAVE_ACTION", text.filter, "open", { selectedCollectionId: state.filterId }));
      if (context.surface === "settings") result.push(contribution("manage", "SETTINGS_SECTION", text.manage, "open"));
      return result;
    }),
    dispatch: (actionId, payload = {}, context = {}) => serial(async () => {
      requireActive();
      if (["open", "open-add", "open-remove"].includes(actionId)) {
        if (actionId !== "open") await selected(payload.gameIds ?? context.selection ?? []);
        const { state } = await read();
        const model = panel(state, { ...context, selection: payload.gameIds ?? context.selection }, context.language);
        if (actionId === "open-remove") {
          model.collections = model.collections.filter(item => item.gameIds.some(id => model.selection.includes(id)));
          model.choices = model.collections.map(item => ({ id: item.id, label: item.name }));
        }
        return model;
      }
      if (actionId === "export") return clone((await read()).state);
      if (actionId === "games") {
        const games = await snapshotGames();
        const { state } = await read();
        return games.filter(game => matchesGame(state, game.id));
      }
      if (actionId === "saves") {
        const saves = await host.saves.list();
        if (!Array.isArray(saves) || saves.some(save => typeof save.gameId !== "string")) error("invalid-saves-response");
        const { state } = await read();
        return clone(saves.filter(save => matchesGame(state, save.gameId)));
      }
      let ids;
      if (["add", "remove", "create", "set-favorite"].includes(actionId) && payload.gameIds !== undefined) ids = await selected(payload.gameIds);
      if (["add", "remove"].includes(actionId) && !ids) error("no-games-selected");
      return write(state => {
        switch (actionId) {
          case "set-favorite": {
            if(!ids || typeof payload.checked!=="boolean")error("invalid-favorite-request");
            const item=ensureCollection(state,"Favoritos");
            item.gameIds=payload.checked?[...new Set([...item.gameIds,...ids])]:item.gameIds.filter(id=>!ids.includes(id));
            return {checked:payload.checked};
          }
          case "ensure-default": return ensureCollection(state, "Favoritos");
          case "create": {
            const item = ensureCollection(state, payload.name);
            if (ids) item.gameIds = [...new Set([...item.gameIds, ...ids])];
            state.filterId = item.id;
            return item;
          }
          case "add": {
            const item = payload.collectionId ? findCollection(state, payload.collectionId) : ensureCollection(state, payload.name);
            item.gameIds = [...new Set([...item.gameIds, ...ids])];
            return item;
          }
          case "remove": {
            const item = findCollection(state, payload.collectionId);
            item.gameIds = item.gameIds.filter(id => !ids.includes(id));
            if (state.filterId === item.id) state.filterId = null;
            return item;
          }
          case "rename": {
            const item = findCollection(state, payload.collectionId);
            const name = normalizeName(payload.name);
            if (isBaseFavorites(item.name) || isBaseFavorites(name)) error("reserved-collection");
            if (state.collections.some(other => other.id !== item.id && other.name.toLowerCase() === name.toLowerCase())) error("duplicate-name");
            item.name = name;
            return item;
          }
          case "delete": {
            if (payload.confirmed !== true) error("confirmation-required");
            const item = findCollection(state, payload.collectionId);
            if(isBaseFavorites(item.name)) error("reserved-collection");
            state.collections = state.collections.filter(other => other.id !== item.id);
            if (state.filterId === item.id) state.filterId = null;
            return { deletedId: item.id }; // Never deletes a game or a save.
          }
          case "filter": {
            if (payload.collectionId !== null) findCollection(state, payload.collectionId);
            state.filterId = payload.collectionId;
            return { filterId: state.filterId };
          }
          case "import-legacy": return importLegacy(state, payload.snapshot);
          case "import-backup": importBackup(state, payload.snapshot); return { imported: true };
          default: return error("unknown-action");
        }
      });
    }),
  };
}
