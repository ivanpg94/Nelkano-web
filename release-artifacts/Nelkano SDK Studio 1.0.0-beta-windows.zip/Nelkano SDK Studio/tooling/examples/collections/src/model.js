// Pure domain operations. No Android, Node, network or filesystem dependencies.
export class CollectionError extends Error {
  constructor(code) { super(code); this.name = "CollectionError"; this.code = code; }
}
const fail = code => { throw new CollectionError(code); };
export const clone = value => JSON.parse(JSON.stringify(value));
const key = name => name.toLowerCase();
export function normalizeName(raw) {
  if (typeof raw !== "string") return fail("invalid-name");
  const value = raw.trim().replace(/\s+/g, " ");
  if (!value || /[\u0000-\u0008\u000e-\u001f\u007f]/.test(value)) return fail("invalid-name");
  return value;
}
export const isBaseFavorites = name => key(name) === "favoritos";
export function gameIds(values) {
  if (!Array.isArray(values) || values.some(id => typeof id !== "string" || !id.trim())) return fail("invalid-game-ids");
  return [...new Set(values)];
}
export function emptyState() {
  return { schemaVersion: 1, nextId: 1, collections: [], filterId: null };
}
export function validateState(state) {
  if (!state || state.schemaVersion !== 1 || !Number.isSafeInteger(state.nextId) || state.nextId < 1 ||
      !Array.isArray(state.collections)) return fail("invalid-state");
  const ids = new Set(), names = new Set();
  for (const item of state.collections) {
    if (!item || !/^c[1-9][0-9]*$/.test(item.id)) return fail("invalid-state");
    const number = Number(item.id.slice(1));
    if (!Number.isSafeInteger(number) || number >= state.nextId) return fail("invalid-state");
    const name = normalizeName(item.name);
    if (name !== item.name || ids.has(item.id) || names.has(key(name))) return fail("invalid-state");
    if (gameIds(item.gameIds).length !== item.gameIds.length) return fail("invalid-state");
    ids.add(item.id); names.add(key(name));
  }
  if (state.filterId !== null && !ids.has(state.filterId)) return fail("invalid-state");
  return state;
}
export function findCollection(state, id) {
  return state.collections.find(item => item.id === id) ?? fail("collection-not-found");
}
export function ensureCollection(state, rawName) {
  const name = normalizeName(rawName);
  const existing = state.collections.find(item => key(item.name) === key(name));
  if (existing) return existing;
  if (state.nextId >= Number.MAX_SAFE_INTEGER) return fail("id-limit");
  const item = { id: `c${state.nextId++}`, name, gameIds: [] };
  state.collections.push(item);
  return item;
}
export function parseLegacyNames(raw) {
  if (Array.isArray(raw)) return raw.map(normalizeName);
  if (typeof raw !== "string") return fail("invalid-legacy-data");
  if (!raw.trim()) return [];
  let parsed;
  try { parsed = JSON.parse(raw); } catch {
    // Same legacy delimiter fallback; the caller retains the untouched export.
    return raw.split(/[;,|]/).filter(value => value.trim()).map(normalizeName);
  }
  if (!Array.isArray(parsed)) return fail("invalid-legacy-data");
  return parsed.map(normalizeName);
}
export function importLegacy(state, snapshot) {
  if (!snapshot || !Array.isArray(snapshot.games)) return fail("invalid-legacy-data");
  const favoriteGameIds = new Set();
  for (const name of parseLegacyNames(snapshot.catalog ?? [])) {
    ensureCollection(state, name);
  }
  for (const game of snapshot.games) {
    gameIds([game.gameId]);
    for (const name of parseLegacyNames(game.collections)) {
      if (isBaseFavorites(name)) favoriteGameIds.add(game.gameId);
      const item = ensureCollection(state, name);
      item.gameIds = [...new Set([...item.gameIds, game.gameId])];
    }
  }
  return { favoriteGameIds: [...favoriteGameIds] };
}
export function importBackup(state, backup) {
  validateState(backup);
  for (const original of backup.collections) {
    const item = ensureCollection(state, original.name);
    item.gameIds = [...new Set([...item.gameIds, ...original.gameIds])];
  }
}
export function matchesGame(state, id) {
  return state.filterId === null || findCollection(state, state.filterId).gameIds.includes(id);
}
