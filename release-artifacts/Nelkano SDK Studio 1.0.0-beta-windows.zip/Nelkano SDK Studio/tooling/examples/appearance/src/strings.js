// Migrated literal bilingual texts. Dynamic texts use dispatch(translate).
export const strings = {
  "text.b7a67436ffc8da84": {
    "en": "Home",
    "es": "Inicio"
  },
  "text.15b5af5308815359": {
    "en": "Library",
    "es": "Biblioteca"
  },
  "text.dd9560d48c070e11": {
    "en": "Saves",
    "es": "Guardados"
  },
  "text.24cd3d5db563dc7c": {
    "en": "Settings",
    "es": "Ajustes"
  },
  "text.51af1ddc1b2b5584": {
    "en": "LANGUAGE",
    "es": "IDIOMA"
  },
  "text.6bc141ad7996a782": {
    "en": "Language",
    "es": "Idioma"
  },
  "text.f9f5029f1560955d": {
    "en": "Interface language",
    "es": "Idioma de la interfaz"
  },
  "text.2b2289a80acaa34a": {
    "en": "Nelkano account",
    "es": "Cuenta Nelkano"
  },
  "text.274d65446992634a": {
    "en": "Login",
    "es": "Login"
  },
  "text.4cdfa9c1d6f4c6bf": {
    "en": "Close session",
    "es": "Cerrar sesión"
  },
  "text.0ea557f981d14a6b": {
    "en": "General",
    "es": "General"
  },
  "text.a4bc0ff50f5c87ae": {
    "en": "Controllers",
    "es": "Mandos"
  },
  "text.7d57132c159fc3c2": {
    "en": "ON-SCREEN CONTROLS",
    "es": "CONTROLES EN PANTALLA"
  },
  "text.bee2bd4f6bc9c827": {
    "en": "Control editor",
    "es": "Editor de controles"
  },
  "text.ef0bd035c8ee75b3": {
    "en": "Move, resize or hide controls for each console and orientation",
    "es": "Mueve, escala u oculta controles por consola y orientacion"
  },
  "text.d8fb2ab8b60993ef": {
    "en": "Open",
    "es": "Abrir"
  },
  "text.16b8096799bbac21": {
    "en": "PHYSICAL GAMEPAD",
    "es": "MANDO FISICO"
  },
  "text.57ac53f37fe6d6d3": {
    "en": "Button mapping",
    "es": "Asignacion de botones"
  },
  "text.6cedb0d2f1710dd2": {
    "en": "Assign buttons and save controller profiles",
    "es": "Asigna botones y guarda perfiles de mando"
  },
  "text.1bf8d0cc545915a3": {
    "en": "View",
    "es": "Ver"
  },
  "text.0dbef8f7ab9fb48f": {
    "en": "Gamepad",
    "es": "Mando"
  },
  "text.9cdbd8353fa73d8b": {
    "en": "Check buttons, D-pad and analog sticks",
    "es": "Comprueba botones, cruceta y sticks analogicos"
  },
  "text.ac9af7cd9c1663f9": {
    "en": "Control layout saved",
    "es": "Diseno de controles guardado"
  },
  "text.0b5bf8fad05bf95b": {
    "en": "Experimental multicore renderer",
    "es": "Render multinucleo experimental"
  },
  "text.fda8bf006b9aaef1": {
    "en": "Render compatible graphics with three CPU workers; unsupported draws stay serial",
    "es": "Renderiza graficos compatibles con tres hilos; los dibujos no compatibles siguen en serie"
  },
  "text.8e9edc0d5ab2689d": {
    "en": "Experimental Vulkan renderer",
    "es": "Renderer Vulkan experimental"
  },
  "text.0d4a731cc4fd992b": {
    "en": "Uses the GPU for compatible PICA draws; restart the game after changing it",
    "es": "Usa la GPU para dibujos PICA compatibles; reinicia el juego tras cambiarlo"
  },
  "text.0b9c98a95198b85a": {
    "en": "No BIOS required",
    "es": "No requiere BIOS"
  },
  "text.8b31e9665656c6db": {
    "en": "Use decrypted games. System fonts and audio are built in.",
    "es": "Usa juegos descifrados. Las fuentes del sistema y el audio estan integrados."
  },
  "text.7624f7bf1a58a8f9": {
    "en": "APPEARANCE",
    "es": "APARIENCIA"
  },
  "text.7a0c8b7219d22983": {
    "en": "Theme",
    "es": "Tema"
  },
  "text.73bd57db0f345372": {
    "en": "EMULATION",
    "es": "EMULACIÓN"
  },
  "text.ebabc27c6ada82ee": {
    "en": "Auto saves",
    "es": "Autoguardados"
  },
  "text.0eca4f1518cf3e37": {
    "en": "Autosave is overwritten every minute while playing",
    "es": "Autoguardado se sobrescribe cada minuto jugando"
  },
  "text.c219ff2757e9d3ca": {
    "en": "Yes",
    "es": "Sí"
  },
  "text.d1960d5064854c5d": {
    "en": "OAuth connected",
    "es": "OAuth conectado"
  },
  "text.d01defa42e5528e4": {
    "en": "OAuth not connected",
    "es": "Sin login OAuth"
  },
  "text.3907301508c3563c": {
    "en": "Upload all to Google Drive",
    "es": "Subir todo a Google Drive"
  },
  "text.389487f08aeb7287": {
    "en": "Drive API · Nelkano Sync folder",
    "es": "Drive API · carpeta Nelkano Sync"
  },
  "text.8136e64bcbc27c98": {
    "en": "Connected",
    "es": "Conectado"
  },
  "text.99fe0c1dd99ba76d": {
    "en": "No login",
    "es": "Sin login"
  },
  "text.b77dfc4b9bad1e16": {
    "en": "Download all from Google Drive",
    "es": "Bajar todo de Google Drive"
  },
  "text.51098f72292b3e3b": {
    "en": "Drive API · import from Nelkano Sync",
    "es": "Drive API · importa desde Nelkano Sync"
  },
  "text.c8ddd795d55c79e8": {
    "en": "Delete cloud data",
    "es": "Eliminar datos en la nube"
  },
  "text.ee820774e0d1d788": {
    "en": "Deletes only Nelkano Sync in Drive; local data is kept",
    "es": "Borra solo Nelkano Sync en Drive; local se conserva"
  },
  "text.9015d9c46e732a98": {
    "en": "Delete",
    "es": "Eliminar"
  },
  "text.db7cc7a0aff56c9b": {
    "en": "TRANSLATION",
    "es": "TRADUCCIÓN"
  },
  "text.ea90972031d0e74e": {
    "en": "API key for translation",
    "es": "Clave API para traducción"
  },
  "text.484c5688cd729873": {
    "en": "Saved",
    "es": "Guardada"
  },
  "text.e6b567012bca2d79": {
    "en": "Set up",
    "es": "Configurar"
  },
  "text.8d84ba8289c68c99": {
    "en": "MODULES",
    "es": "MODULOS"
  },
  "text.e014b0bce62c8324": {
    "en": "Bluetooth Gamepad",
    "es": "Mando Bluetooth"
  },
  "text.ee8a9ff8e8c80931": {
    "en": "Android Gamepad, Joystick and D-pad",
    "es": "Android Gamepad, Joystick y D-pad"
  },
  "text.134bfda5e8c5e02c": {
    "en": "Movement",
    "es": "Movimiento"
  },
  "text.db2ad3b30f034402": {
    "en": "D-pad or left stick = movement",
    "es": "D-pad o stick izquierdo = movimiento"
  },
  "text.d4141f18f785722d": {
    "en": "Buttons",
    "es": "Botones"
  },
  "text.dda277116a978b66": {
    "en": "A/B = A/B buttons",
    "es": "A/B = botones A/B"
  },
  "text.6146a7339baa2370": {
    "en": "Start = Start · Select = Select",
    "es": "Start = Start · Select = Select"
  },
  "text.dd3f1847ec6c2fda": {
    "en": "Triggers = L/R",
    "es": "Triggers = L/R"
  },
  "text.840952ee0bb554bc": {
    "en": "Fullscreen",
    "es": "Pantalla completa"
  },
  "text.2b4111f0ca1d5f8f": {
    "en": "Press Home or move the stick",
    "es": "Pulsa Home o mueve el stick"
  },
  "text.75804392d23d6e1d": {
    "en": "No input detected",
    "es": "Sin entrada detectada"
  },
  "text.6a1662052a136c1d": {
    "en": "Controls",
    "es": "Controles"
  },
  "text.bb054a11529cbe57": {
    "en": "EMULATOR",
    "es": "EMULADOR"
  },
  "text.1d71dfeb6f1ecd74": {
    "en": "BUTTON ASSIGNMENT",
    "es": "ASIGNACION DE BOTONES"
  },
  "text.b9bbb00cf980a0d3": {
    "en": "Save profile",
    "es": "Guardar configuración"
  },
  "text.b3a54e1ca431cb43": {
    "en": "Load profile",
    "es": "Cargar configuración"
  },
  "text.d27989de593587a3": {
    "en": "Restore defaults",
    "es": "Restaurar valores por defecto"
  },
  "text.88de2ca7d6affcf6": {
    "en": "Controls restored to defaults",
    "es": "Controles restaurados a valores por defecto"
  },
  "text.45e53104740437c6": {
    "en": "Waiting for input for ",
    "es": "Esperando entrada para "
  },
  "text.9bafcf6a7601708b": {
    "en": "Up",
    "es": "Arriba"
  },
  "text.b31b742dbc6b2af6": {
    "en": "Down",
    "es": "Abajo"
  },
  "text.d6f64ebc83d85fa8": {
    "en": "Left",
    "es": "Izquierda"
  },
  "text.3246f6293c56b22e": {
    "en": "Right",
    "es": "Derecha"
  },
  "text.9084c7ab978558f9": {
    "en": "Press the physical button or direction now",
    "es": "Pulsa ahora el botón o dirección física"
  },
  "text.f62f9cd663223047": {
    "en": "Tap to remap",
    "es": "Toca para reasignar"
  },
  "text.0656102706bef035": {
    "en": "Auto",
    "es": "Auto"
  },
  "text.e4f27998975deb3a": {
    "en": "Visual gamepad preview",
    "es": "Vista previa visual del mando"
  },
  "text.83f9950989c3273e": {
    "en": "No",
    "es": "No"
  },
  "text.4ce0a5744e103803": {
    "en": "Theme mode",
    "es": "Modo de tema"
  },
  "text.0b1bb47942ad2fff": {
    "en": "Selected",
    "es": "Activo"
  },
  "text.bbffc8b0cc31fbc9": {
    "en": "Gamepad mapping and fullscreen",
    "es": "Mapeo de mando y pantalla completa"
  },
  "text.808cf5baaf85604f": {
    "en": "Change view",
    "es": "Cambiar visualización"
  },
  "text.2fef8a24262ce0f5": {
    "en": "All games",
    "es": "Todos los juegos"
  },
  "text.0dbe810b4a1a6249": {
    "en": "Sort alphabetically",
    "es": "Ordenar alfabeticamente"
  },
  "text.e5e312391125bccf": {
    "en": "Oldest first",
    "es": "Mas antiguos primero"
  },
  "text.922a1a67dcc258d6": {
    "en": "Newest first",
    "es": "Mas recientes primero"
  },
  "text.a7cf82c15d51eb42": {
    "en": "Select game",
    "es": "Seleccionar juego"
  },
  "text.9d52fcfc62130d09": {
    "en": "There are no games with save files.",
    "es": "No hay juegos con guardados."
  },
  "text.f1f752ea1cfc0e55": {
    "en": "Loading save files...",
    "es": "Cargando archivos de guardado..."
  },
  "text.702e2075440064fb": {
    "en": "No save files",
    "es": "No hay archivos de guardado"
  },
  "text.181dcd4fc97741d6": {
    "en": "All",
    "es": "Todos"
  },
  "text.4d80932d9e8da630": {
    "en": "Collections",
    "es": "Colecciones"
  },
  "text.b271da959b666f8d": {
    "en": "Create collection",
    "es": "Crear coleccion"
  },
  "text.86054e40f7ea6524": {
    "en": "All",
    "es": "Todas"
  },
  "text.5f60b499ce8a6e1b": {
    "en": "Select console",
    "es": "Seleccionar consola"
  },
  "text.79f0e10b20206b30": {
    "en": "Delete save state",
    "es": "Eliminar estado"
  },
  "text.f2c58bbb6ecd513e": {
    "en": "Delete this save state?",
    "es": "Eliminar este guardado?"
  },
  "text.063d51d1196403e2": {
    "en": "Cancel",
    "es": "Cancelar"
  },
  "text.304176148fc7377b": {
    "en": "Cart",
    "es": "Cartucho"
  },
  "text.5132f1f9abfb2cae": {
    "en": "Autosave",
    "es": "Autoguardado"
  },
  "text.219558601f84390d": {
    "en": "Pokemon Nelkano is still starting. Please wait.",
    "es": "Pokemon Nelkano todavia esta iniciando. Espera un momento."
  },
  "text.c263cde00f1aaab9": {
    "en": "Add file",
    "es": "Añadir archivo"
  },
  "text.076c53938690b9ec": {
    "en": "Tap Drive to read your remote library or Add to import a compatible file.",
    "es": "Pulsa Drive para leer tu biblioteca remota o Añadir para importar un archivo compatible."
  },
  "text.f526b912826004ac": {
    "en": "There are no files for this filter.",
    "es": "No hay archivos para este filtro."
  },
  "text.6ceb1c5e66952980": {
    "en": "Friends",
    "es": "Amigos"
  },
  "text.462b308a1ce206c3": {
    "en": "Reset filters",
    "es": "Restablecer filtros"
  },
  "text.c386cdc82d31a87b": {
    "en": "selected",
    "es": "seleccionados"
  },
  "text.f53190fd757fa625": {
    "en": "Add",
    "es": "Anadir"
  },
  "text.d48ea0b120a8006a": {
    "en": "Remove",
    "es": "Quitar"
  },
  "text.f9a3f3aa475e180f": {
    "en": "Close",
    "es": "Cerrar"
  },
  "text.c9dd0f817c0b283d": {
    "en": "Collection name",
    "es": "Nombre de coleccion"
  },
  "text.a8ac571a702bd281": {
    "en": "Create",
    "es": "Crear"
  },
  "text.67bf21571a2aee5d": {
    "en": "Invalid collection name.",
    "es": "Nombre de coleccion invalido."
  },
  "text.94c1e2ee353ab095": {
    "en": "Add to collection",
    "es": "Anadir a coleccion"
  },
  "text.d743fb7b5571cb27": {
    "en": "No games selected.",
    "es": "No hay juegos seleccionados."
  },
  "text.2be4372969d986cd": {
    "en": "These games are not in any collection.",
    "es": "Estos juegos no estan en ninguna coleccion."
  },
  "text.bd602851f39b1c75": {
    "en": "Remove from collection",
    "es": "Quitar de coleccion"
  },
  "text.5b2481166feb795d": {
    "en": "Delete games",
    "es": "Eliminar juegos"
  },
  "text.fe69389448bf1936": {
    "en": "Delete selected games, saves, states and screenshots?",
    "es": "Eliminar los juegos seleccionados, saves, states y capturas?"
  },
  "text.edde462bef5de973": {
    "en": "Confirm",
    "es": "Confirmar"
  },
  "text.d4f4c6327537d321": {
    "en": "Search",
    "es": "Buscar"
  },
  "text.744e4378acce3cf2": {
    "en": "Compact",
    "es": "Compacta"
  },
  "text.3d7621eac8c943aa": {
    "en": "List",
    "es": "Lista"
  },
  "text.877ddb52e3310035": {
    "en": "Large",
    "es": "Grande"
  },
  "text.4a71abbccf88104b": {
    "en": "Added: ",
    "es": "Añadido: "
  },
  "text.4e7c2048cee9d9b7": {
    "en": "Added to favorites",
    "es": "Añadido a favoritos"
  },
  "text.6c4df090f2782a9b": {
    "en": "Removed from favorites",
    "es": "Quitado de favoritos"
  },
  "text.4006ab3a9f5b53d7": {
    "en": "Continue Playing",
    "es": "Continuar jugando"
  },
  "text.0711939fa074dce0": {
    "en": "Favorites",
    "es": "Favoritos"
  },
  "text.607a1f43c3db26aa": {
    "en": "Add a compatible file from Library to start.",
    "es": "Añade un archivo compatible desde Biblioteca para empezar."
  },
  "text.4f7dafa3b19b5df2": {
    "en": "Games",
    "es": "juegos"
  },
  "text.d1fdc0cc5442d3c3": {
    "en": "Total play time",
    "es": "tiempo total de juego"
  },
  "text.530f18460d537556": {
    "en": "Waiting for account data",
    "es": "Esperando datos de cuenta"
  },
  "text.cd2dbfc89fa83fee": {
    "en": "Account play time",
    "es": "Tiempo de cuenta"
  },
  "text.b1f17925ef81fa55": {
    "en": "Platforms with activity",
    "es": "plataformas con actividad"
  },
  "text.8bba255e35524405": {
    "en": "Check Settings",
    "es": "Revisa Ajustes"
  },
  "text.131d6ee4d7af890a": {
    "en": "Account platforms",
    "es": "Plataformas de cuenta"
  },
  "text.7085598966dbf9c5": {
    "en": "Import game",
    "es": "Importar juego"
  },
  "text.7e6fcc066ed1d6bd": {
    "en": "No favorites",
    "es": "Sin favoritos"
  },
  "text.5e7e0c9e14b2c084": {
    "en": "Mark games",
    "es": "Marca juegos"
  },
  "text.4bc0dc15980726f0": {
    "en": "from Library",
    "es": "desde Biblioteca"
  },
  "text.8cc784bdfb8912a7": {
    "en": "Prepare translation",
    "es": "Preparar traducción"
  },
  "text.0d828a67570783a6": {
    "en": "Continue",
    "es": "Continuar"
  },
  "text.8a12bf4d16b0774a": {
    "en": "Play",
    "es": "Jugar"
  },
  "text.aced46a5ac92758a": {
    "en": "Upload to Drive",
    "es": "Subir a drive"
  },
  "text.b1c40f09390d0d86": {
    "en": "Syncing...",
    "es": "Sincronizando..."
  },
  "text.917498c65f9a6a8d": {
    "en": "Download from Drive",
    "es": "Bajar de drive"
  },
  "text.6f4d8499017889fe": {
    "en": "Downloading from Drive...",
    "es": "Descargando de Drive..."
  },
  "text.a3fdc2c610adc8ff": {
    "en": "Delete from Drive",
    "es": "Eliminar de drive"
  },
  "text.68e0312f7ab494a7": {
    "en": "Select image",
    "es": "Seleccionar imagen"
  },
  "text.7069a49ece164475": {
    "en": "No saves found for this game.",
    "es": "No hay guardados para este juego."
  },
  "text.7c903fd189e12b32": {
    "en": "Choose artwork",
    "es": "Elegir imagen"
  },
  "text.336ddd02e892febe": {
    "en": "Portada",
    "es": "Portada"
  },
  "text.ae366172f4302df8": {
    "en": "Use original cover",
    "es": "Usar imagen de portada"
  },
  "text.c3a4b8511c830c84": {
    "en": "Use screenshot from this slot",
    "es": "Usar captura de este slot"
  },
  "text.a55991189d9f5385": {
    "en": "Cover",
    "es": "Portada"
  },
  "text.6c16dcb0ba952356": {
    "en": "Use cover image",
    "es": "Usar imagen de portada"
  },
  "text.060a5d5d07bb6d83": {
    "en": "Could not save image.",
    "es": "No se pudo guardar la imagen."
  },
  "text.422dfa1127f354ca": {
    "en": "Use selected save screenshot",
    "es": "Usar captura del slot seleccionado"
  },
  "text.8c55d2d13dd69229": {
    "en": "No screenshot for this slot.",
    "es": "No hay captura en este slot."
  },
  "text.3f36328209174b03": {
    "en": "Download from Drive",
    "es": "Descargar desde Drive"
  },
  "text.1d09edc28d08b41d": {
    "en": "Delete from Drive",
    "es": "Eliminar de Drive"
  },
  "text.6b722743336429a6": {
    "en": "Save States",
    "es": "Guardados"
  },
  "text.020c173cb0306cd3": {
    "en": "No save states for this game.",
    "es": "Sin save states para este juego."
  },
  "text.55b6d86b130cf0df": {
    "en": "No data",
    "es": "Sin datos"
  },
  "text.435793723e2a80ed": {
    "en": "No game selected",
    "es": "No hay juego seleccionado"
  },
  "text.0d427380f110a1e6": {
    "en": "This game is not synced in Drive",
    "es": "Este juego no está sincronizado en Drive"
  },
  "text.cc32fee02f4692e9": {
    "en": "Choose what to remove from Drive.",
    "es": "Elige que quieres borrar de Drive."
  },
  "text.9e4a61261f649439": {
    "en": "Delete save files",
    "es": "Borrar solo guardados"
  },
  "text.4ea9fb9f2bf5dad3": {
    "en": "Delete all",
    "es": "Borrar todo"
  },
  "text.3fff59df6a416950": {
    "en": "Delete this game from Drive?",
    "es": "Eliminar este juego de Drive?"
  },
  "text.0002fc49d1f242df": {
    "en": "Drive game deleted.",
    "es": "Juego borrado de Drive."
  },
  "text.fc50889182b4a31c": {
    "en": "Game is not in Drive",
    "es": "El juego no esta en Drive"
  },
  "text.4a6e15ee2bba03bf": {
    "en": "Delete game",
    "es": "Eliminar juego"
  },
  "text.260e7065ad2454a2": {
    "en": "Delete this game from library?",
    "es": "Eliminar este juego de la biblioteca?"
  },
  "text.c30fa24a0a9078be": {
    "en": "Rename game",
    "es": "Renombrar juego"
  },
  "text.cdaf2023ae7e4957": {
    "en": "Save",
    "es": "Guardar"
  },
  "text.027096953da33c61": {
    "en": "The name cannot be empty.",
    "es": "El nombre no puede estar vacio."
  },
  "text.8401e01e7dd04bd5": {
    "en": "Nelkano Online",
    "es": "Nelkano Online"
  },
  "text.d93c0b5ce13c60ab": {
    "en": "Both screens",
    "es": "Ambas pantallas"
  },
  "text.fa0c70f1cc046318": {
    "en": "Top screen",
    "es": "Pantalla superior"
  },
  "text.046c63fe81ace2d3": {
    "en": "Bottom screen",
    "es": "Pantalla inferior"
  },
  "text.0b6369296b3a4fd6": {
    "en": "Emulator Settings",
    "es": "Configuración del emulador"
  },
  "text.e391486a805f4a2f": {
    "en": "Audio",
    "es": "Audio"
  },
  "text.159816812a3d2c1c": {
    "en": "Emulator volume",
    "es": "Volumen del emulador"
  },
  "text.5361b3c9ced1e980": {
    "en": "Quick saves",
    "es": "Guardados rápidos"
  },
  "text.227ff24645ab7f78": {
    "en": "Pokemon Emerald-like online layer",
    "es": "Capa online Pokemon tipo Esmeralda"
  },
  "text.bd39fde63e65f703": {
    "en": "Configure controls",
    "es": "Configurar controles"
  },
  "text.27ba0ae004be78db": {
    "en": "Button mapping and fullscreen",
    "es": "Mapeo de botones y pantalla completa"
  },
  "text.dfde7ce07ffa648e": {
    "en": "Streaming",
    "es": "Streaming"
  },
  "text.62c6601073571ed1": {
    "en": "Share the full emulator screen to the web session",
    "es": "Comparte toda la pantalla del emulador a la sesion web"
  },
  "text.86956e36ec8fc9f0": {
    "en": "Report an error",
    "es": "Reportar un error"
  },
  "text.9247f7bee6054e4b": {
    "en": "Send reproduction steps and a save-state slot",
    "es": "Envía los pasos y un slot de guardado"
  },
  "text.e0b4b02366fe2f35": {
    "en": "No active game.",
    "es": "No hay un juego activo."
  },
  "text.926e2a822151be29": {
    "en": "Log in to your Nelkano account before reporting an error.",
    "es": "Inicia sesión en tu cuenta Nelkano antes de reportar un error."
  },
  "text.95125b25461325b7": {
    "en": "Your account cannot send error reports.",
    "es": "Tu cuenta no puede enviar reportes de error."
  },
  "text.0a4d0d7dde57fc22": {
    "en": "Send us your save file from right before the incident and explain how to reproduce it.",
    "es": "Envíanos tu archivo de guardado justo antes de la incidencia y explícanos cómo reproducirlo."
  },
  "text.db6f6204276c4acd": {
    "en": "Short summary",
    "es": "Resumen breve"
  },
  "text.43a4879435068af0": {
    "en": "Summary",
    "es": "Resumen"
  },
  "text.60277eb59bacf1e7": {
    "en": "Crash",
    "es": "Cierre inesperado"
  },
  "text.082c612f7c92c416": {
    "en": "Freeze",
    "es": "Bloqueo"
  },
  "text.bc63b809ca5cdb91": {
    "en": "Graphics",
    "es": "Gráficos"
  },
  "text.716f9374d82ef7a6": {
    "en": "Performance",
    "es": "Rendimiento"
  },
  "text.364caff3b219b5a4": {
    "en": "Save state",
    "es": "Guardado"
  },
  "text.544369762eb460a5": {
    "en": "Other",
    "es": "Otro"
  },
  "text.32071df77fc274f8": {
    "en": "Type of error",
    "es": "Tipo de error"
  },
  "text.6898bfc9d4015a5f": {
    "en": "No save-state available",
    "es": "No hay slots guardados"
  },
  "text.4223ee9ab9acd0d1": {
    "en": "Attached save-state",
    "es": "Slot adjunto"
  },
  "text.b230ca1c76ebfdba": {
    "en": "Explain the exact actions after loading the state",
    "es": "Explica las acciones exactas tras cargar el slot"
  },
  "text.a91a9850cb094227": {
    "en": "Steps to reproduce",
    "es": "Pasos para reproducir"
  },
  "text.80263f045099b690": {
    "en": "What happens?",
    "es": "¿Qué ocurre?"
  },
  "text.509d2adfef5be22e": {
    "en": "Actual result",
    "es": "Resultado actual"
  },
  "text.53a28b98fb84e703": {
    "en": "What should happen?",
    "es": "¿Qué debería ocurrir?"
  },
  "text.960005b3b02b58bf": {
    "en": "Expected result",
    "es": "Resultado esperado"
  },
  "text.c248eae8fc606583": {
    "en": "I agree to send this save-state and technical device data for debugging.",
    "es": "Acepto enviar este slot y datos técnicos del dispositivo para depuración."
  },
  "text.4186b3154f8ce05c": {
    "en": "Send report",
    "es": "Enviar reporte"
  },
  "text.68ad1d8d0e057ca5": {
    "en": "Add a summary and reproduction steps.",
    "es": "Añade un resumen y los pasos de reproducción."
  },
  "text.338b95a3b7e00ed2": {
    "en": "You must accept the diagnostic data submission.",
    "es": "Debes aceptar el envío de datos de diagnóstico."
  },
  "text.b18805ee8e947096": {
    "en": "Create a save-state before sending the report.",
    "es": "Crea un slot de guardado antes de enviar el reporte."
  },
  "text.084cb68ed847be14": {
    "en": "Sending…",
    "es": "Enviando…"
  },
  "text.c9dff7fe24ef6eaa": {
    "en": "Report sent.",
    "es": "Reporte enviado."
  },
  "text.8c50ab4892812f82": {
    "en": "Could not send report: ",
    "es": "No se pudo enviar el reporte: "
  },
  "text.502081c064eea659": {
    "en": "Empty",
    "es": "Vacío"
  },
  "text.fad08b01466aeca8": {
    "en": "Not written yet",
    "es": "Aun no escrito"
  },
  "text.2f81e8a75585e9ad": {
    "en": "Cartridge backup",
    "es": "Backup de cartucho"
  },
  "text.7208f41657faaf06": {
    "en": "Shown in Saves and Drive sync",
    "es": "Aparece en Guardados y sync Drive"
  },
  "text.1acb914785e81660": {
    "en": "There is no save in this slot.",
    "es": "No hay guardado en este slot."
  },
  "text.a27f8241e0859587": {
    "en": "There are no save states to load.",
    "es": "No hay guardados para cargar."
  },
  "text.ed43c28762c8db5f": {
    "en": "Load",
    "es": "Cargar"
  },
  "text.d14332b9a923f390": {
    "en": "Empty slot",
    "es": "Slot vacio"
  },
  "text.6775d81de9bc1084": {
    "en": "Reset",
    "es": "Resetear"
  },
  "text.a52b0a68fd622c71": {
    "en": "Quit Project Zomboid?",
    "es": "¿Salir de Project Zomboid?"
  },
  "text.6d97ad44b749a7dd": {
    "en": "Unsaved progress is lost. Save from the game menu (ESC) first.",
    "es": "Se pierde lo que no esté guardado. Guarda antes desde el menú del juego (ESC)."
  },
  "text.bd3e0c527503210d": {
    "en": "Quit",
    "es": "Salir"
  },
  "text.167f36e703e28838": {
    "en": "Audio permission is required for WebRTC streaming.",
    "es": "El permiso de audio es obligatorio para el streaming WebRTC."
  },
  "text.122a19bf825cd0ae": {
    "en": "Syncing Drive",
    "es": "Sincronizando Drive"
  },
  "text.e43c5cddfb9fb690": {
    "en": "Drive API path delete is unavailable.",
    "es": "No está disponible el borrado de rutas de Drive."
  },
  "text.17bca9e1d3a9a5c1": {
    "en": "Drive saves deleted from Drive.",
    "es": "Guardados borrados de Drive."
  },
  "text.22c95b482f024344": {
    "en": "Game is not in Drive",
    "es": "El juego no está en Drive"
  },
  "text.fde9e7d393046da2": {
    "en": "Downloading Drive catalog...",
    "es": "Descargando catálogo de Drive..."
  },
  "text.f997505b755ec7d7": {
    "en": "Downloading from Drive ",
    "es": "Descargando de Drive "
  },
  "text.fb36e6292f894a08": {
    "en": "Delete all Nelkano cloud data from Google Drive?\nLocal files, saves and states will NOT be deleted.",
    "es": "Eliminar todos los datos de Nelkano en Google Drive?\nLos archivos locales, saves y estados NO se borraran."
  },
  "text.85264cb51191f3e9": {
    "en": "Invalid Drive parent id",
    "es": "Id padre de Drive inválido"
  },
  "text.2c68627a58968af9": {
    "en": "Invalid Drive folder name",
    "es": "Nombre de carpeta de Drive inválido"
  },
  "text.3b3fcb529a20214e": {
    "en": "Invalid Drive file name",
    "es": "Nombre de fichero Drive inválido"
  },
  "text.48efb73a70cdfbc1": {
    "en": "No Drive errors recorded.",
    "es": "Sin errores en Drive registrados."
  },
  "text.683014bcd6437141": {
    "en": "Could not read the log: ",
    "es": "No se pudo leer el log: "
  },
  "text.bdab11a1262c35bb": {
    "en": "Drive log cleared.",
    "es": "Log de Drive borrado."
  },
  "text.79efd7b0af1187b6": {
    "en": "Drive Log",
    "es": "Log de Drive"
  },
  "text.931439feee6d85b9": {
    "en": "Loading...",
    "es": "Cargando..."
  },
  "text.789c2ffe1f274d02": {
    "en": "Refresh",
    "es": "Actualizar"
  },
  "text.9351b0d1e67faa32": {
    "en": "Clear",
    "es": "Borrar"
  },
  "text.1028e715bd88406b": {
    "en": "This game is not synced in Drive",
    "es": "Este juego no esta sincronizado en Drive"
  },
  "text.51a74940fe7fdcdc": {
    "en": "Updating Drive catalog...",
    "es": "Actualizando catálogo de Drive..."
  },
  "text.c6f89b2c8da380d8": {
    "en": "Drive / sync folder linked.",
    "es": "Carpeta Drive / sync vinculada."
  },
  "text.f65c412b98b4f907": {
    "en": "Choose a Drive / sync folder first.",
    "es": "Elige primero una carpeta Drive / sync."
  },
  "text.645a02c537396d22": {
    "en": "Sync exported: ",
    "es": "Sync exportado: "
  },
  "text.aa37a170fd9368ad": {
    "en": " games.",
    "es": " juegos."
  },
  "text.f6ee8478f79b3357": {
    "en": "Could not export sync: ",
    "es": "No se pudo exportar sync: "
  },
  "text.0600811319a12292": {
    "en": "manifest.json does not exist in the linked folder.",
    "es": "No existe manifest.json en la carpeta vinculada."
  },
  "text.84fd4ba19f037dc7": {
    "en": "manifest.json does not contain a library.",
    "es": "manifest.json no contiene biblioteca."
  },
  "text.e27e41a30ee33c8b": {
    "en": "Sync imported: ",
    "es": "Sync importado: "
  },
  "text.208e09b4dd43af40": {
    "en": " games, ",
    "es": " juegos, "
  },
  "text.4bbb6bb9085d3059": {
    "en": " saves.",
    "es": " guardados."
  },
  "text.e78c5b79a87529ff": {
    "en": " PS1 data pending a local disc: ",
    "es": " Datos PS1 pendientes de un disco local: "
  },
  "text.74e2b16aa251e6dc": {
    "en": "Could not import sync: ",
    "es": "No se pudo importar sync: "
  },
  "text.d2e4f3ba54d5e934": {
    "en": "Start stream",
    "es": "Iniciar emision"
  },
  "text.d88d6b78d2560296": {
    "en": "Stop stream",
    "es": "Detener emision"
  },
  "text.067da8e34c6b2cc4": {
    "en": "Stopped by user",
    "es": "Detenida por el usuario"
  },
  "text.97a9f1a8d6e1388b": {
    "en": "Log in to your Nelkano account before streaming.",
    "es": "Inicia sesion con tu cuenta Nelkano antes de emitir."
  },
  "text.6460f83fe52de0f3": {
    "en": "Your account cannot use streaming.",
    "es": "Tu cuenta no puede usar el streaming."
  },
  "text.72a1d700ab570df7": {
    "en": "Open a game first to start streaming.",
    "es": "Abre primero un juego para iniciar la emision."
  },
  "text.11eae3e4b3fe67c0": {
    "en": "Starting streaming...",
    "es": "Iniciando streaming..."
  },
  "text.a88f2990261ab58f": {
    "en": "State: ",
    "es": "Estado: "
  },
  "text.58f0ec730d63f375": {
    "en": "Session: not started",
    "es": "Sesion: no iniciada"
  },
  "text.6b50a44b26685214": {
    "en": "Web session ready. Open Streaming on nelkano.com with this same account.",
    "es": "Sesion web lista. Abre Streaming en nelkano.com con esta misma cuenta."
  },
  "text.63b5ee16810991fb": {
    "en": "Video",
    "es": "Video"
  },
  "text.dbed879551be325d": {
    "en": "Idle",
    "es": "Idle"
  },
  "text.cbf43406a7e6d295": {
    "en": "Preparing stream",
    "es": "Preparando emision"
  },
  "text.0d68426c50ee9c7f": {
    "en": "Waiting receiver",
    "es": "Esperando receptor"
  },
  "text.a548ab87bcefbfa0": {
    "en": "Connecting",
    "es": "Conectando"
  },
  "text.20af39782d562eb4": {
    "en": "Error",
    "es": "Error"
  },
  "text.1d310745c68803e4": {
    "en": "Finished",
    "es": "Finalizado"
  },
  "text.dbd00ddda404f8df": {
    "en": "Waiting for friend in Pokemon Nelkano...",
    "es": "Esperando al amigo en Pokemon Nelkano..."
  },
  "text.558005921593d6fa": {
    "en": "One player must be Host and the other Guest.",
    "es": "Un jugador debe ser Host y el otro Invitado."
  },
  "text.7343a5dfcd13b953": {
    "en": "The other player did not connect in time.",
    "es": "El otro jugador no conecto a tiempo."
  },
  "text.f5895fd6c6d99292": {
    "en": "Start a game first.",
    "es": "Inicia un juego primero."
  },
  "text.acc656792860f60a": {
    "en": "Nelkano Online V1 is only available for Pokemon Emerald-like GBA ROMs.",
    "es": "Nelkano Online V1 solo esta disponible para ROMs GBA tipo Pokemon Esmeralda."
  },
  "text.07d2fb4b2e09f52b": {
    "en": "Host",
    "es": "Host"
  },
  "text.3de21008341fa619": {
    "en": "Guest",
    "es": "Invitado"
  },
  "text.ebfc4245acf17137": {
    "en": "Connect online layer",
    "es": "Conectar capa online"
  },
  "text.eb2ce97ace83b988": {
    "en": "No accepted friends available.",
    "es": "No hay amigos aceptados disponibles."
  },
  "text.6444449a71338e47": {
    "en": "Disconnect",
    "es": "Desconectar"
  },
  "text.60886f9b5fc0b342": {
    "en": "Start a compatible Pokemon GBA game first.",
    "es": "Inicia primero un juego Pokemon GBA compatible."
  },
  "text.f994e2312b7cf453": {
    "en": "Import Pokemon Nelkano into the RPG Maker library first.",
    "es": "Importa primero Pokemon Nelkano en la biblioteca de RPG Maker."
  },
  "text.64e61296a8c7ba74": {
    "en": "Opening Pokemon Nelkano with ",
    "es": "Abriendo Pokemon Nelkano con "
  },
  "text.8c8078173346fb59": {
    "en": "The trainer party could not be read from GBA memory.",
    "es": "No se pudo leer el entrenador y su equipo desde la memoria GBA."
  },
  "text.eba3f12753f279e7": {
    "en": "Could not prepare the RPG Maker session: ",
    "es": "No se pudo preparar la sesion de RPG Maker: "
  },
  "text.3a7f9b15327c0b20": {
    "en": "Could not load friends.",
    "es": "No se pudieron cargar los amigos."
  },
  "text.d3bba2e04e5dd875": {
    "en": "Could not identify this ROM.",
    "es": "No se pudo identificar esta ROM."
  },
  "text.596b4a94891b425b": {
    "en": "Waiting for friend...",
    "es": "Esperando al amigo..."
  },
  "text.42bc14e607960074": {
    "en": "Waiting for the other player.",
    "es": "Esperando al otro jugador."
  },
  "text.92b035581e7122a2": {
    "en": "Reconnecting...",
    "es": "Reconectando..."
  },
  "text.fefe856c6d433263": {
    "en": "Online error.",
    "es": "Error online."
  },
  "text.0a554c114df75448": {
    "en": "Online closed.",
    "es": "Online cerrado."
  },
  "text.28b0484f64e326d7": {
    "en": "Disconnected",
    "es": "Desconectado"
  },
  "text.d6c722066a24b531": {
    "en": "Waiting for player (1/2)",
    "es": "Esperando jugador (1/2)"
  },
  "text.d692c5dc8557f2f6": {
    "en": "Connected (2/2)",
    "es": "Conectado (2/2)"
  },
  "text.4dc7b8eac0b32c51": {
    "en": "Sign in to manage friends.",
    "es": "Inicia sesion para gestionar amigos."
  },
  "text.a68f086e9d1e2651": {
    "en": "Log in",
    "es": "Iniciar sesion"
  },
  "text.bac2dc4114767360": {
    "en": "Your account cannot use friends.",
    "es": "Tu cuenta no puede usar amigos."
  },
  "text.43e70367e26d88c2": {
    "en": "Edit profile",
    "es": "Editar perfil"
  },
  "text.a09a76ac10b2516e": {
    "en": "Loading profile...",
    "es": "Cargando perfil..."
  },
  "text.87c7f3827fbd254e": {
    "en": "Profile",
    "es": "Perfil"
  },
  "text.1810f8c28cc4fac9": {
    "en": "Back",
    "es": "Volver"
  },
  "text.6a6914e7adcbc120": {
    "en": "Role",
    "es": "Rol"
  },
  "text.80eb5a39e848d441": {
    "en": "Visible username",
    "es": "Usuario visible"
  },
  "text.4e645cff16de97ce": {
    "en": "Status",
    "es": "Estado"
  },
  "text.5a19a9343a597b5d": {
    "en": "Avatar color",
    "es": "Color del avatar"
  },
  "text.c46d0e23076be121": {
    "en": "Profile image",
    "es": "Imagen de perfil"
  },
  "text.4bc7134c0c4261b8": {
    "en": "Change image",
    "es": "Cambiar imagen"
  },
  "text.74a5ba2aeccb5bae": {
    "en": "Save profile",
    "es": "Guardar perfil"
  },
  "text.d0093bc9600eea5f": {
    "en": "Use at least 2 characters.",
    "es": "Usa al menos 2 caracteres."
  },
  "text.a48de5950458933b": {
    "en": "Saving profile...",
    "es": "Guardando perfil..."
  },
  "text.4ada982cdd476afc": {
    "en": "Profile saved.",
    "es": "Perfil guardado."
  },
  "text.27d72411a11db3be": {
    "en": "Could not open image.",
    "es": "No se pudo abrir la imagen."
  },
  "text.c9e55195e00c5ec1": {
    "en": "Image is too large.",
    "es": "La imagen es demasiado grande."
  },
  "text.97ab3835d7a9e66c": {
    "en": "Image selected",
    "es": "Imagen seleccionada"
  },
  "text.21b479a11653a878": {
    "en": "Selected: ",
    "es": "Seleccionada: "
  },
  "text.c581eac9292ef64c": {
    "en": "Image selected.",
    "es": "Imagen seleccionada."
  },
  "text.6a136ca7d61a9c4e": {
    "en": "Search user",
    "es": "Buscar usuario"
  },
  "text.e51ec36852225531": {
    "en": "Search results",
    "es": "Resultados"
  },
  "text.e614c407dbfb2134": {
    "en": "Searching...",
    "es": "Buscando..."
  },
  "text.ff9c64d954ddc93c": {
    "en": "No active user found.",
    "es": "No se encontro ningun usuario activo."
  },
  "text.59c4654304ebc436": {
    "en": "Loading friends...",
    "es": "Cargando amigos..."
  },
  "text.7a7d3fc7b594987d": {
    "en": "Pending received",
    "es": "Solicitudes recibidas"
  },
  "text.2f9702baff484d27": {
    "en": "Pending sent",
    "es": "Solicitudes enviadas"
  },
  "text.f968dfd2770c94e6": {
    "en": "Nothing here.",
    "es": "Nada aqui."
  },
  "text.d58ecda710788472": {
    "en": "Reject",
    "es": "Rechazar"
  },
  "text.88f18b1c9d69ce84": {
    "en": "Accept",
    "es": "Aceptar"
  },
  "text.d1e8b63c00fb736b": {
    "en": "Remove",
    "es": "Eliminar"
  },
  "text.ea0a0d25c89156d2": {
    "en": "Updating friends...",
    "es": "Actualizando amigos..."
  },
  "text.9f685d9b1fe4d4d8": {
    "en": "Write a user name or email.",
    "es": "Escribe un nombre o email."
  },
  "text.b9ed074b4b585b5a": {
    "en": "Friend request sent.",
    "es": "Solicitud enviada."
  },
  "text.8549d3726197941b": {
    "en": "Search failed.",
    "es": "No se pudo buscar."
  },
  "text.fb4265a3f16c43df": {
    "en": "Sending friend request...",
    "es": "Enviando solicitud..."
  },
  "text.94f910628ee77fef": {
    "en": "Cable link is only available in GBA.",
    "es": "Cable link solo esta disponible en GBA."
  },
  "text.91fb8c07b5ae6a25": {
    "en": "Cable link",
    "es": "Cable link"
  },
  "text.aedc225d0fb77982": {
    "en": "Connect",
    "es": "Conectar"
  },
  "text.b491f5e9a47e6b6e": {
    "en": "Opening WebRTC cable...",
    "es": "Abriendo cable WebRTC..."
  },
  "text.3f99c6080eeb407c": {
    "en": "Session expired. Log in again.",
    "es": "Sesion caducada. Inicia sesion otra vez."
  },
  "text.899a22581a23d695": {
    "en": "Could not sync Nelkano activity: ",
    "es": "No se pudo sincronizar la actividad Nelkano: "
  },
  "text.8521bbf20c885784": {
    "en": "Could not sync: ",
    "es": "No se pudo sincronizar: "
  },
  "text.75ea1b4d463d9c28": {
    "en": "Could not sync. Check connection.",
    "es": "No se pudo sincronizar. Revisa la conexion."
  },
  "text.fd50fd91994f688b": {
    "en": "Streaming published. Open nelkano.com Streaming.",
    "es": "Streaming publicado. Abre Streaming en nelkano.com."
  },
  "text.c9ac77f2d05899ed": {
    "en": "Could not publish streaming session: ",
    "es": "No se pudo publicar la sesion de streaming: "
  },
  "text.6422ef1717b57514": {
    "en": "Not connected",
    "es": "Sin conectar"
  },
  "text.489bd67b7f15eb99": {
    "en": "Connected account",
    "es": "Cuenta conectada"
  },
  "text.579ff7b57282ec6a": {
    "en": "Administrator",
    "es": "Administrador"
  },
  "text.d8c11d71ecf282e1": {
    "en": "User",
    "es": "Usuario"
  },
  "text.2727a85dd5679084": {
    "en": "Log in",
    "es": "Iniciar sesión"
  },
  "text.cd140a756d3990bf": {
    "en": "Remember me",
    "es": "Recordarme"
  },
  "text.306c71215278499b": {
    "en": "Email",
    "es": "Correo electronico"
  },
  "text.ddf2c37064c917a0": {
    "en": "Password",
    "es": "Contrasena"
  },
  "text.bd4e6a9492b7775c": {
    "en": "Log in",
    "es": "Iniciar Sesion"
  },
  "text.58e7a8b7c4f83c32": {
    "en": "No account yet? Register",
    "es": "No tienes una cuenta? Registrate"
  },
  "text.132cfed2f673ea32": {
    "en": "Continue as guest",
    "es": "Continuar como invitado"
  },
  "text.16f2abbbac08593d": {
    "en": "Your name",
    "es": "Tu nombre"
  },
  "text.bff9a1e400d01d92": {
    "en": "I accept the terms and conditions",
    "es": "Acepto los terminos y condiciones"
  },
  "text.87cb6bb5ac347de3": {
    "en": "Name",
    "es": "Nombre"
  },
  "text.70a3cfe86601d513": {
    "en": "Create account",
    "es": "Crear Cuenta"
  },
  "text.6bdd2f8b39b63bf4": {
    "en": "Already have an account? Log in",
    "es": "Ya tienes una cuenta? Inicia sesion"
  },
  "text.8339193971ca3b66": {
    "en": "Connecting Nelkano account...",
    "es": "Conectando cuenta Nelkano..."
  },
  "text.ad8301c268b0f513": {
    "en": "Nelkano account connected.",
    "es": "Cuenta Nelkano conectada."
  },
  "text.737d2cb4724653e8": {
    "en": "Could not log in to Nelkano: ",
    "es": "No se pudo iniciar sesión en Nelkano: "
  },
  "text.9a8f4f0dcb26f0c1": {
    "en": "Enter email and password.",
    "es": "Indica email y contraseña."
  },
  "text.6cf4d032f606f91f": {
    "en": "Creating Nelkano account...",
    "es": "Creando cuenta Nelkano..."
  },
  "text.8bb03f7b1890e5a4": {
    "en": "Account created. Check your email.",
    "es": "Cuenta creada. Revisa tu correo."
  },
  "text.3dfeb93bee39d06f": {
    "en": "Could not create account: ",
    "es": "No se pudo crear la cuenta: "
  },
  "text.dd7f67ea77e65718": {
    "en": "Complete the form and accept the terms.",
    "es": "Completa el formulario y acepta los terminos."
  },
  "text.b22686bd1bb0fa60": {
    "en": "Account created",
    "es": "Cuenta creada"
  },
  "text.7af67e3c397af3cf": {
    "en": "Congratulations, your account has been created successfully.\nActivate your account from the link we sent by email.",
    "es": "Enhorabuena, su cuenta se ha creado correctamente.\nActive su cuenta desde el enlace que le hemos enviado por correo."
  },
  "text.d56170d05f80344f": {
    "en": "OK",
    "es": "Aceptar"
  },
  "text.aa383bd9469d529d": {
    "en": "Nelkano account disconnected.",
    "es": "Cuenta Nelkano desconectada."
  },
  "text.922ffb61201a39fc": {
    "en": "Could not load GBA save state; started from ROM.",
    "es": "No se pudo cargar save state GBA; arrancando desde ROM."
  },
  "text.aa8e2f3935fd38eb": {
    "en": "Loading Nintendo DS...",
    "es": "Cargando Nintendo DS..."
  },
  "text.2db98ea3c890b510": {
    "en": "Could not open ",
    "es": "No se pudo abrir "
  },
  "text.7caa1faa46b9dccf": {
    "en": "Could not load NDS save state; started from ROM.",
    "es": "No se pudo cargar save state NDS; arrancando desde ROM."
  },
  "text.6d00954c283d7ba4": {
    "en": "Could not publish the first NDS frame.",
    "es": "No se pudo publicar el primer frame NDS."
  },
  "text.d537aefccf812b18": {
    "en": "Loading Nintendo 3DS...",
    "es": "Cargando Nintendo 3DS..."
  },
  "text.a784d294b5c8bffc": {
    "en": "This game needs a decrypted copy",
    "es": "Este juego necesita una copia descifrada"
  },
  "text.ce5520f77c7d52a6": {
    "en": "Could not load 3DS save state; started from game.",
    "es": "No se pudo cargar el estado 3DS; se inicio desde el juego."
  },
  "text.b890863ffea7a0bf": {
    "en": "Could not open 3DS game: ",
    "es": "No se pudo abrir el juego 3DS: "
  },
  "text.5e0adb0ca3f2f15a": {
    "en": "Could not load PS1 save state; started from disc.",
    "es": "No se pudo cargar save state PS1; arrancando desde el disco."
  },
  "text.a803eccd72d2d004": {
    "en": "Could not load Master System save state; started from ROM.",
    "es": "No se pudo cargar save state Master System; arrancando desde ROM."
  },
  "text.b49a8706c9e48769": {
    "en": "Could not load Game Gear save state; started from ROM.",
    "es": "No se pudo cargar save state Game Gear; arrancando desde ROM."
  },
  "text.753d0d4ace1d96c1": {
    "en": "Could not load Neo Geo Pocket save state; started from ROM.",
    "es": "No se pudo cargar save state Neo Geo Pocket; arrancando desde ROM."
  },
  "text.62744968b9790fb6": {
    "en": "Emulation stopped: ",
    "es": "Emulacion detenida: "
  },
  "text.6be59710d29bc3d7": {
    "en": "no device",
    "es": "sin dispositivo"
  },
  "text.55c421665da2eb1d": {
    "en": " pressed",
    "es": " pulsado"
  },
  "text.af1c3e9a6f11a623": {
    "en": " released",
    "es": " soltado"
  },
  "text.7d3f0a32d9d7ea2c": {
    "en": "Button ",
    "es": "Botón "
  },
  "text.3cbe6ec965737c9c": {
    "en": "Could not load RPG Maker state: ",
    "es": "No se pudo cargar estado RPG Maker: "
  },
  "text.900113cb8ef1515e": {
    "en": "Extracting RPG Maker encrypted archive...",
    "es": "Extrayendo archivo cifrado RPG Maker..."
  },
  "text.8b8737cc6b16e659": {
    "en": "Extracting RPG Maker files: ",
    "es": "Extrayendo archivos RPG Maker: "
  },
  "text.a8027034fe402ec9": {
    "en": "Not enough space on the Android emulator to extract this RPG Maker game. The incomplete extraction was cleaned.",
    "es": "No queda espacio en el emulador Android para extraer este juego RPG Maker. Se limpio la extraccion incompleta."
  },
  "text.dc4734a45052daba": {
    "en": "Select this CUE and all of its track files.",
    "es": "Selecciona este CUE y todos sus archivos de pistas."
  },
  "text.370e4f60b0d5f035": {
    "en": "The file does not look like a valid Game Boy file.",
    "es": "El archivo no parece un archivo Game Boy valido."
  },
  "text.4b9f4ca286dfa63e": {
    "en": "Unsupported file.",
    "es": "Archivo no soportado."
  },
  "text.f173b0909c9fa277": {
    "en": "Could not open the file: ",
    "es": "No se pudo abrir el archivo: "
  },
  "text.81ba483b9da20b6d": {
    "en": "3DS image is larger than 8 GB.",
    "es": "La imagen 3DS supera los 8 GB."
  },
  "text.55a04632370e9bc8": {
    "en": "Copying 3DS game: ",
    "es": "Copiando juego 3DS: "
  },
  "text.d561d37afdc85731": {
    "en": "The file does not look like a supported 3DS image.",
    "es": "El archivo no parece una imagen 3DS compatible."
  },
  "text.daf57ad41da6b221": {
    "en": "The file does not look like a valid NDS ROM.",
    "es": "El archivo no parece una ROM NDS valida."
  },
  "text.f8a95876fb0cf7dd": {
    "en": "Choose one patch at a time, then select its game.",
    "es": "Elige un solo parche y después selecciona su juego."
  },
  "text.8c4971a983ab7658": {
    "en": "Could not read the selected file.",
    "es": "No se pudo leer el archivo seleccionado."
  },
  "text.bec984242bd7eed7": {
    "en": "Importing PS1 disc...",
    "es": "Importando disco PS1..."
  },
  "text.19d5f7ad5530ada7": {
    "en": "Could not import PS1 disc: ",
    "es": "No se pudo importar el disco PS1: "
  },
  "text.7557644414ce6e0e": {
    "en": "The PS1 module is not available for this device.",
    "es": "El modulo PS1 no esta disponible para este dispositivo."
  },
  "text.71b9859bcef0ccb2": {
    "en": "Importing archive...",
    "es": "Importando archivo..."
  },
  "text.849af671b23d4443": {
    "en": "Cleaning previous import...",
    "es": "Limpiando importacion anterior..."
  },
  "text.e2e052dd0784f3cb": {
    "en": "Could not open the archive: ",
    "es": "No se pudo abrir el archivo comprimido: "
  },
  "text.8689dbf692c2baa5": {
    "en": "Extracting: ",
    "es": "Extrayendo: "
  },
  "text.c9a2e3015d036bae": {
    "en": "Archive password",
    "es": "Contraseña del archivo"
  },
  "text.d3b798633a98742b": {
    "en": "Encrypted archive",
    "es": "Archivo cifrado"
  },
  "text.0b2959695b4bd256": {
    "en": "This RAR/7z is encrypted. Enter its password to import it.",
    "es": "Este RAR/7z está cifrado. Introduce su contraseña para importarlo."
  },
  "text.82c828d895489f85": {
    "en": "Import",
    "es": "Importar"
  },
  "text.73ef8e3999624a6a": {
    "en": "Password required",
    "es": "Contraseña necesaria"
  },
  "text.b5eb6e6c0dd0debb": {
    "en": "Checking archive...",
    "es": "Revisando archivo..."
  },
  "text.d0be3bdd09f48cf7": {
    "en": "only the macOS build (Project Zomboid.app/Contents/Java) runs on Android",
    "es": "solo funciona la versión de Mac (Project Zomboid.app/Contents/Java)"
  },
  "text.31b41f97dae42b3a": {
    "en": "Installing Project Zomboid mods...",
    "es": "Instalando mods de Project Zomboid..."
  },
  "text.52850a5eb191b022": {
    "en": "Importing: ",
    "es": "Importando: "
  },
  "text.5422f805c793c9f2": {
    "en": "Cleaning: ",
    "es": "Limpiando: "
  },
  "text.7e66386f06cee128": {
    "en": "This system is not available in this version.",
    "es": "Este sistema no está disponible en esta versión."
  },
  "text.730979611d9aae9f": {
    "en": "Preparing ",
    "es": "Preparando "
  },
  "text.b03d1e45d57a4395": {
    "en": "NDS ROM is larger than 512 MB.",
    "es": "La ROM NDS supera los 512 MB."
  },
  "text.f0673796f4f09c0e": {
    "en": "Audio is not available for ",
    "es": "Audio no disponible para "
  },
  "text.49d01d4f68b2fe2d": {
    "en": "ZIP import",
    "es": "Importacion ZIP"
  },
  "text.7400cc7d14007ab2": {
    "en": "Project Zomboid mods installed: ",
    "es": "Mods de Project Zomboid instalados: "
  },
  "text.28c94a002bb5996f": {
    "en": "Enable them in the game's MODS menu (or when creating a game).",
    "es": "Actívalos en el menú MODS del juego (o al crear la partida)."
  },
  "text.1f6d4b011f4902b8": {
    "en": "No compatible games were imported.",
    "es": "No se importo ningun juego compatible."
  },
  "text.c15bc943b1cede15": {
    "en": "Imported: ",
    "es": "Importados: "
  },
  "text.146c6c300eb5633b": {
    "en": "Already in library: ",
    "es": "Ya en biblioteca: "
  },
  "text.0470330fa0302c82": {
    "en": "Skipped: ",
    "es": "Omitidos: "
  },
  "text.497fc715c395b8ba": {
    "en": "Imported",
    "es": "Importados"
  },
  "text.f195e86d9eb6df97": {
    "en": "Already in library",
    "es": "Ya en biblioteca"
  },
  "text.88a8e8581bfac9eb": {
    "en": "Mods",
    "es": "Mods"
  },
  "text.19e70e0d9588f02f": {
    "en": "Skipped",
    "es": "Omitidos"
  },
  "text.a92a2dafe1ed8eb1": {
    "en": "nested ZIP unreadable or too deep",
    "es": "ZIP anidado no legible o demasiado profundo"
  },
  "text.35fe7bb8bc559606": {
    "en": "nested archive unreadable or too deep",
    "es": "archivo anidado no legible o demasiado profundo"
  },
  "text.669cac59924a8456": {
    "en": "duplicate ROM",
    "es": "ROM duplicada"
  },
  "text.9ad9098b6d23e6c7": {
    "en": "unsupported",
    "es": "no soportado"
  },
  "text.3b4f04d93c12f234": {
    "en": "File is too large for direct ROM import. Use ZIP for complete projects.",
    "es": "El archivo es demasiado grande para importarlo como ROM. Usa ZIP para proyectos completos."
  },
  "text.64c903dfbd7cbfff": {
    "en": "The Project Zomboid module is disabled (Settings > Modules).",
    "es": "El módulo Project Zomboid está desactivado (Ajustes > Módulos)."
  },
  "text.83ea8073ff4c345c": {
    "en": "Preparing RPG Maker...",
    "es": "Preparando RPG Maker..."
  },
  "text.438824167e8896b8": {
    "en": "Restoring RPG Maker state...",
    "es": "Restaurando estado RPG Maker..."
  },
  "text.27f0914dc0994e32": {
    "en": "Checking RPG Maker state...",
    "es": "Comprobando estado RPG Maker..."
  },
  "text.47efce96e4673d4f": {
    "en": "Loading game scripts...",
    "es": "Cargando scripts del juego..."
  },
  "text.4e80b4cb5a388e3c": {
    "en": "Loading game data...",
    "es": "Cargando datos de la partida..."
  },
  "text.251c2055cea90f0a": {
    "en": "Restoring game screen...",
    "es": "Restaurando pantalla del juego..."
  },
  "text.f04ff384a5696256": {
    "en": "Preparing the game...",
    "es": "Preparando el juego..."
  },
  "text.5153c79f775a91a6": {
    "en": "Could not open RGSS XP: ",
    "es": "No se pudo abrir RGSS XP: "
  },
  "text.2cebfb1b4863ef6b": {
    "en": "No application can open this link",
    "es": "No hay una aplicacion para abrir este enlace"
  },
  "text.da3cb7bed8677658": {
    "en": "Could not save state: ",
    "es": "No se pudo guardar estado: "
  },
  "text.a5f2f9da46e92116": {
    "en": "Mega Drive core is not running.",
    "es": "El core Mega Drive no esta iniciado."
  },
  "text.bbbd991273f4a318": {
    "en": "Cartridge save written.",
    "es": "Guardado de cartucho escrito."
  },
  "text.88c24b7d424d5f21": {
    "en": "Could not save cartridge data: ",
    "es": "No se pudo guardar el cartucho: "
  },
  "text.dec28c9bf5473767": {
    "en": "Empty slot",
    "es": "Slot vacío"
  },
  "text.3fdc5ff1d58a1837": {
    "en": "State saved.",
    "es": "Estado guardado."
  },
  "text.9fb15135f5ae8f7c": {
    "en": "RPG Maker runtime is not ready.",
    "es": "El runtime RPG Maker no esta listo."
  },
  "text.71eea6fa9e26a83a": {
    "en": "A state operation is already running.",
    "es": "Ya hay una operacion de estado en curso."
  },
  "text.6d9db11ed26cb591": {
    "en": "Restoring RPG Maker state",
    "es": "Restaurando estado RPG Maker"
  },
  "text.023e0d1b02bb13d6": {
    "en": "Checking state...",
    "es": "Comprobando estado..."
  },
  "text.3fdd3b0da163820f": {
    "en": "Cancelling...",
    "es": "Cancelando..."
  },
  "text.d09114dad8ef1598": {
    "en": "State loaded.",
    "es": "Estado cargado."
  },
  "text.26035605daee3db6": {
    "en": "State load cancelled.",
    "es": "Carga de estado cancelada."
  },
  "text.63dc8e3afe00637e": {
    "en": "Could not load state: ",
    "es": "No se pudo cargar estado: "
  }
};
