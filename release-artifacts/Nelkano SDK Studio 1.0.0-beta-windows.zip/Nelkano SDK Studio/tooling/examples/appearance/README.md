# Apariencia

SDK 0.2.0, módulo 0.1.0. Español/inglés y cinco paletas originales. Los formularios se dibujan con los componentes de la app; sin traducción se conserva el texto original. Permisos appearance.locale, presentation.appearance, storage.private.cas, modules.hooks.

Ganchos 1.0.0: settings (snapshot/set), theme-options (label/skinId), locale-options (label/language/strings). Usa IDs devueltos por host.appearance.snapshot(). Las contribuciones de diccionarios siguen los límites generales de hooks; para idiomas completos usa directamente el puerto appearance.

Los catálogos de temas e idiomas pertenecen a las fuentes de Apariencia; no dependen de los prototipos retirados. Libro local: /sdk-de-nelkano/idioma-temas.
