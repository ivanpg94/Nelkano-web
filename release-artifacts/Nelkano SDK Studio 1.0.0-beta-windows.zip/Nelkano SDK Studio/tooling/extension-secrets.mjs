const need=(v,m)=>{if(!v)throw Error(m)};
/** Studio stores test credentials only in memory; never creates a plaintext secret file. */
export class ExtensionSecrets {
 constructor(){this.values=new Map()}
 call(owner,method,args){if(method==='secrets.capabilities'){need(args.length===0,'invalid-secret-request');return {persistent:false,maxKeys:64,maxValueBytes:4096,maxTotalBytes:65536}}
  need(args.length===(method==='secrets.put'?2:1),'invalid-secret-request');const key=args[0];need(typeof key==='string'&&/^[a-z][a-z0-9.-]{0,127}$/.test(key),'invalid-extension-name');const data=new Map(this.values.get(owner)??[]);
  if(method==='secrets.get')return data.get(key)??null;
  if(method==='secrets.put'){const value=args[1];need(typeof value==='string'&&Buffer.byteLength(value)<=4096,'secret-value-size');need(data.has(key)||data.size<64,'secret-key-limit');data.set(key,value);need(Buffer.byteLength(JSON.stringify(Object.fromEntries(data)))<=65536,'secret-storage-limit');this.values.set(owner,data);return true}
  if(method==='secrets.remove'){const removed=data.delete(key);this.values.set(owner,data);return removed}throw Error('unknown-secret-operation')
 }
}
