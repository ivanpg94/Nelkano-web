import {spawn} from 'node:child_process';
export async function codexModels(command,launch=spawn){
 return new Promise(done=>{
  const child=launch(command.file,[...command.prefix,'app-server'],{stdio:['pipe','pipe','pipe'],windowsHide:true,shell:false});
  let buffer='',finished=false,bytes=0;const models=[];
  const finish=value=>{if(finished)return;finished=true;clearTimeout(timeout);child.stdin.end();done(value);const cleanup=setTimeout(()=>child.kill(),1500);cleanup.unref();child.once('close',()=>clearTimeout(cleanup));};
  const timeout=setTimeout(()=>finish([]),15000);child.once('error',()=>finish([]));child.once('close',()=>finish([]));
  child.stderr.resume();child.stdin.on('error',()=>{});
  const send=value=>child.stdin.write(JSON.stringify(value)+'\n');
  child.stdout.on('data',chunk=>{bytes+=chunk.length;if(bytes>1024*1024){finish([]);return;}buffer+=chunk;let index;while((index=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,index);buffer=buffer.slice(index+1);try{const e=JSON.parse(line);
   if(e.id===1){if(e.error){finish([]);return;}send({method:'initialized',params:{}});send({id:2,method:'model/list',params:{limit:100,includeHidden:false}});}
   if(e.id===2){if(e.error){finish([]);return;}for(const m of e.result?.data??[]){const id=m.model??m.id;if(typeof id!=='string'||!/^[a-zA-Z0-9._:-]{1,128}$/.test(id)||m.hidden)continue;const levels=(m.supportedReasoningEfforts??[]).map(x=>x.reasoningEffort).filter(x=>['none','minimal','low','medium','high','xhigh','max','ultra'].includes(x));models.push({id,label:String(m.displayName??id).slice(0,120),levels,defaultLevel:levels.includes(m.defaultReasoningEffort)?m.defaultReasoningEffort:levels[0]??'',isDefault:m.isDefault===true});}
    if(e.result?.nextCursor&&models.length<100){send({id:2,method:'model/list',params:{limit:100,includeHidden:false,cursor:e.result.nextCursor}});}else finish(models.slice(0,100));}
  }catch{}}});
  send({id:1,method:'initialize',params:{clientInfo:{name:'nelkano_sdk',title:'Nelkano SDK',version:'0.2.0'}}});
 });
}
export const claudeModels=()=>['sonnet','opus','haiku'].map(id=>({id,label:id[0].toUpperCase()+id.slice(1),levels:id==='haiku'?[]:['low','medium','high'],defaultLevel:id==='haiku'?'':'medium',isDefault:id==='sonnet'}));
