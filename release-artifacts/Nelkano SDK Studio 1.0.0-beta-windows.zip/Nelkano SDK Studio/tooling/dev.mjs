import {createServer} from 'node:http';
import {randomBytes,createHash} from 'node:crypto';
import {readFile,readdir,lstat} from 'node:fs/promises';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {safePath} from './zip.mjs';
import {spawn} from 'node:child_process';
import {DevEngine} from './dev-engine.mjs';
import {DevWorkspace} from './dev-workspace.mjs';
import {AgentChats} from './agent-chat.mjs';
import {MemoryInspector} from './memory-inspector.mjs';
import {activeStudioTooling} from './studio-updates.mjs';
export async function fingerprint(paths){const hash=createHash('sha256');for(const path of paths){let text;try{text=await readFile(join(path,'manifest.json'),'utf8');}catch{hash.update('missing-manifest:'+path);continue;}hash.update(text);let m;try{m=JSON.parse(text);}catch{continue;}for(const f of m.files??[]){try{safePath(f);let current=path;for(const part of f.split('/')){current=join(current,part);if((await lstat(current)).isSymbolicLink())throw Error('source-symlink');}hash.update(await readFile(current));}catch{hash.update('missing:'+f);}}}return hash.digest('hex');}
export async function serveDev(paths=[],{dataDir=join(resolve(paths[0]??process.cwd()),'.nelkdev'),watch=true,agentOptions={}}={}){
 const engine=new DevEngine(dataDir);await engine.init();const workspace=new DevWorkspace(engine);try{for(const path of paths)await workspace.open(path);}catch(e){engine.close();throw e;}
 const inspector=new MemoryInspector(engine);
 const token=randomBytes(24).toString('hex');let queue=Promise.resolve();const serial=fn=>{const task=queue.then(fn);queue=task.catch(()=>{});return task;};
 const chats=new AgentChats(workspace,{...agentOptions,onChange:()=>{engine.revision++;},onComplete:project=>serial(()=>workspace.sync(project))});await chats.init();
 const server=createServer(async(req,res)=>{
  try{
   if(req.headers.authorization!=='Bearer '+token){res.writeHead(403);res.end();return;}
   res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json');
   if(req.method==='GET'&&req.url==='/state'){res.end(JSON.stringify(await serial(()=>({...(engine.gameMod.tick(),engine.gameRuntime.tick(),engine.gameMod.dispatchEvents(),engine.dispatchExtensionEvents(),engine.state()),projects:workspace.state(),chat:chats.state()}))));return;}
   if(req.method!=='POST'||req.url!=='/rpc'){res.writeHead(404);res.end();return;}
   let bytes=0;const chunks=[];for await(const chunk of req){bytes+=chunk.length;if(bytes>512*1024)throw Error('request-too-large');chunks.push(chunk);}
   const {method,args={}}=JSON.parse(Buffer.concat(chunks).toString('utf8'));const value=await serial(async()=>{
    switch(method){
     case 'memory.status':case 'memory.call':case 'memory.code':case 'memory.release':return inspector.call(method,args);
     case 'chat.refresh':return chats.refresh();
     case 'chat.open':return chats.conversation(args.project,args.provider);
     case 'chat.send':return chats.send(args);
     case 'chat.cancel':return chats.cancel(args.project,args.provider);
     case 'chat.new':return chats.clear(args.project,args.provider);
     case 'context':engine.context(args.context,args.navigation===true);return true;
     case 'invoke':return engine.invoke(args.button);
     case 'panel':return engine.panelAction(args.action,args.payload??{});
     case 'dismiss-panel':engine.dismissPanel();return true;
     case 'dismiss-message':engine.message=null;engine.revision++;return true;
     case 'asset':return engine.asset(args.id,args.path);
     case 'connections.review':engine.connections.approve(args.allowed===true);return true;
     case 'ui.asset':{const owner=engine.pages.ownerFor(args.module,args.id,args.revision);if(!owner||!engine.packages.get(args.module)?.manifest.capabilities.includes('storage.files'))return null;return engine.files.image(owner,args.name)}
     case 'ui.describe':engine.pages.resolve(args.target,args.base);return true;
     case 'ui.close':engine.pages.close();engine.revision++;return true;
     case 'ui.invoke':if(!engine.pages.authorized(args.module,args.id,args.revision,args.action))throw Error('stale-ui-action');return engine.perform(args.module,args.action,args.payload,args.context);
     case 'services.select':engine.services.select(args.name,args.owner);engine.revision++;return true;
     case 'toggle':engine.toggle(args.id,args.enabled===true);return true;
     case 'add':return workspace.open(args.path);
     case 'editor.tree':return workspace.tree(args.project);
     case 'editor.read':return workspace.read(args.project,args.path);
     case 'editor.save':return workspace.save(args.project,args.path,args.content,args.revision);
     case 'editor.create-file':return workspace.createFile(args.project,args.path,args.content??'',args.declare!==false);
     case 'editor.create-folder':return workspace.createFolder(args.project,args.path);
     case 'editor.import-asset':return workspace.importAsset(args.project,args.source,args.path,args.declare!==false);
     case 'editor.create-project':return workspace.createProject(args);
     case 'reload':for(const p of workspace.projects.values())await workspace.sync(p.id);return true;
     case 'session.open':{const v=engine.player.open(args.gameId,args.slot);engine.refresh();return v;}
     case 'session.close':engine.player.close();engine.refresh();return true;
     case 'player.action':{const v=engine.player.call(args.operation,args.values);engine.refresh();return v;}
     case 'autosave.tick':return engine.simulateAutoSave(args.gameId,args.paused??false,args.canSave??true);
     case 'delete.confirm':engine.approveDeletion();return true;
     case 'delete.cancel':engine.cancelDeletion();return true;
     case 'reset-filters':engine.resetFilters();return true;
     case 'reset':engine.reset();return true;
     case 'skin':engine.selectSkin(args.id??null);return true;
     case 'export':return engine.export(args.id,args.keyPath??null);
     case 'event':engine.log('simulation','host',args.name??'Evento simulado');engine.refresh();return true;
     default:throw Error('unknown-dev-command');
    }
   });res.end(JSON.stringify({ok:true,value}));
  }catch(e){engine.log('error','dev',e.message);res.statusCode=400;res.end(JSON.stringify({ok:false,error:e.message}));}
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;
 let hash=await fingerprint([...workspace.projects.values()].map(p=>p.path)),timer,closed=false;let checking=false;
 if(watch)timer=setInterval(async()=>{if(checking)return;checking=true;try{const next=await fingerprint([...workspace.projects.values()].map(p=>p.path));if(next!==hash){hash=next;await serial(async()=>{for(const p of workspace.projects.values())await workspace.sync(p.id);});}}catch(e){engine.message=e.message;engine.log('build','dev',e.message);}finally{checking=false;}},800);
 return {engine,workspace,chats,server,url,token,close:async()=>{if(closed)return;closed=true;clearInterval(timer);await chats.close();await queue;engine.close();await new Promise(r=>server.close(r));}};
}
async function executable(directory){for(const e of await readdir(directory,{withFileTypes:true})){const file=join(directory,e.name);if(e.isFile()&&e.name==='Nelkano SDK Simulator.exe')return file;if(e.isDirectory()&&!['runtime','app'].includes(e.name)){const found=await executable(file);if(found)return found;}}return null;}
export async function startDev(args){
 const active=await activeStudioTooling(dirname(fileURLToPath(import.meta.url)));
 if(active){await new Promise((ok,no)=>{const child=spawn(process.execPath,[join(active,'cli.mjs'),'dev',...args],{stdio:'inherit',windowsHide:true});child.once('error',no);child.once('exit',code=>{process.exitCode=code??1;ok();});});return;}

 const headless=args.includes('--headless');const modules=args.filter(x=>x!=='--headless');
 const runtimeRoot=join(dirname(fileURLToPath(import.meta.url)),'simulator');let app;
 if(!headless){try{app=await executable(runtimeRoot);}catch{}if(!app)throw Error('Falta la distribuciÃ³n grÃ¡fica del SDK. Instala el paquete sdk-tools del simulador; para construir desde fuentes ejecuta :sdk:simulator:stageSdkRuntime.');}
 const session=await serveDev(modules);console.log('Nelkano SDK Â· mÃ³dulos desde fuentes Â· recarga automÃ¡tica Â· datos en '+session.engine.root);
 if(headless){console.log('Host headless listo. Ãšsalo mediante serveDev() en tus pruebas; no sustituye la vista grÃ¡fica.');const stop=async()=>{await session.close();process.exit(0);};process.once('SIGINT',stop);process.once('SIGTERM',stop);return;}
 const child=spawn(app,[session.url,session.token],{stdio:'inherit',windowsHide:false});
 const cleanup=async()=>{child.kill();await session.close();};process.once('SIGINT',cleanup);process.once('SIGTERM',cleanup);
 child.once('error',async e=>{console.error(e.message);await session.close();process.exitCode=1;});
 child.once('exit',async code=>{await session.close();process.exitCode=code??0;});
}


