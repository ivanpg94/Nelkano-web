/** Context keys contain selection, game and session. Stale entries stay visible until replaced. */
export class ContributionCache {
 constructor(limit=64){this.limit=limit;this.contexts=new Map();this.generations=new Map();}
 fresh(key,id){const e=this.contexts.get(key)?.get(id);return !!e&&e.generation===(this.generations.get(id)??0);}
 ready(key,active){return [...active].every(id=>this.fresh(key,id));}
 values(key,active){return [...(this.contexts.get(key)??[])].filter(([id])=>active.has(id)).flatMap(([,e])=>e.values);}
 put(key,id,values){const entries=this.contexts.get(key)??new Map();this.contexts.delete(key);entries.set(id,{generation:this.generations.get(id)??0,values});this.contexts.set(key,entries);while(this.contexts.size>this.limit)this.contexts.delete(this.contexts.keys().next().value);}
 invalidate(ids){for(const id of ids)this.generations.set(id,(this.generations.get(id)??0)+1);}
 remove(id){this.invalidate([id]);for(const c of this.contexts.values())c.delete(id);}
}
