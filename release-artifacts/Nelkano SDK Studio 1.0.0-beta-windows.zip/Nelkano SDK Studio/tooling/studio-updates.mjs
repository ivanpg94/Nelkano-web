import {readFile,realpath} from 'node:fs/promises';
import {resolve,join,sep} from 'node:path';
import {homedir} from 'node:os';
export async function activeStudioTooling(current,{platform=process.platform,root=join(process.env.LOCALAPPDATA??homedir(),'Nelkano','SDK','app-updates')}={}) {
 if(platform!=='win32')return null;
 try {
  const target=await realpath((await readFile(join(root,'active.txt'),'utf8')).trim());
  const versions=await realpath(join(root,'versions'));
  if(!target.toLowerCase().startsWith((versions+sep).toLowerCase()))return null;
  const tooling=await realpath(join(target,'tooling'));
  if(tooling.toLowerCase()===(await realpath(current)).toLowerCase())return null;
  const metadata=await readFile(join(target,'studio-version.properties'),'utf8');
  const previous=await readFile(join(current,'studio-version.properties'),'utf8').catch(()=>readFile(join(current,'..','studio-version.properties'),'utf8').catch(()=>null));
  const get=(text,key)=>new RegExp('^'+key+'=(.+)$','m').exec(text)?.[1]?.trim();
  const next=Number(get(metadata,'versionCode')),before=Number(get(previous??'','versionCode')??0);
  if(get(metadata,'studioAppId')!=='nelkano.sdk.studio'||!Number.isSafeInteger(next)||next<1||next<=before)return null;
  const pkg=JSON.parse(await readFile(join(tooling,'package.json'),'utf8'));
  if(pkg.name!=='@nelkano/sdk-tools'||pkg.version!==get(metadata,'sdkToolsVersion'))return null;
  await readFile(join(tooling,'cli.mjs'));return tooling;
 }catch{return null;}
}
