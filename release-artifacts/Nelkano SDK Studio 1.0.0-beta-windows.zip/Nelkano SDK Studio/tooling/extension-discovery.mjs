export function discoveryPage(values,options={}) {
 if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>!['offset','limit'].includes(k)))throw Error('invalid-discovery-page');
 const offset=options.offset??0,limit=options.limit??32;
 if(!Number.isInteger(offset)||offset<0||offset>10000||!Number.isInteger(limit)||limit<1||limit>128)throw Error('invalid-discovery-page');
 const page=[];let bytes=2;
 for(const item of values.slice(offset,offset+limit)){const size=Buffer.byteLength(JSON.stringify(item))+1;if(bytes+size>112*1024){if(!page.length)throw Error('discovery-item-size');break}page.push(item);bytes+=size}
 return JSON.parse(JSON.stringify(page));
}
