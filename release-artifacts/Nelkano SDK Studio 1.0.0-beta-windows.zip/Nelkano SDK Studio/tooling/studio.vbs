Option Explicit
Dim shell, files, folder, work, command, arg
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
folder = files.GetParentFolderName(WScript.ScriptFullName)
work = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Nelkano"
If Not files.FolderExists(work) Then files.CreateFolder work
work = work & "\SDK"
If Not files.FolderExists(work) Then files.CreateFolder work
shell.CurrentDirectory = work
command = "node " & Quote(folder & "\cli.mjs") & " dev"
For Each arg In WScript.Arguments
  command = command & " " & Quote(arg)
Next
On Error Resume Next
shell.Run command, 0, False
If Err.Number <> 0 Then MsgBox "No se pudo abrir SDK Studio. Comprueba que Node.js esta instalado y disponible en PATH.", 16, "Nelkano SDK Studio"
Function Quote(value)
  Quote = Chr(34) & Replace(value, Chr(34), Chr(34) & Chr(34)) & Chr(34)
End Function
