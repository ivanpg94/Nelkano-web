const sizes = {u8:1,i8:1,u16:2,i16:2,u32:4,i32:4,f32:4,f64:8};
const bounds = {u8:[0,255],i8:[-128,127],u16:[0,65535],i16:[-32768,32767],u32:[0,4294967295],i32:[-2147483648,2147483647]};
const need=(v,message)=>{if(!v)throw Error(message)};
export const numberSize=type=>{need(Object.hasOwn(sizes,type),'invalid-memory-type');return sizes[type]};
const suffix=endian=>{need(endian==='little'||endian==='big','invalid-memory-endian');return endian==='little'?'LE':'BE'};
export function encodeNumber(value,type,endian) {
 const bytes=Buffer.alloc(numberSize(type)),order=suffix(endian);
 need(typeof value==='number'&&Number.isFinite(value),'invalid-memory-value');
 if(bounds[type])need(Number.isInteger(value)&&value>=bounds[type][0]&&value<=bounds[type][1],'memory-value-out-of-range');
 if(type==='f32')need(Number.isFinite(Math.fround(value)),'invalid-memory-value');
 const methods={u8:'writeUInt8',i8:'writeInt8',u16:'writeUInt16'+order,i16:'writeInt16'+order,u32:'writeUInt32'+order,i32:'writeInt32'+order,f32:'writeFloat'+order,f64:'writeDouble'+order};
 bytes[methods[type]](value,0);return bytes;
}
export function decodeNumber(bytes,type,endian) {
 need(bytes.length===numberSize(type),'memory-value-size');const order=suffix(endian);
 const methods={u8:'readUInt8',i8:'readInt8',u16:'readUInt16'+order,i16:'readInt16'+order,u32:'readUInt32'+order,i32:'readInt32'+order,f32:'readFloat'+order,f64:'readDouble'+order};
 const value=bytes[methods[type]](0);return Number.isFinite(value)?value:null;
}
