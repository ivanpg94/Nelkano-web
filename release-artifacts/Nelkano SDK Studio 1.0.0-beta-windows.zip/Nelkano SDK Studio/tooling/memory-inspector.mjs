import {numberSize} from './game-mod-numbers.mjs';
const need=(v,message)=>{if(!v)throw Error(message)};
const OWNER='sdk-studio-inspector';
const allowed=new Set(['gameMod.capabilities','gameMod.read','gameMod.readValues','gameMod.writeValues','gameMod.searchStart','gameMod.searchRefine','gameMod.searchRead','gameMod.searchClose']);
/** Author tools are outside the module runtime; access still uses validated synthetic operations and write ownership. */
export class MemoryInspector {
 constructor(engine){this.engine=engine}
 call(method,args){
  if(method==='memory.release'){this.close();return true}
  if(method==='memory.status'){const current=this.engine.player.current;return {simulated:true,active:!!current,session:current?.session??null,gameId:current?.gameId??null,capabilities:current?this.engine.gameMod.access(OWNER,'gameMod.capabilities',[current.session]):null}}
  if(method==='memory.code')return memoryCode(args.spec,args.action,args.language);
  need(allowed.has(args.operation),'unknown-memory-inspector-operation');need(args.session,'session-unavailable');
  const callArgs=args.operation==='gameMod.capabilities'?[args.session]:[args.session,args.value];
  const result=this.engine.gameMod.access(OWNER,args.operation,callArgs);this.engine.revision++;return result;
 }
 close(){this.engine.gameMod.searches.release(OWNER)}
}
export function memoryCode(spec,action='read',language='js'){
 need(spec&&typeof spec==='object'&&['js','ts'].includes(language)&&['read','write','observe'].includes(action),'invalid-memory-code');
 need(typeof spec.space==='string'&&/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(spec.space)&&Number.isSafeInteger(spec.address)&&spec.address>=0&&spec.address+numberSize(spec.type)<=Number.MAX_SAFE_INTEGER,'invalid-memory-code');
 const endian=spec.endian??'little';need(['little','big'].includes(endian),'invalid-memory-endian');
 const range=`{space: ${JSON.stringify(spec.space)}, address: 0x${spec.address.toString(16).padStart(8,'0')}, type: ${JSON.stringify(spec.type)}, endian: ${JSON.stringify(endian)}}`;
 const declaration=language==='ts'?`import type {Host, SdkSessionReference} from '@nelkano/sdk';\n\n`:'';
 const params=language==='ts'?'host: Host, session: SdkSessionReference':'host, session';
 if(action==='observe')return declaration+`// Permisos: emulation.game-mod, emulation.memory.read, runtime.events\n// Comprueba memoryObserve y la dirección para tu juego.\nexport async function observeValue(${params}) {\n  return host.gameMod.observe(session, {id: "observed-value", everyFrames: 1,\n    ranges: [{space: ${JSON.stringify(spec.space)}, address: 0x${spec.address.toString(16).padStart(8,'0')}, length: ${numberSize(spec.type)}}]});\n}\n// Reacciona a game-memory-changed en onEvent; unobserve retira la observación.\n`;
 if(action==='read')return declaration+`// Permisos: emulation.game-mod, emulation.memory.read\n// Comprueba que esta dirección pertenece a los datos de tu juego.\nexport async function readValue(${params}) {\n  const result = await host.gameMod.readValues(session, {values: [${range}]});\n  return result.values[0];\n}\n`;
 const valueParam=language==='ts'?', value: number':', value';
 return declaration+`// Permisos: emulation.game-mod, emulation.memory.read, emulation.memory.write\n// La escritura puede fallar si el juego cambia entre lectura y escritura.\nexport async function writeValue(${params}${valueParam}) {\n  const descriptor = ${range}${language==='ts'?' as const':''};\n  const current = await host.gameMod.readValues(session, {values: [descriptor]});\n  const expected = current.values[0].value;\n  if (expected === null) throw new Error("Utiliza bytes para este valor no finito.");\n  return host.gameMod.writeValues(session, {writes: [{...descriptor, expected, value}]});\n}\n`;
}
