import {spawn} from 'node:child_process';
import {codexModels,claudeModels} from './agent-catalog.mjs';
import {access,readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {join,dirname,resolve,delimiter} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
const providers=['codex','claude'];
const need=(x,m)=>{if(!x)throw Error(m);};
const text=x=>String(x??'').replace(/\x1b\[[0-9;]*m/g,'').slice(0,12000);
const validSession=x=>typeof x==='string'&&/^[a-zA-Z0-9_-]{8,128}$/.test(x);
async function agentAuthentication(id,command){
 return new Promise(resolveStatus=>{
  const child=spawn(command.file,[...command.prefix,...(id==='codex'?['login','status']:['auth','status'])],{shell:false,windowsHide:true,stdio:['ignore','pipe','pipe']});
  let result='';const read=chunk=>{result=(result+chunk).slice(-8000);};child.stdout.on('data',read);child.stderr.on('data',read);
  const timeout=setTimeout(()=>{child.kill();resolveStatus(null);},5000);
  child.once('error',()=>{clearTimeout(timeout);resolveStatus(null);});
  child.once('close',()=>{clearTimeout(timeout);try{resolveStatus(id==='claude'?JSON.parse(result).loggedIn===true:/logged in/i.test(result)&&!/not logged in/i.test(result));}catch{resolveStatus(null);}});
 });
}
export async function detectAgents(env=process.env){
 const dirs=[...(env.PATH??env.Path??'').split(delimiter),env.APPDATA?join(env.APPDATA,'npm'):null,(env.USERPROFILE??env.HOME)?join(env.USERPROFILE??env.HOME,'.local/bin'):null].filter(Boolean);
 const out=[];
 for(const id of providers){
  let command=null;
  for(const dir of dirs){
   for(const ext of process.platform==='win32'?['.exe','.cmd']:['']){
    const file=resolve(dir,id+ext);try{await access(file);}catch{continue;}
    if(ext==='.cmd'){
     const cli=join(dir,'node_modules',id==='codex'?'@openai/codex/bin/codex.js':'@anthropic-ai/claude-code/cli.js');
     try{await access(cli);command={file:process.execPath,prefix:[cli]};}catch{continue;}
    }else command={file,prefix:[]};
    break;
   }
   if(command)break;
  }
  out.push({id,name:id==='codex'?'Codex':'Claude Code',installed:!!command,authenticated:command?await agentAuthentication(id,command):null,models:command?(id==='codex'?await codexModels(command):claudeModels()):[],command});
 }
 return out;
}
export function agentArgs(provider,mode,session,model="",effort=""){
 need(providers.includes(provider),'unknown-agent');need(['consult','edit'].includes(mode),'unknown-agent-mode');
 need(typeof model==='string'&&(!model||/^[a-zA-Z0-9._:-]{1,128}$/.test(model)),'invalid-agent-model');
 need(typeof effort==='string'&&(!effort||['none','minimal','low','medium','high','xhigh','max','ultra'].includes(effort)),'invalid-agent-level');
 if(provider==='codex'){
  const args=['exec','--json','--skip-git-repo-check','-c','sandbox_mode="'+(mode==='edit'?'workspace-write':'read-only')+'"','-c','approval_policy="never"'];
  if(session){need(validSession(session),'invalid-agent-session');args.push('resume',session);}
  if(model)args.push('-m',model);
  if(effort)args.push('-c','model_reasoning_effort="'+effort+'"');
  return [...args,'-'];
 }
 const tools=mode==='edit'?'Read,Glob,Grep,Edit,Write':'Read,Glob,Grep';
 const args=['-p','--verbose','--output-format','stream-json','--tools',tools,'--allowedTools',mode==='edit'?'Read(./**),Glob,Grep,Edit(./**),Write(./**)':'Read(./**),Glob,Grep'];
 if(session){need(validSession(session),'invalid-agent-session');args.push('--resume',session);}
 if(model)args.push('--model',model);
 if(effort)args.push('--effort',effort);
 return args;
}
/** Trusted IDE service, never exposed to the module's QuickJS broker. */
export class AgentChats {
 constructor(workspace,{discover=detectAgents,launch=spawn,onChange=()=>{},onComplete=async()=>{},stop=null}={}){
  this.workspace=workspace;this.discover=discover;this.launch=launch;this.onChange=onChange;this.onComplete=onComplete;
  this.stop=stop;this.providers=[];this.conversations=new Map();this.active=null;this.closed=false;
 }
 async init(){await this.refresh();}
 async refresh(){if(this.active)return this.state().providers;this.providers=await this.discover();this.onChange();return this.state().providers;}
 key(project,provider){need(providers.includes(provider),'unknown-agent');this.workspace.project(project);return project+'-'+provider;}
 async conversation(project,provider){
  const key=this.key(project,provider);if(this.conversations.has(key))return this.conversations.get(key);
  const value={project,provider,session:null,messages:[],running:false,mode:'edit',model:'',effort:''};
  try{const file=join(this.workspace.engine.root,'chats',key+'.json');const raw=await readFile(file,'utf8');need(Buffer.byteLength(raw)<=512*1024,'chat-too-large');const saved=JSON.parse(raw);
   value.session=validSession(saved.session)?saved.session:null;value.model=typeof saved.model==='string'?saved.model:'';value.effort=typeof saved.effort==='string'?saved.effort:'';
   if(Array.isArray(saved.messages))value.messages=saved.messages.slice(-64).filter(m=>['user','assistant','event','error'].includes(m.role)&&typeof m.text==='string').map(m=>({role:m.role,text:text(m.text)}));
  }catch{}
  this.conversations.set(key,value);this.onChange();return value;
 }
 state(){return {providers:this.providers.map(({id,name,installed,authenticated,models})=>({id,name,installed,authenticated:authenticated??null,models:models??[]})),conversations:[...this.conversations.values()].map(({project,provider,messages,running,mode,model,effort})=>({project,provider,messages,running,mode,model,effort}))};}
 add(c,role,value){if(!value)return;if(role==='error'){c.failed=true;try{const parsed=JSON.parse(value);value=parsed.error?.message??parsed.message??value;}catch{} if(c.messages.at(-1)?.role==='error'&&c.messages.at(-1)?.text===text(value))return;}c.messages.push({role,text:text(value)});while(c.messages.length>64||Buffer.byteLength(JSON.stringify(c.messages))>256*1024)c.messages.shift();this.onChange();}
 async persist(c){const dir=join(this.workspace.engine.root,'chats');await mkdir(dir,{recursive:true});const file=join(dir,this.key(c.project,c.provider)+'.json');const temp=file+'.tmp';await writeFile(temp,JSON.stringify({session:c.session,messages:c.messages,model:c.model,effort:c.effort}));await rename(temp,file);}
 async clear(project,provider){need(!this.active,'agent-already-running');const c=await this.conversation(project,provider);c.session=null;c.messages=[];await this.persist(c);this.onChange();return true;}
 event(c,e){
  if(c.provider==='codex'){
   if(e.type==='thread.started'&&validSession(e.thread_id))c.session=e.thread_id;
   if(e.type==='item.completed'&&e.item?.type==='agent_message'){this.add(c,'assistant',e.item.text);c.replied=true;}
   if(e.type==='item.started'&&e.item?.type==='command_execution')this.add(c,'event','Ejecutando: '+text(e.item.command).slice(0,500));
   if(e.type==='item.completed'&&e.item?.type==='file_change')this.add(c,'event','Archivos modificados: '+(e.item.changes??[]).map(x=>x.path).join(', '));
   if(e.type==='error'||e.type==='turn.failed')this.add(c,'error',e.message??e.error?.message??'El agente no pudo completar el turno.');
  }else{
   if(validSession(e.session_id))c.session=e.session_id;
   if(e.type==='assistant')for(const part of e.message?.content??[]){if(part.type==='text'){this.add(c,'assistant',part.text);c.replied=true;}else if(part.type==='tool_use')this.add(c,'event','Herramienta: '+part.name);}
   if(e.type==='result'){
    if(e.is_error)this.add(c,'error',e.result??(e.errors??[]).join('\n'));
    else if(!c.replied&&e.result){this.add(c,'assistant',e.result);c.replied=true;}
    if(e.permission_denials?.length)this.add(c,'error','Permisos rechazados por Claude: '+e.permission_denials.map(x=>x.tool_name).join(', '));
   }
  }
 }
 async send({project,provider,mode='consult',prompt,file=null,model='',effort=''}){
  need(!this.closed,'chat-closed');need(!this.active,'agent-already-running');need(typeof prompt==='string'&&prompt.trim()&&Buffer.byteLength(prompt)<=16000,'invalid-chat-message');
  const cwd=this.workspace.project(project).path;agentArgs(provider,mode,null,model,effort);
  if(file)await this.workspace.path(project,file);
  const c=await this.conversation(project,provider);const tool=this.providers.find(p=>p.id===provider&&p.installed);need(tool,'agent-not-installed');need(tool.authenticated!==false,'Inicia sesión en una terminal con '+(provider==='codex'?'codex login':'claude')+'; Studio la detectará automáticamente.');
  if(tool.models?.length){const choice=tool.models.find(m=>m.id===model);need(choice,'Selecciona un modelo disponible en el desplegable.');need(!effort||choice.levels.includes(effort),'El nivel no está disponible para este modelo.');}
  const guide=c.session?'':(await readFile(join(here,'README.md'),'utf8')).slice(0,18000);
  const context=`Trabajas en Nelkano SDK Studio, sobre el módulo ${cwd}. ${file?'Archivo abierto: '+file+'. ':''}Modo ${mode==='edit'?'editar el módulo':'consultar, no modificar archivos'}. Respeta los cambios existentes. No cambies versiones, no hagas commits/push, no modifiques proyectos externos. No leas claves ni .nelkdev. No instales dependencias ni uses subagentes. ${guide?'Referencia del SDK:\n'+guide+'\n':''}Petición del usuario:\n${prompt}`;
  this.add(c,'user',prompt);c.mode=mode;c.model=model;c.effort=effort;c.running=true;c.replied=false;c.failed=false;this.onChange();
  let child;try{child=this.launch(tool.command.file,[...tool.command.prefix,...agentArgs(provider,mode,c.session,model,effort)],{cwd,stdio:['pipe','pipe','pipe'],shell:false,windowsHide:true,detached:process.platform!=='win32'});}catch(e){c.running=false;this.add(c,'error',e.message);await this.persist(c);throw e;}
  const run={c,child,cancelled:false,done:null};this.active=run;
  let buffer='',err='';let outputBytes=0;
  child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');
  child.stdout.on('data',chunk=>{
   outputBytes+=Buffer.byteLength(chunk);if(outputBytes>8*1024*1024){this.add(c,'error','La salida del agente excede el límite.');void this.cancel(project,provider);return;}
   buffer+=chunk;let index;while((index=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,index);buffer=buffer.slice(index+1);try{this.event(c,JSON.parse(line));}catch{}}
   if(buffer.length>256*1024){buffer='';this.add(c,'error','Evento demasiado grande; se omitió.');}
  });
  child.stderr.on('data',chunk=>{err=(err+chunk).slice(-4000);});
  child.stdin.on('error',()=>{});
  run.done=new Promise(resolveDone=>{
   let ended=false;const finish=async(code,error)=>{if(ended)return;ended=true;
    if(buffer.trim())try{this.event(c,JSON.parse(buffer));}catch{}
    if(run.cancelled)this.add(c,'event','Ejecución detenida. Los cambios ya escritos se conservan.');
    else if((error||code!==0)&&!c.failed)this.add(c,'error',error?.message??(err||'El agente terminó con error.'));
    else if(!c.replied&&!c.failed)this.add(c,'event','Turno terminado sin respuesta textual.');
    try{await this.persist(c);}catch(e){this.add(c,'error',e.message);}
    try{await this.onComplete(project);}catch(e){this.add(c,'error',e.message);}
    c.running=false;if(this.active===run)this.active=null;this.onChange();resolveDone();
   };
   child.once('error',e=>void finish(null,e));child.once('close',code=>void finish(code));
  });
  child.stdin.end(context);return {started:true};
 }
 async cancel(project,provider){const run=this.active;if(!run)return false;need(run.c.project===project&&run.c.provider===provider,'different-agent-running');run.cancelled=true;
  if(this.stop){await this.stop(run.child);return true;}
  if(process.platform==='win32')await new Promise(r=>{const killer=spawn('taskkill.exe',['/PID',String(run.child.pid),'/T','/F'],{windowsHide:true,stdio:'ignore',shell:false});killer.once('error',r);killer.once('close',r);});
  else {try{process.kill(-run.child.pid,'SIGTERM');}catch{run.child.kill('SIGTERM');}}
  return true;
 }
 async close(){this.closed=true;const run=this.active;if(run){await this.cancel(run.c.project,run.c.provider);await run.done;}}
}
