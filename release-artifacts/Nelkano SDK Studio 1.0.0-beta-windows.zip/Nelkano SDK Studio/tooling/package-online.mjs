import {readFile,writeFile,mkdir,access} from 'node:fs/promises';
import {generateKeyPairSync} from 'node:crypto';
import {join,resolve} from 'node:path';
import {buildPackage,validatePackage} from './package.mjs';
const root=resolve(import.meta.dirname,'../../../..'),signing=join(process.env.LOCALAPPDATA??process.env.HOME,'Nelkano','SDK','signing');await mkdir(signing,{recursive:true});
for(const name of ['gba-online','pokemon-online']){const key=join(signing,name+'.pem');try{await access(key)}catch{await writeFile(key,generateKeyPairSync('ed25519').privateKey.export({type:'pkcs8',format:'pem'}),{flag:'wx',mode:0o600})};const bytes=await buildPackage(join(root,'modules',name),await readFile(key)),meta=validatePackage(bytes);await mkdir(join(root,'outputs/modules'),{recursive:true});await writeFile(join(root,'outputs/modules',meta.id+'-'+meta.version+'.nelkmod'),bytes);console.log(meta.id+' '+meta.version+' firmado; no incluido en APK')}
