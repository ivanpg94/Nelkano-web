#!/usr/bin/env node
import {readFile,writeFile,mkdir,cp,readdir,lstat} from 'node:fs/promises';
import {resolve,dirname,join,posix} from 'node:path';import {fileURLToPath} from 'node:url';
import {compile} from './compiler.mjs';import {buildPackage,validatePackage,validateManifest,generateKeys} from './package.mjs';
import {safePath} from './zip.mjs';
const root=dirname(fileURLToPath(import.meta.url));const [command,...args]=process.argv.slice(2);

try{
 if(command==='dev'){const {startDev}=await import('./dev.mjs');await startDev(args);}
 else if(command==='example'&&['hooks','skin','control-editor','friends-hooks','basics','appearance','patches','gba-online','pokemon-online'].includes(args[0])&&args.length===2){await mkdir(args[1],{recursive:false});await cp(join(root,'examples',args[0]),args[1],{recursive:true});console.log('Standalone '+args[0]+' example created');}
 else if(command==='example'&&args[0]==='collections'&&args.length===2){await mkdir(args[1],{recursive:false});await cp(join(root,'examples','collections'),args[1],{recursive:true});const manifestPath=join(args[1],'manifest.json');const manifest=JSON.parse(await readFile(manifestPath,'utf8'));manifest.id='example.collections';manifest.name='Example Collections';manifest.bundledByDefault=false;await writeFile(manifestPath,JSON.stringify(manifest,null,2));for(const file of manifest.files.filter(f=>f.endsWith('.js'))){const p=join(args[1],file);await writeFile(p,(await readFile(p,'utf8')).replaceAll('nelkano.collections','example.collections'));}console.log('Standalone Collections source created with independent example.collections identity');}
 else if(command==='init'&&args.length===1){await mkdir(args[0],{recursive:false});await mkdir(join(args[0],'src'));await writeFile(join(args[0],'src','index.ts'),"import type { Host, Extension } from '@nelkano/sdk';\nexport function createModule(host: Host): Extension { return { async activate(){},async deactivate(){},async contributions(context){return [{moduleId:'example.counter',id:'open',slot:'SETTINGS_SECTION',label:'Example',actionId:'open'}]},async dispatch(){return {kind:'panel',title:'Example',fields:[],rows:[],actions:[]}} }; }\n");await writeFile(join(args[0],'manifest.json'),JSON.stringify({formatVersion:1,id:'example.counter',name:'Example',version:'0.1.0',sdkVersion:'0.2.0',platforms:['android'],entry:'src/index.ts',bundledByDefault:false,dependencies:[],capabilities:[],files:['src/index.ts']},null,2));}
 else if(command==='check'||command==='build'){console.log(await compile(args[0],command==='build'));}
 else if(command==='keygen'&&args.length===2){await generateKeys(...args);}
 else if(command==='pack'&&args.length===3){const built=await compile(args[0]);const bytes=await buildPackage(built,await readFile(args[1]));console.log(JSON.stringify(validatePackage(bytes)));await writeFile(args[2],bytes,{flag:'wx'});}
 else if(command==='verify'&&args.length>=1){console.log(JSON.stringify(validatePackage(await readFile(args[0]),args[1]),null,2));}
 else throw new Error('Usage: nelkmod dev [dir] [other-dir...] [--headless] | init dir | example collections/hooks/skin/control-editor/friends-hooks/basics/appearance/patches/gba-online/pokemon-online dir | check/build dir | keygen private public | pack dir private output | verify package [author]');
 if(['init','example'].includes(command)){await writeFile(join(command==='init'?args[0]:args[1],'.gitignore'),'node_modules/\ndist/\n.nelkdev/\n*.pem\n*.nelkmod\n');}
}catch(e){console.error(e.message);process.exitCode=1}

