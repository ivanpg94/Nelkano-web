import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
const root=resolve(import.meta.dirname,'../../../..');
for(const name of ['gba-online','pokemon-online']){
 const source=join(root,'modules',name),target=join(import.meta.dirname,'examples',name);
 const manifest=JSON.parse(await readFile(join(source,'manifest.json'),'utf8'));
 for(const file of ['manifest.json','package.json','README.md',...manifest.files]){
  const destination=join(target,file);await mkdir(dirname(destination),{recursive:true});
  await writeFile(destination,await readFile(join(source,file)));
 }
 console.log('Standalone example prepared: '+name);
}
