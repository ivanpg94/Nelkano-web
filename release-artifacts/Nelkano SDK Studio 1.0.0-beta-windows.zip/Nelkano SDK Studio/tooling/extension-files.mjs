import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {discoveryPage} from './extension-discovery.mjs';
const need=(v,m)=>{if(!v)throw Error(m)},copy=v=>JSON.parse(JSON.stringify(v));
const keys=(v,r,o=[])=>need(v&&typeof v==='object'&&!Array.isArray(v)&&r.every(k=>Object.hasOwn(v,k))&&Object.keys(v).every(k=>r.includes(k)||o.includes(k)),'invalid-extension-object');
const name=v=>need(typeof v==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(v),'invalid-file-name');
const revision=v=>need(Number.isSafeInteger(v)&&v>=0,'invalid-file-revision');
const mime=v=>need(typeof v==='string'&&v.length<=128&&/^[a-zA-Z0-9!#$&^_.+-]+\/[a-zA-Z0-9!#$&^_.+-]+$/.test(v),'invalid-file-mime');
const own=(o,k)=>Object.hasOwn(o,k)?o[k]:undefined;
export class ExtensionFiles {
 constructor(engine){this.engine=engine;this.leases=new Map();this.stages=new Map()}
 start(owner){this.release(owner);this.leases.set(owner,{})}
 release(owner){this.leases.delete(owner);for(const[id,s]of this.stages)if(s.owner===owner)this.stages.delete(id)}
 transaction(owner,action){const file=join(this.engine.root,'data','files-'+createHash('sha256').update(owner).digest('hex')+'.json');const before=existsSync(file)?readFileSync(file,'utf8'):'{"revision":0,"files":{}}';const state=JSON.parse(before),result=action(state),next=JSON.stringify(state);if(next!==before)this.engine.atomic(file,next);return copy(result)}
 summary(row){const {name,revision,size,mimeType}=row;return {name,revision,size,mimeType}}
 decode(v,max){need(typeof v==='string'&&v.length<=Math.ceil(max/3)*4,'file-chunk-size');const bytes=Buffer.from(v,'base64');need(bytes.length<=max&&bytes.toString('base64')===v,'invalid-file-bytes');return bytes}
 stage(owner,id){const s=this.stages.get(id);need(s&&s.owner===owner&&s.lease===this.leases.get(owner),'file-writer-unavailable');return s}
 image(owner,name){if(!this.leases.has(owner))return null;return this.transaction(owner,s=>{const row=own(s.files,name);if(!row||row.mimeType!=='image/png')return null;const b=this.decode(row.bodyBase64,1048576);if(b.length<33||!b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))||b.toString('ascii',12,16)!=='IHDR'||b.readUInt32BE(16)<1||b.readUInt32BE(16)>1024||b.readUInt32BE(20)<1||b.readUInt32BE(20)>1024)return null;return b.toString('base64')})}
 call(owner,method,args){need(this.leases.has(owner),'module-revoked');
  if(method==='files.capabilities'){need(args.length===0,'invalid-file-request');return {importExport:false,maxFiles:16,maxFileBytes:1048576,maxTotalBytes:4194304,maxChunkBytes:65536}}
  if(['files.import','files.export'].includes(method))throw Error('document-picker-unavailable');
  if(method==='files.list'){need(args.length<=1,'invalid-file-request');return this.transaction(owner,s=>discoveryPage(Object.keys(s.files).sort().map(k=>this.summary(s.files[k])),args[0]))}
  if(method==='files.read'){need(args.length===2,'invalid-file-request');name(args[0]);const spec=args[1];keys(spec,['offset','length']);revision(spec.offset);revision(spec.length);need(spec.length<=65536,'file-range-invalid');return this.transaction(owner,s=>{const row=own(s.files,args[0]);need(row,'file-unavailable');const bytes=this.decode(row.bodyBase64,1048576);need(spec.offset<=bytes.length&&spec.length<=bytes.length-spec.offset,'file-range-invalid');return {...this.summary(row),dataBase64:bytes.subarray(spec.offset,spec.offset+spec.length).toString('base64')}})}
  if(method==='files.begin'){need(args.length===1,'invalid-file-request');const spec=args[0];keys(spec,['name','expectedRevision'],['mimeType']);name(spec.name);revision(spec.expectedRevision);mime(spec.mimeType??'application/octet-stream');need([...this.stages.values()].filter(s=>s.owner===owner).length<2&&this.stages.size<32,'file-writer-limit');this.transaction(owner,s=>{need((own(s.files,spec.name)?.revision??0)===spec.expectedRevision,'file-changed');return null});const id=randomUUID();this.stages.set(id,{owner,lease:this.leases.get(owner),spec:copy(spec),chunks:[],size:0});return {id}}
  if(method==='files.write'){need(args.length===2,'invalid-file-request');const s=this.stage(owner,args[0]),spec=args[1];keys(spec,['offset','dataBase64']);revision(spec.offset);need(spec.offset===s.size,'file-write-offset');const bytes=this.decode(spec.dataBase64,65536);need(s.size+bytes.length<=1048576&&[...this.stages.values()].reduce((n,v)=>n+v.size,0)+bytes.length<=8388608,'file-staging-limit');s.chunks.push(bytes);s.size+=bytes.length;return {size:s.size}}
  if(method==='files.commit'){need(args.length===1,'invalid-file-request');const stage=this.stage(owner,args[0]),spec=stage.spec,bytes=Buffer.concat(stage.chunks);const result=this.transaction(owner,s=>{const old=own(s.files,spec.name);if((old?.revision??0)!==spec.expectedRevision)return {applied:false,revision:old?.revision??0};need(old||Object.keys(s.files).length<16,'file-count-limit');need(Object.values(s.files).reduce((n,r)=>n+r.size,0)-(old?.size??0)+bytes.length<=4194304,'file-storage-limit');revision(s.revision+1);const row={name:spec.name,revision:++s.revision,size:bytes.length,mimeType:spec.mimeType??'application/octet-stream',bodyBase64:bytes.toString('base64')};Object.defineProperty(s.files,spec.name,{value:row,writable:true,enumerable:true,configurable:true});return {applied:true,file:this.summary(row)}});if(result.applied)this.stages.delete(args[0]);return result}
  if(method==='files.abort'){need(args.length===1,'invalid-file-request');const s=this.stages.get(args[0]);if(s?.owner===owner&&s.lease===this.leases.get(owner)){this.stages.delete(args[0]);return true}return false}
  if(method==='files.remove'){need(args.length===2,'invalid-file-request');name(args[0]);revision(args[1]);return this.transaction(owner,s=>{const row=own(s.files,args[0]);if(!row||row.revision!==args[1])return false;delete s.files[args[0]];revision(s.revision+1);s.revision++;return true})}throw Error('unknown-file-operation')
 }
}
