# SDK Nelkano 0.2.0

## Actualizar SDK Studio

En Windows x64, **Ajustes → Actualización de SDK Studio** comprueba el canal oficial de nelkano.com. Studio también comprueba al abrir, al recuperar el foco y cada seis horas. Puedes descargar con progreso, cancelar y posponer; instalar exige guardar los archivos y terminar las operaciones y agentes activos.

La actualización incluye el programa y las herramientas del SDK. Se verifica el tamaño, SHA-256 y la identidad del ZIP y del ejecutable antes de activar una carpeta nueva bajo `%LOCALAPPDATA%/Nelkano/SDK/app-updates/versions`. Studio y su host se cierran antes de reabrir los proyectos; no se reemplazan sus fuentes ni `.nelkdev`. Los lanzadores existentes seleccionan la versión activada. Node.js continúa siendo un requisito.

Preparación desde fuentes: `gradlew :sdk:simulator:packageStudioUpdate`. El ZIP se genera en `sdk/simulator/build/studio-updates`; se registra en `/admin/nelkano/app-updates`, canal `sdk-studio-windows-x86_64`. La versión de Studio se declara en `sdk/studio-version.properties` y sigue siendo **0.2.0**; los paquetes del SDK conservan **0.2.0**. Cambiar versiones y códigos únicamente por petición expresa de Ivan. La primera distribución que incorpora el actualizador se instala por el procedimiento habitual; la web necesita el canal desplegado y una publicación posterior. No hay publicación automática.

## APIs de la plataforma abierta

La base incorpora APIs programables para ampliar funciones, interfaz, datos y juegos. Los módulos anteriores mantienen sus contratos. Android, Windows y SDK Studio compilan con las mismas APIs; la memoria, ROM temporal y reglas reales se verifican en GBA. Las diferencias de capacidades se indican a continuación.

- **Intervenir en servicios:** `services.intercept({id,name,method,phase,order?})` registra una transformación antes o después; `onService` recibe `phase` y `hookId`. La respuesta debe respetar el esquema del método. `removeInterceptor(id)` retira la transformación. Hasta 32 por módulo y 128 totales. Un error después de la operación no deshace sus efectos.
- **Entidades locales:** permiso `storage.entities`. `entities.define({name,version,schema,indexes?,relations?})`, `get`, `query`, `transact` y `migrate`. Esquemas de objeto, relaciones entre tipos del mismo módulo, índices de igualdad, revisiones y lotes atómicos con `expectedRevision`. Consultas con filtros AND, orden, offset y limit; páginas acotadas a 96 KiB. Hasta 64 tipos, 10.000 registros por tipo, 32 KiB por registro, 16 MiB por identidad y 128 cambios por lote. Datos locales privados por módulo y autor; nunca se suben automáticamente. Android y escritorio usan SQLite con registros separados; Studio usa JSON local. Actualizaciones fallidas restauran el estado anterior. `storage.private.cas` conserva su formato anterior.
- **Páginas y componentes:** permiso `presentation.extend`. `ui.page`, `mount`, `patch`, `remove`, `open`, `close` y `targets`. Páginas con secciones, filas, texto, botones, campos, selectores, pestañas, modales, imágenes PNG y lienzo con figuras. `dispatch` recibe las acciones y valores del formulario. Montajes en `home/library/game/saves/settings/emulation.before`, `.after` y `.content`, además de puntos de cada componente publicado. Una modificación puede cambiar texto, visibilidad, disponibilidad o `actionId`; los conflictos entre módulos se rechazan. Hasta 32 registros por módulo, 256 totales, 512 nodos y profundidad 16. Se retiran al desactivar. Es un renderer de componentes compartido, no HTML arbitrario ni un editor visual.
- **Servidores propios:** permiso `network.external` y lista firmada `origins` del manifiesto, con orígenes HTTP/HTTPS exactos. `connections.request`, `socket`, `read`, `send` y `close` trabajan con identificadores privados. `requestOrigin` solicita confirmación nativa para un servidor nuevo; la elección persiste por autor. No heredan cookies ni credenciales Nelkano y no siguen redirecciones. Android ofrece HTTPS/WSS; Windows y Studio admiten también HTTP/WS. Hasta 12 trabajos (8 HTTP y 4 sockets), 64 KiB por cuerpo/mensaje y 32 mensajes recibidos pendientes por socket. `onEvent` recibe `connection-changed` y `connection-origin-reviewed`. Desactivar cancela las conexiones. Studio ejecuta estas conexiones de verdad: usa servidores y credenciales de prueba.
- **Tareas:** permiso `runtime.tasks`. `tasks.schedule({id,delayMs,intervalMs?,payload?})`, `read`, `update` y `cancel`. `onEvent` recibe `task-due` con id, revisión, número de ocurrencias y payload. Puede actualizar progreso, resultado y estado. Hasta 32 tareas por módulo, intervalos de 100 ms a 24 h y datos de 32 KiB. Los avisos se agrupan; no garantiza ejecución puntual. Funcionan mientras vive la aplicación y se cancelan al desactivar; no ejecutan trabajos con la app cerrada.
- **Entradas en el juego:** permisos `emulation.game-mod` y `emulation.input`. `gameMod.input(session,{buttons:[{code,pressed}]})` mantiene pulsaciones propias, combinadas con el usuario y otros módulos. Desactivar libera solo las propias. Consulta `gameMod.capabilities`; cada core interpreta únicamente sus botones compatibles. Studio simula el contrato.

- **Archivos privados:** `storage.files` habilita `files.list/read/begin/write/commit/abort/remove`. begin exige el nombre y expectedRevision; write añade tramos consecutivos de hasta 64 KiB; commit publica todo o devuelve un conflicto. Hasta 16 archivos, 1 MiB por archivo, 4 MiB por identidad y dos escritores simultáneos por módulo. Las etapas sin publicar se eliminan al desactivar. `files.import/export` requieren además `resources.documents` y abren el selector del sistema en Android/escritorio, sin exponer rutas ni URI. Los archivos quedan incluidos en la recuperación de actualizaciones. Studio guarda archivos locales, pero anuncia importExport:false para el selector. Una imagen PNG privada puede aparecer en ui.page/mount con resource: `file:imagen.png`; exige storage.files, pertenencia al registro activo y dimensiones máximas de 1024×1024. No permite leer imágenes privadas de otros módulos.
- **Credenciales propias:** `storage.secrets` habilita `secrets.get/put/remove/capabilities`. Hasta 64 claves, 4 KiB por valor y 64 KiB por identidad. Android cifra con una clave Keystore separada y excluye el archivo del backup; Windows usa DPAPI; Linux usa Secret Service si está disponible y, si falla, conserva cambios únicamente en memoria. Studio mantiene secretos de prueba solo en memoria. Consulta persistent tras guardar para conocer la persistencia efectiva. El journal contiene copias cifradas o referencias opacas, nunca valores en texto plano. No incluye credenciales de la cuenta Nelkano.
- **Guardados que requieren módulos:** `gameMod.configureSave({gameId,newGame?})`, con emulation.game-mod, declara este módulo y autor como necesarios para los guardados de un juego. Regístralo antes de abrir el juego; newGame:true exige un inicio nuevo y rechaza guardados anteriores sin esa marca. Mantiene slots manuales, autoguardado y batería habituales; no crea perfiles separados. Al cargar comprueba identidad/autor y rechaza la operación sin borrar datos si falta un módulo. Los guardados sin requisitos conservan sus bytes anteriores; las cabeceras nuevas son versionadas y admiten la cabecera anterior. Al retirar un módulo que solo exige presencia, pausa sin descartar la partida y permite guardar antes de salir; no permite reanudar mientras falte. Las sesiones con requisitos se abren pausadas para preparar el módulo antes de continuar. La retirada de módulos que modificaron RAM/reglas/ROM mantiene el cierre de sesión de gameMod ya existente. Inicio nuevo disponible en CHIP-8, GB/GBC, NES, SMS/GG, NGP, GBA, MD, SNES, NDS y PS1; otros cores lo rechazan explícitamente. Studio reproduce metadatos de guardado, no SRAM real.
- **Contenido temporal GBA:** capabilities expone el espacio `rom`, con direcciones de archivo desde cero y longitud real del cartucho. read/write/readValues/writeValues/search/observe y reglas pueden usarlo, con emulation.memory.read/write y emulation.game-mod. write compara expected y admite lotes mixtos con RAM sin efectos parciales. Cambia únicamente el cartucho cargado de esa sesión; al volver a abrir se lee la ROM original. No expande su longitud ni cambia la detección inicial del tipo de guardado. Las modificaciones de ROM no se incluyen en los estados: el módulo debe declararse necesario y volver a preparar sus cambios al cargar. Studio usa ROM sintética. Scripts y recursos con nombre de proyectos RPG Maker siguen las APIs gameRuntime anteriores y sus límites; esto no añade un motor de scripts universal a otros cores.

`services.list(name?,{offset,limit})`, `entities.types({offset,limit})` y `ui.targets({offset,limit})` devuelven páginas de hasta 32 entradas por defecto (máximo 128) y 112 KiB. Avanza offset con el número de entradas recibidas hasta obtener una página vacía. Las cuotas por tamaño pueden producir una página menor que limit.

La matriz de memoria/ROM/reglas reales corresponde a GBA. Las otras familias de core no adquieren esas capacidades por compartir el SDK. El constructor visual y cualquier otra herramienta nueva se consultarán antes de desarrollarlos.

## Servicios, proveedores y eventos propios

`modules.services` permite publicar contratos dinámicos con `host.services.register({name,version,methods})`. Cada método declara esquemas input/output como los hooks existentes. `onService(request)` recibe service, method, value y caller (identidad real del módulo y autor). `host.services.call(name,method,value,{provider?,version?,author?})` llama al proveedor dentro de su runtime aislado; list(name?) descubre proveedores y unregister(name) retira solo los propios. Los contratos del mismo nombre y versión major deben tener los mismos métodos/esquemas. No se comparte código ni almacenamiento privado.

Ajustes ya no muestra el selector global de proveedores. Un consumidor puede indicar una alternativa mediante options.provider en services.call. Sin proveedor explícito ni preferencia previa, la base tiene prioridad cuando existe; un único proveedor propio se usa automáticamente. Si hay varios sin base, el consumidor debe indicar el proveedor. El host conserva las preferencias previas por identidad del autor. Límites: 256 proveedores y 32 métodos por contrato; esquemas de profundidad 8, 32 campos declarados, datos hasta 96 KiB, arrays de 256 elementos. Se rechazan ciclos y llamadas a un runtime ocupado; cambiar/retirar el proveedor invalida respuestas en curso.

La base publica `nelkano.emulation` 1.0.0 con método `execute`: input `{operation,args}`, output `{value:resultado}`. Consulta list("nelkano.emulation") para obtener/copiar el contrato exacto. Abarca snapshot, pausa/reset, presentación, guardar/cargar, library.launch y library.setCover. Las APIs anteriores delegan a este servicio conservando sus permisos. Una alternativa elegida implementa onService; para delegar a la base utiliza call con `{provider:"nelkano.base",author:"builtin",version:"1.0.0"}`. El consumidor necesita el permiso original de la operación incluso al utilizar services.call; el proveedor que delegue también necesita ese permiso. Esta sustitución afecta a operaciones solicitadas por módulos, no reemplaza automáticamente llamadas internas de la app ni cores nativos.

`modules.events` habilita `host.events.define(topic,schema)`, subscribe(topic), unsubscribe(topic) y emit(topic,value). El nombre publicado empieza por el identificador del módulo y un punto. Solo ese autor/módulo puede emitirlo; onEvent recibe `{type:"module-event",topic,value,sender:{moduleId,author}}`. Una suscripción puede preceder al proveedor. Eventos en cola se entregan en primer plano, hasta ocho por ronda aproximadamente cada 50 ms; no ofrecen entrega durable ni tiempo exacto. Hay 256 temas, 64 suscripciones y 64 eventos pendientes por módulo. Una cola llena rechaza el envío completo sin entrega parcial. Desactivar limpia servicios, temas, suscripciones y eventos propios. Los hooks anteriores siguen funcionando.


Se distribuye como @nelkano/sdk (tipos) y @nelkano/sdk-tools (CLI). No requiere clases ni imports del repositorio. Los hosts de producción son Android nuevo y la app Desktop JVM de Windows/Linux. El SDK incluye un simulador gráfico de desarrollo para Windows x64 que reutiliza las pantallas de la nueva aplicación.

## Crear un módulo

Instala ambos paquetes .tgz con npm. Ejecuta npx nelkmod init mi-modulo, npx nelkmod check mi-modulo y npx nelkmod build mi-modulo. La entrada TypeScript puede usar import type desde @nelkano/sdk; los imports ejecutables son relativos y deben estar incluidos en el manifiesto.

Genera tu identidad con npx nelkmod keygen author.pem author-public.pem. Conserva la clave privada fuera del paquete. Empaqueta con npx nelkmod pack mi-modulo author.pem mi-modulo.nelkmod; comprueba con npx nelkmod verify mi-modulo.nelkmod. Importa desde Ajustes → Módulos y revisa firma, permisos y dependencias.

Ejemplos independientes: npx nelkmod example collections destino; npx nelkmod example hooks destino; npx nelkmod example skin destino. hooks contiene provider, icons y buttons: cada carpeta es un módulo empaquetable. Los ejemplos hooks enseñan el registro; la plantilla control-editor contiene el editor completo. Usa tu propia clave. El ejemplo Colecciones tiene identidad example.collections y convive con el incluido.

## Ganchos de Android

contributions(context) devuelve datos UiContribution: id, slot, label, actionId, order, enabled, visibility y payload. Puede incluir icon, kind (action/toggle), category (general/appearance/emulation), description y checked. Un toggle despacha checked con el nuevo estado y solo cambia al refrescar la respuesta del módulo.

LIBRARY_ACTION se dibuja junto a ordenación y vista; LIBRARY_SELECTION_ACTION en la selección. SETTINGS_SECTION y ajustes de sistema/emulación se dibujan como filas. PLAYER_SYSTEM_BUTTON se integra en el catálogo de geometría de emulación; placement contiene portrait/landscape con x/y entre 0 y 1, scale entre 0.5 y 2 y visible. Máximo 16 por módulo/contexto. Los demás slots documentados conservan sus zonas; PLAYER_OVERLAY y MODULE_PANEL siguen reservados.

icon puede ser standard:collections, standard:settings, standard:add o standard:reset, o una ruta PNG de files. Android muestra un icono estándar si falta o no puede decodificarse. PNG limitado al decodificar a 2048×2048. Si un proveedor muestra un icono de un consumidor, indica iconOwner; el host verifica que ese consumidor aportó exactamente esa ruta a un gancho del proveedor. No se admiten rutas externas. Cada icono conserva etiqueta accesible y la barra gestiona desbordamiento.

## Ganchos entre módulos

Declara la capacidad modules.hooks. provides publica name/version y tres esquemas: contribution, input y output. consumes declara provider/hook/version/optional, y author opcional (SHA-256 de la clave pública) para fijar publicador. dependencies declara id/version/optional y author opcional. El registro pertenece al host; cada runtime sigue aislado.

host.hooks.status() informa qué ganchos consumidos están disponibles. contribute(provider,hook,id,value) añade o reemplaza una aportación propia. list(provider,hook) devuelve aportaciones con moduleId, author, id y value; el proveedor puede leer sus propios ganchos. invoke(provider,hook,operation,value) llama onHook({hook,operation,value,caller:{moduleId,author}}) del proveedor y valida entrada y respuesta.

Los esquemas admiten type object/array/string/number/integer/boolean/null, properties, required, items, enum y additionalProperties. Máxima profundidad 8, 32 propiedades de esquema, 256 elementos de array y 128 KiB por mensaje. No hay JSON Schema completo ni importación de código de otro módulo.

Una versión requerida es un mínimo dentro del mismo major: 1.1.0 acepta 1.2.0 pero no 2.0.0. Una dependencia obligatoria debe estar activa y ser compatible; si desaparece se desactiva su consumidor conservando datos. Una opcional ausente retira su integración; el consumidor recibe hooks-changed y mantiene el resto. No se activan proveedores automáticamente ni se descargan dependencias. Se rechazan ciclos obligatorios y llamadas a un runtime ocupado (hook-call-cycle-or-busy), evitando llamadas circulares; el consumidor puede tratar este error. Los ganchos se retiran al desactivar o caer un módulo.

Los contratos del editor son icons (ControlIconContribution: target/icon/label) y system-buttons (SystemButtonContribution: actionId/icon/label). El proveedor almacena la elección del usuario por autor + moduleId + id; instalar alternativas no cambia la elección. Al desaparecer una alternativa usa el icono predeterminado y conserva la preferencia. El editor usa invokeContributor para ejecutar el callback del consumidor registrado. Los ejemplos anteriores siguen mostrando el patrón invoke hacia un proveedor declarado.

## Apariencia

Declara presentation.appearance y skins en el manifiesto. Cada skin contiene id/label y opcionalmente colors, background PNG, font TTF, icons, cornerRadius (0–32 dp), spacing (2–24 dp), controlHeight (36–64 dp), headerHeight (48–88 dp), navigation (bottom/top) y libraryView (grid/list inicial). Los recursos pertenecen al paquete verificado. Copia licencias de fuentes junto a los recursos.

Tokens de color: background, surface, surfaceSoft, border, text, muted, primary, primarySoft. Formato #RRGGBB o #AARRGGBB. icons usa nav.home/nav.library/nav.saves/nav.settings y standard:add/standard:reset/standard:settings. Los botones de juego mantienen su elección de iconos a través del editor; el skin no la reemplaza automáticamente.

El usuario selecciona un skin en Ajustes → Apariencia. La elección se guarda por autor y módulo; el host restaura el estilo predeterminado mientras está desactivado/desinstalado. La distribución inicial de biblioteca no reemplaza la vista que el usuario ya eligió en esa pantalla. No hay pantallas arbitrarias ni código Compose del módulo.

## Capacidades, datos y límites

storage.private.cas: documentos SQLite con CAS, privados por id y autor, hasta 96 KiB. library.read y saves.read: snapshots de solo lectura, hasta 128 KiB. Los paneles contienen campos text/select/json, filas y acciones. Los campos select usan desplegables tanto en páginas como en diálogos; presentation:tabs conserva las pestañas. El valor elegido mantiene su formato JSON. Las confirmaciones y copiar/pegar JSON se dibujan por Android. data-changed puede devolver filtros de games/saves; los de módulos activos se intersectan.

Paquete ZIP formato 1: hasta 32 MiB, 128 entradas y 8 MiB/archivo; JS/JSON/SVG/PNG/TXT/TTF, firma Ed25519 y todos los recursos declarados. SVG puede empaquetarse pero no se renderiza como icono en esta versión. SDK 0.1.0 permanece compatible. Doce runtimes QuickJS aislados, heap 32 MiB cada uno y cinco segundos por operación. Sin filesystem, red ni APIs Android expuestas a JavaScript. Una firma identifica autor, no confianza. Desinstalar conserva datos salvo elección expresa de borrarlos; actualizar requiere el mismo autor y el módulo desactivado.


## Modificar juegos con gameMod

host.gameMod abre herramientas generales de modificación sin cambiar los módulos actuales. Declara emulation.game-mod y consulta capabilities(session) con emulation.read antes de trabajar: cada core anuncia los espacios, regiones, permisos y límites que realmente conecta. Una dirección pertenece al espacio indicado; en GBA cpu utiliza direcciones absolutas. read requiere emulation.memory.read; write requiere emulation.memory.write y compara todos los bytes expected antes de escribir el lote. data y expected son base64 canónico. Un desacuerdo devuelve applied:false y conflictIndex sin escritura parcial.

installRule(session,{id,conditions,writes}) requiere lectura y escritura. Evalúa condiciones y bytes esperados en cada frame del motor, sin llamar JavaScript por frame; si alguno difiere no aplica el lote. removeRule requiere escritura y listRules lectura; ambas operaciones solo acceden a reglas de la identidad del módulo. Límites GBA: 32 rangos y 32 KiB por lote; 16 reglas y 32 KiB de condiciones/escrituras entre todas las reglas de la sesión. Las condiciones y escrituras se restringen a EWRAM/IWRAM. El resto de regiones anunciadas son de consulta.

Las zonas reservadas por otro módulo producen modification-conflict. Retirar una regla no deshace sus efectos ni libera su reserva: ambas duran hasta cerrar la sesión. Desactivar, actualizar o perder un módulo que haya usado estas modificaciones cierra su sesión; la ROM original permanece intacta. Los efectos incorporados a un guardado normal pueden persistir. gameRuntime.patch conserva su comportamiento anterior; las escrituras antiguas participan en los conflictos con gameMod y su retirada por sí sola no cierra la partida.

Studio ofrece memoria GBA sintética y anuncia simulated:true; sus reglas se evalúan en pasos simulados independientes de los callbacks JavaScript. No ejecuta un core ni acredita compatibilidad de un juego. Los motores sin integración anuncian capacidades vacías y límites cero. La validación real requiere la aplicación y el core anunciado.
## SDK Studio: editor y simulador gráfico

Requisitos para usar la distribución: Windows x64 y Node.js 22 o posterior con npm. El paquete sdk-tools incluye la ventana Compose y su Java; no necesitas Android Studio, Gradle, teléfono ni Java instalado. La ventana integra proyectos, árbol de carpetas, editor JS/TS/JSON con pestañas y visor. Ejecuta npx nelkmod dev sin argumentos para empezar vacío o pasa carpetas para abrirlas.

Desde una carpeta de trabajo independiente, instala los dos paquetes .tgz de esta entrega:

```powershell
npm install C:/ruta/nelkano-sdk-0.2.0.tgz C:/ruta/nelkano-sdk-tools-0.2.0.tgz
npx nelkmod init mi-modulo
npx nelkmod dev mi-modulo
```

Para probar un ejemplo completo:

```powershell
npx nelkmod example collections colecciones
npx nelkmod dev colecciones
```

La ventana muestra la misma Home, biblioteca, ficha de juego, guardados, ajustes y controles que el código compartido de Android. Abrir módulo selecciona otra carpeta de fuentes; admite hasta doce módulos simultáneos. También puedes pasar varias carpetas a dev: por ejemplo hooks/provider hooks/icons hooks/buttons. Prueba las aportaciones opcionales y obligatorias activando y desactivando proveedores.

Cada módulo se compila y valida al cargarlo. Los cambios en archivos declarados y manifest.json se recargan automáticamente; si la compilación falla continúa el código anterior y aparece el error. La recarga válida conserva los datos privados. Restablecer datos borra solo los documentos y la elección de apariencia del entorno de desarrollo. El panel de eventos registra operaciones del host, acciones, console.log y errores. Los skins usan colores, iconos, geometría, navegación, PNG y TTF del módulo.

Los juegos y guardados son ficticios. Biblioteca y Colecciones, favoritos, filtros, paneles, CAS, permisos y ganchos entre módulos ejecutan código real. Iniciar un juego crea una sesión simulada para probar botones y eventos: no ejecuta ROMs, audio, Bluetooth, red, Drive ni emulación. Las operaciones de guardar/cargar y teclas producen eventos de prueba. La comprobación final de hardware, JNI, rendimiento y permisos Android sigue requiriendo la nueva app.

El código se ejecuta en QuickJS WASM aislado, sin acceso a Node, filesystem o red, con 32 MiB por módulo y cinco segundos por llamada. Se aplican esquemas y versiones de ganchos, retirada de aportaciones, límites de mensajes y 96 KiB por documento CAS. El almacenamiento de desarrollo usa JSON local en lugar del SQLite de Android. No es una reproducción del motor nativo ni de los servicios Android.

Si arrancas con carpeta, .nelkdev se crea allí; sin argumentos, en el directorio actual. Contiene: author.pem, documentos, apariencia y exports. Esa clave se genera una sola vez y mantiene la identidad al recargar o reiniciar. No la publiques en Git; los proyectos generados incluyen .gitignore. Exportar .nelkmod guarda primero los documentos abiertos, compila de nuevo, firma y verifica el paquete sin cambiar versiones. Con mi clave permite usar una identidad de distribución Ed25519 existente; al cambiar de autor Android lo tratará como otra identidad, no como actualización del autor anterior. La ruta del resultado aparece en la ventana.

Para autores del SDK, la receta del runtime está en sdk/simulator, no en build. Desde src/nelkano ejecuta:

```powershell
./gradlew.bat :sdk:simulator:stageSdkRuntime -PnelkanoPackagingJdk=C:/ruta/a/JDK-completo
```

El empaquetado requiere un JDK completo con jpackage (Android Studio puede proporcionar solo JBR). La salida desechable se copia a sdk/tooling/simulator y entra en npm pack de sdk-tools. No se sube el binario a Git: se reconstruye desde fuentes. Para probar el broker sin ventana usa serveDev() desde dev.mjs; --headless mantiene el host para diagnóstico, pero no muestra la app.

### Crear y editar dentro de la ventana

Nuevo módulo pide carpeta superior, nueva carpeta, nombre, ID y plantilla Básico, Colecciones o Apariencia. Genera fuentes independientes. El árbol permite crear archivos y carpetas e importar PNG/TTF. Los padres deben existir; registrar en manifest.json añade archivos compatibles a files, sin importar automáticamente su código. Guarda primero un manifiesto con cambios pendientes.

Abre archivos en pestañas. El editor incluye números de línea, resaltado sencillo, indentación, Ctrl+F y Ctrl+S. Guardar recompila y actualiza el visor; un borrador sin guardar no se ejecuta. Problemas muestra errores; Eventos muestra operaciones del host. Un error de compilación conserva el runtime anterior. Los cambios externos se detectan por revisión: recarga y reconcilia antes de guardar. El cierre ofrece guardar, descartar o cancelar. Exportar guarda todos los documentos primero y se detiene ante un conflicto.

Textos UTF-8 hasta 64 KiB; árbol hasta 1.000 entradas y doce niveles. No sigue symlinks ni muestra .git, node_modules, build, dist, .nelkdev, claves .pem/.key o paquetes exportados. Los binarios se importan, no se editan como texto. No incluye autocompletado semántico, breakpoints, Git integrado, renombrado/eliminación desde el árbol, editor gráfico de imágenes ni instalación en el teléfono. Tras exportar, importa el .nelkmod en Android nuevo.
### Distribución de paneles y búsqueda

Arrastra los separadores entre Proyectos, editor y visor para ajustar sus anchos; el separador de la consola ajusta su altura. Proyectos puede ocultarse y recuperarse con el botón de cabecera. Ajustes agrupa las acciones de crear/abrir, guardar, exportar, clave, mostrar/ocultar paneles, orientación, recompilación y restablecimientos. Restablecer distribución recupera el espacio inicial sin borrar datos; los tamaños se mantienen durante la sesión.

Ctrl+F abre y enfoca el buscador del archivo. La búsqueda literal no distingue mayúsculas; resalta todas las coincidencias y distingue la actual. Contador y desplazamiento automático hasta el resultado. Intro/F3/flecha abajo avanzan, Mayús+Intro/Mayús+F3/flecha arriba retroceden y Esc cierra. Buscar no modifica el archivo. Ctrl+S guarda y Ctrl+Mayús+S guarda todo desde la ventana.

## Chat con Codex o Claude Code

El chat sigue automáticamente la carpeta del proyecto seleccionado. Al abrir o cambiar de módulo se muestra su conversación; la petición siguiente trabaja en esa carpeta. Los borradores de mensajes se conservan al cambiar de proyecto. Un turno ya iniciado termina en su carpeta original.

Solo hay dos desplegables: **Modelo** y **Nivel**. Modelo incluye el agente en su nombre (Codex o Claude Code); no hay botones separados para agente, Detectar, Consultar/Editar o Nueva. El chat permite editar las fuentes según la petición. La flecha del campo Mensaje envía; Ctrl+Intro también. Mientras trabaja, el cuadrado detiene el proceso activo, incluso si cambiaste de proyecto.

Codex consulta el catálogo del CLI mediante app-server model/list y muestra los niveles ofrecidos por ese catálogo. Se envían explícitamente modelo y esfuerzo, sin heredar un modelo global incompatible ni cambiar la configuración del usuario. Si no se obtiene catálogo no se inventan modelos Codex. Claude ofrece los alias Sonnet, Opus y Haiku; no son una comprobación del acceso de la cuenta. Para Sonnet/Opus se ofrecen Bajo/Medio/Alto, y Haiku usa su nivel predeterminado.

Necesitas CLI instalado y autenticado: codex login o claude desde una terminal. La detección se actualiza al abrir el panel y cada minuto; no hay botón Detectar. Studio no instala ni autentica agentes ni copia credenciales. Las peticiones y el contexto que lea el agente se envían a su servicio según la configuración de su CLI.

Antes de enviar se guardan los archivos abiertos del módulo; si falla, no se ejecuta el agente. Sesiones e historial siguen separados por carpeta/proveedor en .nelkdev/chats; el último modelo/nivel utilizado se guarda con la conversación. Al finalizar se actualizan editor y visor; se conservan borradores y la protección contra sobrescrituras externas. Un fallo de compilación conserva el último módulo válido. Cancelar/cerrar mantiene cambios parciales. Versiones, commits/push y exportaciones no se automatizan.

Es una función del IDE fuera de QuickJS, no un gancho del SDK. Codex usa workspace-write y approval_policy=never; Claude Read/Glob/Grep/Edit/Write, sin Bash. No se eluden límites del CLI ni se tramitan aprobaciones interactivas. Cwd e instrucciones no garantizan aislamiento completo del sistema operativo. Studio compila el visor. Las pruebas con agentes simulados no certifican una conversación real para cada cuenta/modelo.

## Abrir Studio en Windows

El acceso directo de este equipo inicia tooling/studio.vbs con Colecciones, sin consola visible. Abrir-simulador.cmd delega en ese mismo lanzador y termina enseguida: cerrar su consola ya no cierra Studio. El proceso auxiliar Node permanece oculto hasta cerrar el SDK.

El ejecutable distribuido también puede abrirse directamente: si no recibe conexión al host, inicia studio.vbs y el host local, usando datos de desarrollo bajo %LOCALAPPDATA%/Nelkano/SDK. En ese caso abre Studio vacío; usa Ajustes para abrir o crear un módulo. Para npm siguen disponibles npx nelkmod dev y npx nelkmod dev ruta-del-modulo. Necesita Node.js en PATH; Java está incluido.

La ventana y el ejecutable usan el icono de Nelkano conservado en las fuentes del simulador (PNG/ICO). El lanzador también se incluye en sdk-tools; borrar build/ permite reconstruir desde fuentes.

## Editor de controles y lienzo declarativo

El módulo incluido nelkano.control-editor (0.1.0) usa SDK 0.2.0. Su lógica vive en modules/control-editor; el APK incorpora un .nelkmod firmado, desactivable e importable. Mantiene doce perfiles, vertical/horizontal, selección múltiple, movimiento en grupo, tamaños 0.5–2, visibilidad, cuadrícula y ajuste, zoom 1–4, desplazamiento y vista previa. Guardar confirma todos los perfiles visitados e iconos elegidos en un CAS; Cancelar conserva el diseño guardado.

Capacidad environment.display: host.environment.snapshot() devuelve width/height en píxeles, density, touchSlop y fpsVisibleByDefault. Studio devuelve métricas ficticias. No proporciona acceso a una ventana nativa.

Capacidad presentation.control-layouts: host.presentation.applyControlLayouts({moduleId,revision,profiles,layouts,icons?}) publica una capa propia. layouts usa claves PROFILE|PORTRAIT o PROFILE|LANDSCAPE y cada control admite x/y normalizados [0,1], scale [0.5,2], visible boolean. icons asocia ID de control con {moduleId,path}; el broker exige PNG declarado propio o aportado al proveedor. Se rechazan propietarios ajenos, revisiones anteriores y valores no válidos. releaseControlLayouts(moduleId) retira la capa propia; desactivar, desinstalar o fallar retira sus efectos y conserva datos. Si coinciden varias capas, la elección por perfil es determinista según el ID de módulo; se recomienda activar un único editor para cada perfil.

Respuesta dispatch: {kind:'control-editor',title,profile,orientation,profiles,nodes,viewport,grid,preview,scaleLevels,scaleLevel}. Un nodo contiene id,label,kind SCREEN/DPAD/JOYSTICK/INPUT/SYSTEM_ACTION,bounds [left,top,right,bottom] en píxeles del lienzo,value {x,y,scale,visible},selected,shown,opacity,asset e iconOwner opcional. viewport contiene virtualWidth/virtualHeight,scale,left/top; el módulo responde a resize(width,height). El host valida límites y recursos antes de mostrar el lienzo compartido por Android y Studio. No ejecuta callbacks UI del módulo. Las acciones del lienzo son switch(profile,orientation), drag(id,phase,x,y), select(id,toggle), scale-begin/scale(level)/scale-end, visibility, grid, reset, zoom, preview, save y cancel.

El editor publica icons y system-buttons 1.0.0. Un consumidor declara modules.hooks y consumes con provider nelkano.control-editor, hook, version y optional. icons acepta {target,icon,label}; target identifica el control (por ejemplo a o sys-pause). system-buttons acepta {actionId,icon,label,target?}. El editor conserva las elecciones por autor + módulo + ID. Si desaparece el consumidor, usa el icono predeterminado y retira sus botones, conservando la elección para una futura reactivación.

Para ejecutar un botón aportado, el proveedor usa host.hooks.invokeContributor(hook,moduleId,id,operation,value). Solo puede llamar a un consumidor que haya aportado ese ID a uno de sus propios ganchos. El broker comprueba identidad, disponibilidad y esquemas input/output; llama onHook del consumidor con hook,operation,value,contributionId y caller. No necesita conocer por adelantado IDs de futuros consumidores. Se mantiene el rechazo de llamadas circulares/runtime ocupado.

Crea una copia autónoma con npx nelkmod example control-editor mi-editor o la plantilla Editor de controles de Studio. La copia usa example.control-editor y una clave propia; puede coexistir, pero desactiva otros editores para probar su capa. Los perfiles se separan en src/profiles/*.js para poder abrirlos y editarlos en Studio. Guarda, verifica, exporta y prueba en Android nuevo. La receta interna bundle-control-editor.mjs empaqueta la copia incluida, con clave de desarrollo fuera del repositorio; sync-control-example.mjs sincroniza la plantilla desde las fuentes canónicas.

La asignación de teclas físicas/Bluetooth corresponde a gamepad y sigue pendiente. El lienzo no implementa funciones de grabación, reproducción ni autoguardado: los botones del catálogo solo ejecutan funciones disponibles en el jugador o acciones aportadas por otros módulos. Los SVG del catálogo se conservan en el paquete; el renderer utiliza etiquetas para ellos porque aún no decodifica SVG como icono. Studio no ejecuta ROMs ni hardware. SDK, APK y módulo mantienen sus versiones por petición de Ivan.


Secciones de Ajustes, 2026-10-04: Apariencia y Emulación son secciones de General, no pestañas. SETTINGS_SECTION admite section opcional, texto no vacío de hasta 64 caracteres sin controles, validado por ambos hosts. category conserva general/appearance/emulation como clasificación compatible; sin section se usan Funciones adicionales/Apariencia/Emulación. Colecciones declara Biblioteca y el editor Controles en pantalla; se retiran al desactivar el módulo. Tema se selecciona en General → Apariencia → Tema. BIOS conserva su pestaña; no se crean entradas de funcionalidades pendientes. Slots de ajustes de sistema y de emulación no cambian. Libro local importado y exportado; versiones e identidades de firma conservadas.

## Nelkano básicos y library.delete

La plantilla basics y el módulo modules/basics (nelkano.basics 0.1.0) añaden borrado individual en la ficha y múltiple en selección. host.library.requestDelete(gameIds) requiere library.delete, IDs existentes únicos (1–100) y devuelve {pending:true}. El host muestra confirmación nativa: cancelar conserva todo; confirmar borra biblioteca, copia importada privada y guardados. El módulo no puede aprobar ni obtiene archivos. El archivo original del selector se conserva. Studio solo modifica sus juegos ficticios, persistidos por entorno de desarrollo; Restablecer datos restaura las muestras. El nombre todavía no se puede modificar. library.setCover permite usar una captura de guardado como carátula. SDK 0.2.0 sin incremento de versión.


### Autoguardados de Nelkano básicos

`saves.autosave` permite `host.saves.setAutoSave(enabled)` con un booleano estricto. Publica una política del módulo, sin rutas, bytes de estados ni temporizadores JavaScript. Android escribe cada 60 segundos de juego continuo y sin pausa si el core admite SAVE_STATES y permite guardar. Usa el slot reservado 6, separado de los manuales 0–5, visible como Autoguardado y cargable desde ficha/Guardados. Pausar o cerrar la partida detiene el temporizador. Desactivar, desinstalar o fallar el módulo retira su solicitud; reactivar recupera la preferencia privada persistida por CAS. Con varias solicitudes basta una activa. El valor predeterminado es desactivado. Studio simula el ajuste y un slot ficticio cada minuto en su sesión de prueba, sin ejecutar ROMs ni producir estados reales.

## Operaciones de emulación

Android ejecuta las operaciones; el módulo decide cuándo usarlas. Studio implementa el mismo contrato con datos ficticios.

- emulation.read: host.emulation.snapshot() devuelve null o sesión, juego, pausa, capacidades, slots y display. También habilita eventos de partida.
- emulation.control: setPaused(session, boolean), reset(session).
- presentation.player: setFullscreen(session, boolean), setStretch(session, boolean), setScreenMode(session, 0|1|2), selectSlot(session, 0..6).
- saves.write: host.saves.save(session, 0..5).
- saves.load: host.saves.load(session, 0..6), solo guardados existentes.
- library.launch: host.library.launch(gameId, slot?), para un ID existente. Sin slot empieza de nuevo; con slot continúa.

Usa la referencia id/generation de la acción, no la de una partida posterior. El host rechaza sesiones antiguas, valores incorrectos, permisos ausentes y operaciones que el core no soporte. El slot 6 es automático y no admite escrituras manuales.

Eventos en onEvent: session-started, session-paused, session-resumed, session-closed, session-reset, save-created, save-loaded, display-changed. Incluyen session y gameId; guardados incluyen slot y automatic. No hay eventos por fotograma.

Nelkano básicos aporta los botones actuales mediante estas APIs, y la acción Continuar con payload.primaryLaunch. PLAYER_SYSTEM_BUTTON puede indicar payload.controlId para conservar posición/iconos ajustados en el editor. El editor transmite request.value.context al consumidor de system-buttons.

Guardar genera una miniatura del motor cuando hay imagen disponible. saves.list incluye hasThumbnail y library.list incluye coverSlot. library.setCover(gameId, slot) requiere library.cover y copia la captura; null restaura la portada. GAME_ARTWORK_ACTION coloca el botón sobre la imagen. Los paneles admiten preview y filas thumbnail: {gameId, slot, original?}; se validan library.read/saves.read y los IDs del catálogo. La captura independiente, su exportación y el renombrado siguen pendientes. Consulta el libro local, capítulo Emulación: operaciones y eventos, para ejemplos completos.

## Amigos

Plantilla Amigos (simulación): registro, acceso, solicitudes y perfil ficticios. Usa demo@nelkano.test / Nelkano123. No hay correo ni conexión remota. Android conecta con https://nelkano.com mediante sesión cifrada, renovación y permisos firmados. Permite registro con activación por correo, acceso, amistades y edición de perfil con foto. Studio sigue usando únicamente datos ficticios. Consulta modules/friends/README.md y el capítulo Amigos del libro local.

Amigos publica friend-actions, friends-data y friends-events 1.0.0. Ejemplo: npx nelkmod example friends-hooks destino. Consulta el capítulo Amigos del libro local. No es una integración de mundos ni extracción de memoria Pokémon.

## Mandos, segunda pantalla, apariencia, parches y streaming

Básicos reutiliza catálogo y preferencias de mando, protocolo LAN de segunda pantalla y motor WebRTC. Apariencia reúne español/inglés y cinco paletas. Parches reutiliza IPS/VCDIFF y crea una copia GBA/NDS sin sobrescribir el original. Ninguno depende del Android antiguo.

Puertos: input (input.gamepad), secondScreen (media.second-screen), streaming (media.streaming), appearance (appearance.locale y presentation.appearance), patches (resources.patch). Ganchos 1.0.0: Básicos/gamepad, second-screen y streaming; Apariencia/settings, theme-options y locale-options; Parches/apply-patch. Consulta los capítulos 16–19 del libro local para ejemplos y límites.

Streaming pide confirmación nativa y usa cuenta/señalización de https://nelkano.com. Studio simula la emisión sin enviar datos; no ejecuta ROMs, conecta hardware ni aplica parches binarios. Falta comprobar mando, segunda pantalla y emisión con dispositivos físicos. El respaldo HTTP de vídeo/audio ya está conectado: WebP/JPEG adaptativo y PCM mono 16 kHz. Se recuperan cierres pendientes por cuenta; no se reanudan emisiones automáticamente. input.importProfile/exportProfile abren documentos JSON de hasta 96 KiB en Android. Studio simula estos selectores: no escribe archivos y la importación devuelve cancelled; usa Copiar / pegar para probar un respaldo.

## GBA Online y Pokémon Online

Ejemplos opcionales e independientes: `npx nelkmod example gba-online mi-gba-online` y `npx nelkmod example pokemon-online mi-pokemon-online`. Carga Amigos y ambos módulos en Studio. La memoria GBA, los checkpoints y el mundo son simulados; no se ejecuta Ruby ni se conecta a Internet. Las pruebas reales requieren exportar e importar en la aplicación. Contratos en `src/index.ts` del paquete SDK y documentación web, capítulo Online GBA.
## Números y observación de cambios

`host.gameMod.readValues(session, {values})` lee `u8`, `i8`, `u16`, `i16`, `u32`, `i32`, `f32` y `f64`. Cada entrada contiene `space`, `address`, `type` y `endian` opcional (`little`/`big`, por defecto el orden del espacio). Devuelve `value`, los mismos datos de dirección/tipo, `endian` efectivo y `data` Base64. Los floats no finitos devuelven `value:null`; `data` conserva los bits originales. Para NaN, infinito, cero con signo o comparaciones exactas de representaciones usa la API de bytes. Los enteros fuera de rango, fracciones enteras y desbordamientos float se rechazan.

`writeValues(session, {writes})` añade `value` y `expected` numéricos. Convierte todo el lote antes de escribir y utiliza los mismos permisos, comparación atómica, conflictos y retirada que `write`. Hasta 32 valores por lote. En hosts anteriores comprueba que estas funciones existan antes de llamarlas; no se ha cambiado la versión 0.2.0.

`observe(session, {id, ranges, everyFrames?})` requiere `emulation.game-mod`, `emulation.memory.read` y `runtime.events`. Consulta `memoryObserve`, `maxWatches`, `maxWatchBytes` y `maxWatchRanges`. GBA comparte 16 observaciones, 32 rangos y 16 KiB observados por sesión; `everyFrames` admite 1–600, por defecto 1. Se captura la base al registrar y se compara después de avanzar frames; pausar/capturar no produce muestras. Repetir tu id reemplaza tu observación y descarta avisos pendientes.

El módulo recibe en `onEvent` un objeto `game-memory-changed` con `session`, `watchId`, `sequence`, `frame`, `changes` y `ranges` (`space`, `address`, `before`, `data`, en Base64). Solo hay un aviso pendiente por observación: conserva el primer `before`, el último `data` y el número de muestras cambiadas agrupadas. El host entrega avisos aproximadamente cada 100 ms mientras está en primer plano; no garantiza detectar cambios transitorios entre muestras ni es una traza completa. El contador `frame` es de muestreo del adaptador; Studio cuenta pasos sintéticos, no fotogramas reales. Las observaciones permanecen en reset/load de la misma sesión y se comparan al volver a avanzar.

`unobserve(session, id)` retira únicamente tu observación y su aviso pendiente. Desactivar un módulo que solo observa conserva la partida abierta; escribir memoria o registrar reglas mantiene el cierre de la sesión al retirarlo. Cerrar/cambiar sesión elimina las observaciones anteriores. Studio simula el mismo contrato, sin ejecutar juegos. configureSave incorpora requisitos de módulo/autor y nueva partida por capacidad del core, descritos arriba.

## Buscar valores y generar código

Las búsquedas requieren `emulation.game-mod` y `emulation.memory.read`. Consulta `memorySearch`, `maxSearches`, `maxScanBytes`, `maxSearchBytes` y `maxSearchResults`. GBA y Studio comparten por sesión hasta cuatro búsquedas, 256 KiB por búsqueda y 1 MiB de capturas; cada página devuelve hasta 128 resultados. Otros cores anuncian false/cero.

```js
const search = await host.gameMod.searchStart(session, {
  space: "cpu", address: 0x02000000, length: 262144,
  type: "u16", mode: "unknown"
});
// Tras cambiar algo en el juego, conserva los candidatos que aumentaron.
const refined = await host.gameMod.searchRefine(session, {
  id: search.id, mode: "increased"
});
const page = await host.gameMod.searchRead(session, {
  id: search.id, offset: 0, limit: 32
});
await host.gameMod.searchClose(session, {id: search.id});
```

`searchStart` admite `equal` con `value` o `unknown` sin valor; tipos u8/i8/u16/i16/u32/i32/f32/f64. `endian` toma el orden del espacio por defecto. `alignment` admite 1/2/4/8 y por defecto el tamaño del tipo: es el paso entre candidatos desde la dirección inicial. El rango debe caber en una región legible.

`searchRefine` admite equal/notEqual (con value), changed/unchanged/increased/decreased (sin value). Compara solo los candidatos retenidos con la última captura y actualiza esa base cuando termina correctamente. changed/unchanged comparan bits; increased/decreased requieren números finitos. equal compara números, redondeando f32 a su representación; los no finitos se entregan como null y no coinciden con un valor finito.

La respuesta contiene id, matchCount, scannedBytes, revision, space, address, length, type, endian, alignment y paged. `searchRead` añade offset, results y hasMore. Los resultados incluyen dirección, tipo, orden, value y data Base64 de la última captura; no son lecturas nuevas en tiempo real. Conserva todos los candidatos aunque se vean por páginas. La captura usa tramos de hasta 32 KiB: con el juego en marcha no garantiza un instante simultáneo; pausa explícitamente si lo necesitas.

Las búsquedas son privadas por módulo y autor. searchClose devuelve false si no existe una búsqueda propia. Desactivar un módulo que solo busca conserva la partida abierta. Cerrar o cambiar sesión descarta las búsquedas; reset/load en la misma sesión conserva la captura anterior hasta refinarla.

En Studio pulsa **Explorar memoria**, abre GBA de prueba y elige dirección, tipo y rango. Puedes leer bytes y valores, iniciar una búsqueda conocida/desconocida, filtrarla, seleccionar un resultado y generar lectura, escritura comprobada u observación en JS/TS. **Copiar código** entrega funciones editables; debes incorporarlas a tu módulo y declarar sus permisos. La escritura generada lee primero expected y comprueba si se aplicó. La observación requiere también runtime.events. **Cambiar valor de prueba** solo modifica la RAM sintética de Studio, respetando los conflictos con módulos; cerrar el explorador libera sus búsquedas y conserva esos cambios hasta cerrar/restablecer la sesión. No conecta Studio a partidas reales ni edita automáticamente tus archivos.

Reportes de errores es una función privada del módulo oficial para cuentas Tester. Sus operaciones y transporte no forman parte del SDK público y no se conceden a módulos de terceros.

Nelkan IA incorpora en snapshot/assistant-state los campos microphoneReady (confirmación real del reconocedor) y heard (transcripción parcial/final privada). La conexión local fallida recurre al servicio configurado; los errores quedan visibles y la escucha sigue limitada al primer plano. Esto no acredita reconocimiento acústico con todas las voces.

Nelkan IA permite elegir voces del motor Android: set-voice({voice:string}) guarda el ID validado y preview-voice({}) sintetiza un ejemplo fijo. snapshot incluye voices ({id,label,network}), voice, voiceReady, voiceLoading y previewing. Se requieren los mismos permisos assistant.voice y modules.services. Catálogo hasta 64 voces españolas, excluyendo las marcadas pendientes de instalación; no es un catálogo universal de voces ni selecciona el modelo Qwen.

Nelkan IA queda dedicado a información documentada de Nelkano: Qwen devuelve un ID entre los apartados recuperados y el host valida y entrega únicamente texto local revisado o un aviso de falta de información. No se exponen respuestas generales libres, no se modifican pesos y no se ejecutan acciones. El manual de la app modular se conserva en assistant/src/main/assets/nelkano-knowledge.json.

La aplicación base incorpora su propio actualizador: comprueba versiones oficiales, descarga y verifica el paquete y entrega la instalación a Android, Windows o Linux/SteamOS tras cerrar la partida. Este mecanismo conserva los datos y módulos y no añade operaciones JavaScript al SDK. SDK Studio no consulta ni instala actualizaciones de la aplicación; su distribución se actualiza por separado. La primera aplicación con este sistema debe instalarse por el procedimiento habitual y el catálogo debe desplegarse antes de ofrecer una versión posterior.
