import {numberSize,encodeNumber,decodeNumber} from './game-mod-numbers.mjs';
import {GameModSearches,SEARCH_LIMITS} from './game-mod-searches.mjs';
const copy = value => JSON.parse(JSON.stringify(value));
const need = (value, message) => { if (!value) throw Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const exactKeys = (value, required, optional = []) => need(object(value) && required.every(key => Object.hasOwn(value, key)) && Object.keys(value).every(key => required.includes(key) || optional.includes(key)), 'invalid-game-mod-object');
const MAX_RANGES = 32, MAX_BYTES = 32768, MAX_RULES = 16;
const operations = {
  'gameMod.configureSave':'emulation.game-mod',
  'gameMod.input':'emulation.input',
  'gameMod.capabilities': 'emulation.read',
  'gameMod.read': 'emulation.memory.read',
  'gameMod.write': 'emulation.memory.write',
  'gameMod.installRule': 'emulation.memory.write',
  'gameMod.removeRule': 'emulation.memory.write',
  'gameMod.listRules': 'emulation.memory.read',
  'gameMod.readValues': 'emulation.memory.read',
  'gameMod.writeValues': 'emulation.memory.write',
  'gameMod.observe': 'emulation.memory.read',
  'gameMod.unobserve': 'emulation.memory.read',
  'gameMod.searchStart':'emulation.memory.read','gameMod.searchRefine':'emulation.memory.read','gameMod.searchRead':'emulation.memory.read','gameMod.searchClose':'emulation.memory.read',
};
export const gameModCapability = method => operations[method] ?? null;
const sessionKey = ref => ref.id + ':' + ref.generation;
const overlaps = (a, b) => a.space === b.space && a.address < b.address + b.length && b.address < a.address + a.length;
const decode = text => {
  need(typeof text === 'string' && text.length > 0 && text.length <= 43692 && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text), 'invalid-memory-bytes');
  const bytes = Buffer.from(text, 'base64');
  need(bytes.length > 0 && bytes.length <= MAX_BYTES && bytes.toString('base64') === text, 'invalid-memory-bytes');
  return bytes;
};
/** Synthetic memory only. Studio never runs a core or opens a real game here. */
export class GameModFixtures {
  constructor(engine) { this.engine = engine;this.rom=Buffer.alloc(16*1024*1024);this.rom.write('BPEE',0xac); this.rules = new Map(); this.claims = []; this.baselines = new Map(); this.watches=new Map();this.frame=0;this.eventTimes=new Map();this.searches=new GameModSearches((ref,value)=>this.access('sdk-search', 'gameMod.read',[ref,value]),ref=>this.descriptor(this.check(ref)));this.searchSession=null; }
  started(owner){this.engine.moduleSavePolicy.start(owner)}
  check(ref) {
    need(object(ref) && Object.keys(ref).sort().join(',') === 'generation,id' && typeof ref.id === 'string' && ref.id.length > 0 && ref.id.length <= 128 && Number.isSafeInteger(ref.generation) && ref.generation >= 0, 'invalid-session');
    const current = this.engine.player.current;
    need(current, 'session-unavailable');
    need(current.session.id === ref.id && current.session.generation === ref.generation, 'stale-session');
    this.prune();
    return current;
  }
  prune() {
    const current = this.engine.player.current?.session;
    const key = current ? sessionKey(current) : null;
    if(key!==this.searchSession){this.inputOwners=new Map();this.searches.clear();this.searchSession=key}
    for (const [id, rule] of this.rules) if (rule.sessionKey !== key) this.rules.delete(id);
    for (const [id, watch] of this.watches) if (watch.sessionKey !== key) this.watches.delete(id);
    this.claims = this.claims.filter(claim => claim.sessionKey === key);
    for (const [id, baseline] of this.baselines) if (id !== key) {
      baseline.ram.copy(this.engine.gameRuntime.ram); baseline.iwram.copy(this.engine.gameRuntime.iwram);baseline.rom?.copy(this.rom);
      this.baselines.delete(id);
    }
  }
  descriptor(current) {
    const supported = current.systemId === 'gba';
    return {
      session: copy(current.session), gameId: current.gameId, systemId: current.systemId, simulated: true,
      spaces: supported ? [{ id: 'cpu', addressBits: 32, byteOrder: 'little', regions: [
        { id: 'ewram', start: 0x02000000, length: 0x40000, readable: true, writable: true },
        { id: 'iwram', start: 0x03000000, length: 0x8000, readable: true, writable: true },
        { id: 'io', start: 0x04000000, length: 0x400, readable: true, writable: false },
        { id: 'palette', start: 0x05000000, length: 0x400, readable: true, writable: false },
        { id: 'vram', start: 0x06000000, length: 0x18000, readable: true, writable: false },
        { id: 'oam', start: 0x07000000, length: 0x400, readable: true, writable: false },
        { id: 'rom', start: 0x08000000, length: 0x6000000, readable: true, writable: false },
      ] },{id:'rom',addressBits:25,byteOrder:'little',regions:[{id:'loaded',start:0,length:this.rom.length,readable:true,writable:true}]}] : [],
      saveRequirements:true,newGame:!['psp','gamecube','switch','3ds','rpgmaker'].includes(current.systemId),input:true,inputCodes:Array.from({length:41},(_,i)=>i),memoryRead: supported, memoryWrite: supported, atomicWrite: supported, frameRules: supported,
      memoryObserve:supported,maxWatches:supported?16:0,maxWatchBytes:supported?16384:0,maxWatchRanges:supported?32:0,
      memorySearch:supported,...Object.fromEntries(Object.entries(SEARCH_LIMITS).map(([k,v])=>[k,supported?v:0])),
      maxRanges: supported ? MAX_RANGES : 0, maxBytes: supported ? MAX_BYTES : 0, maxRules: supported ? MAX_RULES : 0, maxRuleBytes: supported ? MAX_BYTES : 0,
    };
  }
  range(current, value, write = false) {
    exactKeys(value, ['space', 'address', 'length']);
    need(['cpu','rom'].includes(value.space) && Number.isSafeInteger(value.address) && value.address >= 0 && Number.isSafeInteger(value.length) && value.length > 0 && value.length <= MAX_BYTES, 'invalid-memory-range');
    const space = this.descriptor(current).spaces.find(space => space.id === value.space);
    need(space, 'game-mod-unavailable');
    const region = space.regions.find(region => value.address >= region.start && value.address + value.length <= region.start + region.length);
    need(region && (write ? region.writable : region.readable), write ? 'memory-region-read-only' : 'memory-range-unavailable');
    return { space: value.space, address: value.address, length: value.length };
  }
  bytes(range) {
    const runtime = this.engine.gameRuntime;
    if(range.space==='rom')return this.rom.subarray(range.address,range.address+range.length);
    if (range.address >= 0x02000000 && range.address < 0x02040000) return runtime.ram.subarray(range.address - 0x02000000, range.address - 0x02000000 + range.length);
    if (range.address >= 0x03000000 && range.address < 0x03008000) return runtime.iwram.subarray(range.address - 0x03000000, range.address - 0x03000000 + range.length);
    if(range.space==='cpu'&&range.address>=0x08000000&&range.address<0x0e000000){const out=Buffer.alloc(range.length),offset=(range.address-0x08000000)%0x2000000;for(let i=0;i<out.length;i++)out[i]=this.rom[(offset+i)%0x2000000]??0;return out}
    const bytes = Buffer.alloc(range.length), code = Buffer.from('BPEE'), start = 0x080000ac + Math.max(0, Math.floor((range.address - 0x08000000) / 0x2000000)) * 0x2000000;
    for (let i = 0; i < code.length; i++) if (start + i >= range.address && start + i < range.address + range.length) bytes[start + i - range.address] = code[i];
    return bytes;
  }
  writes(current, values) {
    need(Array.isArray(values) && values.length > 0 && values.length <= MAX_RANGES, 'invalid-memory-writes');
    const result = values.map(value => {
      exactKeys(value, ['space', 'address', 'data', 'expected']);
      const data = decode(value.data), expected = decode(value.expected);
      need(data.length === expected.length, 'memory-byte-length-mismatch');
      const range = this.range(current, { space: value.space, address: value.address, length: data.length }, true);
      return { ...range, data, expected };
    });
    need(result.reduce((total, write) => total + write.length, 0) <= MAX_BYTES, 'memory-byte-limit');
    for (let i = 0; i < result.length; i++) for (let j = 0; j < i; j++) need(!overlaps(result[i], result[j]), 'overlapping-memory-writes');
    return result;
  }
  conditions(current, values) {
    need(Array.isArray(values) && values.length <= MAX_RANGES, 'invalid-rule-conditions');
    return values.map(value => {
      exactKeys(value, ['space', 'address', 'expected']);
      const expected = decode(value.expected);
      return { ...this.range(current, { space: value.space, address: value.address, length: expected.length }, false), expected };
    });
  }
  checkClaims(owner, key, writes, legacy = false) {
    for (const write of writes) {
      const conflict = this.claims.find(claim => claim.owner !== owner && claim.sessionKey === key && (!legacy || !claim.legacy) && overlaps(claim, write)) ?? [...this.rules.values()].find(rule => rule.owner !== owner && rule.sessionKey === key && rule.writes.some(other => overlaps(other, write)));
      need(!conflict, 'modification-conflict: ' + (conflict?.owner ?? ''));
    }
  }
  reserve(owner, key, writes, legacy = false) {
    this.checkClaims(owner, key, writes, legacy);
    const merged = [];
    const additions = writes.filter(write => write.length > 0).map(write => ({ owner, sessionKey: key, legacy, space: write.space, address: write.address, length: write.length }));
    for (const claim of this.claims.concat(additions).sort((a, b) => a.owner.localeCompare(b.owner) || a.space.localeCompare(b.space) || Number(a.legacy) - Number(b.legacy) || a.address - b.address)) {
      const previous = merged.at(-1);
      if (previous && previous.owner === claim.owner && previous.sessionKey === claim.sessionKey && previous.space === claim.space && previous.legacy === claim.legacy && claim.address <= previous.address + previous.length) {
        previous.length = Math.max(previous.address + previous.length, claim.address + claim.length) - previous.address;
      } else merged.push({ ...claim });
    }
    need(merged.length <= 1024, 'modification-range-limit');
    return merged;
  }
  /** The old online API retains its unload semantics; only cross-API ownership is new. */
  legacyPatch(owner, ref, request, execute) {
    this.engine.gameRuntime.check(ref);
    this.prune();
    const key = sessionKey(ref);
    // Keep the legacy decoder and range validation in GameRuntimeFixtures.call.
    const writes = request.writes.map(write => ({ space: 'cpu', address: Number(write.address), length: Buffer.from(write.data, 'base64').length }));
    const claims = this.reserve(owner, key, writes, true);
    const result = execute();
    if (result === true) this.claims = claims;
    return result;
  }
  remember(key) {
    if (!this.baselines.has(key)) this.baselines.set(key, { ram: Buffer.from(this.engine.gameRuntime.ram), iwram: Buffer.from(this.engine.gameRuntime.iwram),rom:Buffer.from(this.rom) });
  }
  apply(owner, key, writes) {
    const conflictIndex = writes.findIndex(write => !this.bytes(write).equals(write.expected));
    if (conflictIndex >= 0) return { applied: false, conflictIndex };
    this.remember(key);
    for (const write of writes) {
      write.data.copy(this.bytes(write));
    }
    return { applied: true };
  }
  ruleId(id) { need(typeof id === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(id), 'invalid-rule-id'); return id; }
  call(pkg, method, args) {
    need(gameModCapability(method), 'unknown-game-mod-operation');
    need(this.engine.runtimes.has(pkg.id), 'module-revoked');
    return this.access(this.engine.owner(pkg),method,args);
  }
  /** Developer tools reach this only through the authenticated localhost RPC, never through module JS. */
  access(owner,method,args) {
    need(gameModCapability(method),'unknown-game-mod-operation');
    if(method==='gameMod.configureSave'){need(Array.isArray(args)&&args.length===1,'invalid-arguments');return this.engine.moduleSavePolicy.configure(owner,args[0])}
    need(Array.isArray(args) && args.length === (method === 'gameMod.capabilities' || method === 'gameMod.listRules' ? 1 : 2), 'invalid-arguments');
    const current = this.check(args[0]), key = sessionKey(current.session), value = args[1];
    if(method==='gameMod.input'){
      exactKeys(args[1],['buttons']);const buttons=args[1].buttons;need(Array.isArray(buttons)&&buttons.length>0&&buttons.length<=41&&new Set(buttons.map(b=>b.code)).size===buttons.length,'invalid-module-input');buttons.forEach(b=>{exactKeys(b,['code','pressed']);need(Number.isInteger(b.code)&&b.code>=0&&b.code<=40&&typeof b.pressed==='boolean','invalid-module-input')});this.inputOwners??=new Map();need(this.inputOwners.has(owner)||this.inputOwners.size<32,'module-input-owner-limit');const held=new Set(this.inputOwners.get(owner)??[]);for(const b of buttons)if(b.pressed)held.add(b.code);else held.delete(b.code);if(held.size)this.inputOwners.set(owner,held);else this.inputOwners.delete(owner);return {pressedCodes:[...held].sort((a,b)=>a-b)};
    }
    if (method === 'gameMod.capabilities') return this.descriptor(current);
    if (method === 'gameMod.listRules' && current.systemId !== 'gba') return [];
    need(current.systemId === 'gba', 'game-mod-unavailable');
    if(method.startsWith('gameMod.search'))return this.searches.call(owner,args[0],method,value);
    if(method==='gameMod.readValues') {
      exactKeys(value,['values']);need(Array.isArray(value.values)&&value.values.length>0&&value.values.length<=MAX_RANGES,'memory-batch-limit');
      const specs=value.values.map(v=>{exactKeys(v,['space','address','type'],['endian']);return {...this.range(current,{space:v.space,address:v.address,length:numberSize(v.type)}),type:v.type,endian:v.endian??'little'}});
      return {values:specs.map(v=>({space:v.space,address:v.address,type:v.type,endian:v.endian,value:decodeNumber(this.bytes(v),v.type,v.endian),data:this.bytes(v).toString('base64')}))};
    }
    if(method==='gameMod.writeValues') {
      exactKeys(value,['writes']);need(Array.isArray(value.writes)&&value.writes.length>0&&value.writes.length<=MAX_RANGES,'memory-batch-limit');
      const writes=value.writes.map(v=>{exactKeys(v,['space','address','type','value','expected'],['endian']);const endian=v.endian??'little';return {space:v.space,address:v.address,data:encodeNumber(v.value,v.type,endian).toString('base64'),expected:encodeNumber(v.expected,v.type,endian).toString('base64')}});
      return this.access(owner,'gameMod.write',[args[0],{writes}]);
    }
    if(method==='gameMod.observe') {
      exactKeys(value,['id','ranges'],['everyFrames']);const id=this.ruleId(value.id),watchKey=owner+':'+id;
      need(Array.isArray(value.ranges)&&value.ranges.length>0&&value.ranges.length<=32,'watch-range-limit');
      const ranges=value.ranges.map(r=>this.range(current,r)),everyFrames=value.everyFrames??1;
      need(Number.isInteger(everyFrames)&&everyFrames>=1&&everyFrames<=600,'watch-sampling-invalid');
      const retained=[...this.watches.entries()].filter(([k])=>k!==watchKey).map(([,w])=>w);
      need(retained.length<16,'watch-count-limit');need(retained.reduce((n,w)=>n+w.ranges.length,0)+ranges.length<=32,'watch-range-limit');
      need(retained.reduce((n,w)=>n+w.ranges.reduce((m,r)=>m+r.length,0),0)+ranges.reduce((n,r)=>n+r.length,0)<=16384,'watch-byte-limit');
      this.watches.set(watchKey,{id,owner,sessionKey:key,session:copy(current.session),ranges,everyFrames,baseline:ranges.map(r=>Buffer.from(this.bytes(r))),sequence:0,pending:null});return {id};
    }
    if(method==='gameMod.unobserve')return this.watches.delete(owner+':'+this.ruleId(value));
    if (method === 'gameMod.read') {
      exactKeys(value, ['ranges']);
      need(Array.isArray(value.ranges) && value.ranges.length > 0 && value.ranges.length <= MAX_RANGES, 'invalid-memory-ranges');
      const ranges = value.ranges.map(range => this.range(current, range));
      need(ranges.reduce((total, range) => total + range.length, 0) <= MAX_BYTES, 'memory-byte-limit');
      return { ranges: ranges.map(range => ({ space: range.space, address: range.address, data: this.bytes(range).toString('base64') })) };
    }
    if (method === 'gameMod.write') {
      exactKeys(value, ['writes']);
      const writes = this.writes(current, value.writes);
      const claims = this.reserve(owner, key, writes);
      const result = this.apply(owner, key, writes);
      if (result.applied) this.claims = claims;
      return result;
    }
    if (method === 'gameMod.installRule') {
      exactKeys(value, ['id', 'writes'], ['conditions']);
      const id = this.ruleId(value.id), ruleKey = owner + ':' + id, writes = this.writes(current, value.writes), conditions = this.conditions(current, value.conditions ?? []);
      need(writes.length + conditions.length <= MAX_RANGES, 'rule-range-limit');
      const claims = this.reserve(owner, key, writes);
      const existing = [...this.rules.entries()].filter(([otherKey, rule]) => otherKey !== ruleKey && rule.sessionKey === key);
      need(existing.length < MAX_RULES, 'frame-rule-limit');
      const size = rows => rows.reduce((total, rule) => total + rule.writes.reduce((bytes, write) => bytes + write.length, 0) + rule.conditions.reduce((bytes, condition) => bytes + condition.length, 0), 0);
      need(size(existing.map(([, rule]) => rule).concat({ writes, conditions })) <= MAX_BYTES, 'frame-rule-byte-limit');
      this.remember(key);
      this.rules.set(ruleKey, { id, owner, sessionKey: key, session: copy(current.session), writes, conditions });
      this.claims = claims;
      return { id };
    }
    if (method === 'gameMod.removeRule') return this.rules.delete(owner + ':' + this.ruleId(value));
    return [...this.rules.values()].filter(rule => rule.owner === owner && rule.sessionKey === key).map(rule => ({
      id: rule.id,
      conditions: rule.conditions.map(condition => ({ space: condition.space, address: condition.address, expected: condition.expected.toString('base64') })),
      writes: rule.writes.map(write => ({ space: write.space, address: write.address, expected: write.expected.toString('base64'), data: write.data.toString('base64') })),
    }));
  }
  tick() {
    this.prune();
    if (this.engine.player.current?.paused) return;
    if(!this.engine.player.current)return;
    this.frame++;
    for (const rule of [...this.rules.values()]) {
      if (!this.engine.runtimes.has(rule.owner.split('@')[0])) continue;
      if (rule.conditions.every(condition => this.bytes(condition).equals(condition.expected))) this.apply(rule.owner, rule.sessionKey, rule.writes);
    }
    for(const watch of this.watches.values()) {
      if(this.frame%watch.everyFrames)continue;
      const next=watch.ranges.map(r=>Buffer.from(this.bytes(r)));
      if(next.every((bytes,i)=>bytes.equals(watch.baseline[i])))continue;
      watch.sequence++;
      watch.pending={type:'game-memory-changed',session:copy(watch.session),watchId:watch.id,sequence:watch.sequence,frame:this.frame,changes:(watch.pending?.changes??0)+1,ranges:watch.ranges.map((r,i)=>({space:r.space,address:r.address,before:watch.pending?.ranges[i].before??watch.baseline[i].toString('base64'),data:next[i].toString('base64')}))};
      watch.baseline=next;
    }
  }
  takeEvents(owner) {this.prune();return [...this.watches.values()].filter(w=>w.owner===owner&&w.pending).map(w=>{const event=w.pending;w.pending=null;return event})}
  dispatchEvents() {
    for(const [id,pkg]of this.engine.packages)if(this.engine.runtimes.has(id)&&pkg.manifest.capabilities.includes('runtime.events')&&pkg.manifest.capabilities.includes('emulation.memory.read')) {
      const owner=this.engine.owner(pkg),now=Date.now();if(now-(this.eventTimes.get(owner)??0)<100)continue;this.eventTimes.set(owner,now);
      try {for(const event of this.takeEvents(this.engine.owner(pkg))) {
        const result=this.engine.call(id,'onEvent',event),open=this.engine.panel;
        if(open?.moduleId===id&&['panel','page'].includes(result?.kind)){this.engine.validatePanel(result,id);open.model=result}
      }}catch(e){this.engine.stop(id,e.message)}
    }
  }
  release(owner) {
    this.engine.moduleSavePolicy?.release(owner);
    this.inputOwners?.delete(owner);this.searches.release(owner);
    this.eventTimes.delete(owner);
    this.prune();
    const current = this.engine.player.current, key = current ? sessionKey(current.session) : null;
    const touched = key && (this.claims.some(claim => claim.owner === owner && claim.sessionKey === key && !claim.legacy) || [...this.rules.values()].some(rule => rule.owner === owner && rule.sessionKey === key));
    if (touched) {
      this.engine.player.close();
      const baseline = this.baselines.get(key);
      if (baseline) { baseline.ram.copy(this.engine.gameRuntime.ram); baseline.iwram.copy(this.engine.gameRuntime.iwram);baseline.rom?.copy(this.rom); }
      this.rules.clear(); this.watches.clear();this.searches.clear();this.claims = []; this.baselines.clear();
    } else {
      for (const [id, rule] of this.rules) if (rule.owner === owner) this.rules.delete(id);
      for (const [id, watch] of this.watches) if (watch.owner === owner) this.watches.delete(id);
      this.claims = this.claims.filter(claim => claim.owner !== owner);
    }
    return Boolean(touched);
  }
}
