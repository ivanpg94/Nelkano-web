// Installation trust only. This does not grant a reports port to SDK modules or Studio.
export const reportAuthor='d678dfc43349f1cf71d3bd98019c94655768685ff2b6163e5163d1b3a69df4a1';
export function validatePrivatePackage(manifest,author){
 if(manifest.capabilities.includes('error-reports.send')&&(manifest.id!=='nelkano.error-reports'||author!==reportAuthor))throw Error('private-module-required');
}
