import {readFile,writeFile,mkdir,cp,lstat} from 'node:fs/promises';
import {resolve,dirname,join,posix} from 'node:path';
import ts from 'typescript';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
const sdkRequire=createRequire(import.meta.url);
let sdkTypes;try{sdkTypes=join(dirname(sdkRequire.resolve('@nelkano/sdk/package.json')),'src/index.ts');}catch{const local=join(dirname(fileURLToPath(import.meta.url)),'../typescript/src/index.ts');if(existsSync(local))sdkTypes=local;}
import {validateManifest} from './package.mjs';
import {safePath} from './zip.mjs';
export async function compile(target,emit=true){
 const source=resolve(target),manifest=JSON.parse(await readFile(join(source,'manifest.json'),'utf8'));
 validateManifest({...manifest,entry:manifest.entry.replace(/\.ts$/,'.js'),files:manifest.files.map(f=>f.replace(/\.ts$/,'.js'))});
 for(const file of manifest.files){safePath(file);let current=source;for(const part of file.split('/')){current=join(current,part);if((await lstat(current)).isSymbolicLink())throw new Error('Source symlink rejected');}}
  if(emit){for(const file of manifest.files.map(f=>f.replace(/\.ts$/,'.js')).concat('manifest.json')){let current=source;for(const part of ['dist',...file.split('/')]){current=join(current,part);try{if((await lstat(current)).isSymbolicLink())throw Error('Output symlink rejected');}catch(e){if(e.code==='ENOENT')break;throw e;}}}}
 const sources=manifest.files.filter(f=>/\.(ts|js)$/.test(f));
 for(const file of sources){const code=await readFile(join(source,file),'utf8');const ast=ts.createSourceFile(file,code,ts.ScriptTarget.ES2022,true);let failure;
  function visit(n){if(ts.isImportDeclaration(n)||ts.isExportDeclaration(n)){const spec=n.moduleSpecifier?.text;if(spec&&!n.isTypeOnly&&!n.importClause?.isTypeOnly){if(!spec.startsWith('./')||!spec.endsWith('.js'))failure='Only packaged relative .js imports are executable: '+spec;else{const candidate=posix.normalize(posix.join(posix.dirname(file),spec));if(!manifest.files.includes(candidate)&&!manifest.files.includes(candidate.replace(/\.js$/,'.ts')))failure='Import is not declared in manifest: '+spec;}}}
   if(ts.isCallExpression(n)&&n.expression.kind===ts.SyntaxKind.ImportKeyword)failure='Dynamic imports are not supported';ts.forEachChild(n,visit);}visit(ast);if(failure)throw new Error(failure);
 }
 const options={target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022,moduleResolution:ts.ModuleResolutionKind.Bundler,strict:true,allowJs:true,checkJs:false,noEmitOnError:true,outDir:join(source,'dist'),rootDir:source,skipLibCheck:true,...(sdkTypes?{paths:{"@nelkano/sdk":[sdkTypes]}}:{})};
 const compilerHost=ts.createCompilerHost(options);const loadSource=compilerHost.getSourceFile.bind(compilerHost);compilerHost.getSourceFile=(file,...args)=>{const ast=loadSource(file,...args);if(ast&&sdkTypes&&resolve(file).toLowerCase()===resolve(sdkTypes).toLowerCase())ast.isDeclarationFile=true;return ast;};
 const program=ts.createProgram(sources.map(f=>join(source,f)),options,compilerHost);const diagnostics=ts.getPreEmitDiagnostics(program);if(diagnostics.length)throw new Error(ts.formatDiagnosticsWithColorAndContext(diagnostics,{getCurrentDirectory:()=>source,getCanonicalFileName:x=>x,getNewLine:()=> '\n'}));if(!emit)return 'TypeScript and package imports valid';program.emit();
 for(const file of manifest.files.filter(f=>!sources.includes(f))){await mkdir(dirname(join(source,'dist',file)),{recursive:true});await cp(join(source,file),join(source,'dist',file));}
 manifest.files=manifest.files.map(f=>f.replace(/\.ts$/,'.js'));manifest.entry=manifest.entry.replace(/\.ts$/,'.js');await writeFile(join(source,'dist','manifest.json'),JSON.stringify(manifest,null,2));return join(source,'dist');
}

