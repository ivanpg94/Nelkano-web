const need=(v,m)=>{if(!v)throw Error(m)};
/** Studio models requirements in save metadata; no real core or battery runs here. */
export class ModuleSavePolicy {
 constructor(engine){this.engine=engine;this.available=new Set();this.policies=new Map();this.active=null}
 start(owner){this.available.add(owner)}
 release(owner){this.available.delete(owner);for(const[key,p]of this.policies)if(p.owner===owner)this.policies.delete(key);if(this.active?.owners.has(owner)&&this.engine.player.current){this.engine.player.current.paused=true;this.engine.message='Esta partida necesita el módulo '+owner.split('@')[0]+'. Puedes guardar antes de salir.'}}
 configure(owner,spec){need(this.available.has(owner),'module-revoked');need(spec&&typeof spec==='object'&&!Array.isArray(spec)&&typeof spec.gameId==='string'&&spec.gameId.length>0&&spec.gameId.length<=256&&Object.keys(spec).every(k=>['gameId','newGame'].includes(k))&&(!Object.hasOwn(spec,'newGame')||typeof spec.newGame==='boolean'),'invalid-save-policy');
  if(spec.newGame&&this.active?.gameId===spec.gameId)need(this.active.fresh.has(owner),'fresh-module-game-required');
  const key=owner+':'+spec.gameId;need(this.policies.size<256||this.policies.has(key),'save-policy-limit');this.policies.set(key,{owner,gameId:spec.gameId,newGame:spec.newGame??false});if(this.active?.gameId===spec.gameId)this.active.owners.add(owner);return true}
 declared(gameId){return [...this.policies.values()].filter(p=>p.gameId===gameId)}
 validate(gameId,row){const owners=row?.requiredModuleOwners??[],fresh=row?.freshModuleOwners??[];need(Array.isArray(owners)&&owners.length<=32&&owners.every(o=>typeof o==='string'&&o.includes('@')&&o.length<=512)&&Array.isArray(fresh)&&fresh.every(o=>owners.includes(o)),'invalid-module-save');need(owners.every(o=>this.available.has(o)),'missing-save-modules');need(this.declared(gameId).filter(p=>p.newGame).every(p=>fresh.includes(p.owner)),'fresh-module-game-required')}
 prepare(gameId,row){if(row)this.validate(gameId,row);const declared=this.declared(gameId);this.active={gameId,owners:new Set([...declared.map(p=>p.owner),...(row?.requiredModuleOwners??[])]),fresh:new Set(row?.freshModuleOwners??declared.filter(p=>p.newGame).map(p=>p.owner))}}
 loaded(gameId,row){this.validate(gameId,row);this.prepare(gameId,row)}
 ensureAvailable(){need(!this.active||[...this.active.owners].every(o=>this.available.has(o)),'missing-save-modules')}
 saved(row){if(this.active?.owners.size){row.requiredModuleOwners=[...this.active.owners].sort();row.freshModuleOwners=[...this.active.fresh].sort()}return row}
 end(){this.active=null}
}
