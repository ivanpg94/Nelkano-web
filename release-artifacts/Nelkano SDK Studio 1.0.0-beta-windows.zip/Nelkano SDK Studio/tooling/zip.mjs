// Bounded ZIP subset for source-only draft packages: STORE or DEFLATE, no ZIP64,
// encryption, data descriptors, comments, symlinks or extra fields. Never extracts.
import { deflateRawSync, inflateRawSync } from "node:zlib";
export const MAX_FILE = 8 * 1024 * 1024;
export const MAX_ARCHIVE = 32 * 1024 * 1024;
const fail = () => { throw new Error("invalid-or-unsupported-zip"); };
export function safePath(name) {
  if (typeof name !== "string" || !/^[a-zA-Z0-9_./-]+$/.test(name) ||
      name.split("/").some(part => !part || part === "." || part === "..")) throw new Error("unsafe-package-path");
  return name;
}
export function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
export function encodeZip(files) {
  const local = [], central = [], seen = new Set(); let offset = 0, total = 0;
  for (const [path, bytes] of files) {
    safePath(path); const lower = path.toLowerCase();
    if (seen.has(lower)) throw new Error("duplicate-package-path"); seen.add(lower);
    const data = Buffer.from(bytes), name = Buffer.from(path, "utf8"), compressed = deflateRawSync(data);
    total += data.length;
    if (data.length > MAX_FILE || total > MAX_ARCHIVE || seen.size > 128) throw new Error("package-too-large");
    const crc = crc32(data), l = Buffer.alloc(30), c = Buffer.alloc(46);
    l.writeUInt32LE(0x04034b50); l.writeUInt16LE(20, 4); l.writeUInt16LE(8, 8); l.writeUInt16LE(33, 12);
    l.writeUInt32LE(crc, 14); l.writeUInt32LE(compressed.length, 18); l.writeUInt32LE(data.length, 22); l.writeUInt16LE(name.length, 26);
    c.writeUInt32LE(0x02014b50); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(8, 10); c.writeUInt16LE(33, 14);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(compressed.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(offset, 42);
    local.push(l, name, compressed); central.push(c, name); offset += l.length + name.length + compressed.length;
  }
  const directory = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50); end.writeUInt16LE(seen.size, 8); end.writeUInt16LE(seen.size, 10);
  end.writeUInt32LE(directory.length, 12); end.writeUInt32LE(offset, 16);
  const result = Buffer.concat([...local, directory, end]);
  if (result.length > MAX_ARCHIVE) throw new Error("package-too-large");
  return result;
}
export function decodeZip(raw) {
  const b = Buffer.from(raw), files = new Map(), seen = new Set();
  if (b.length < 22 || b.length > MAX_ARCHIVE) fail();
  const e = b.length - 22;
  if (b.readUInt32LE(e) !== 0x06054b50 || b.readUInt16LE(e + 4) || b.readUInt16LE(e + 6) || b.readUInt16LE(e + 20)) fail();
  const count = b.readUInt16LE(e + 10), size = b.readUInt32LE(e + 12), start = b.readUInt32LE(e + 16);
  if (!count || count > 128 || b.readUInt16LE(e + 8) !== count || start + size !== e) fail();
  let p = start, expectedLocal = 0, total = 0;
  for (let i = 0; i < count; i++) {
    if (p + 46 > e || b.readUInt32LE(p) !== 0x02014b50) fail();
    const flags = b.readUInt16LE(p + 8), method = b.readUInt16LE(p + 10), crc = b.readUInt32LE(p + 16);
    const compressedSize = b.readUInt32LE(p + 20), originalSize = b.readUInt32LE(p + 24);
    const nameSize = b.readUInt16LE(p + 28), extra = b.readUInt16LE(p + 30), comment = b.readUInt16LE(p + 32), l = b.readUInt32LE(p + 42);
    const attrs = b.readUInt32LE(p + 38);
    if (flags || ![0, 8].includes(method) || extra || comment || b.readUInt16LE(p + 34) ||
        (attrs >>> 16 & 0xf000) === 0xa000 || p + 46 + nameSize > e || originalSize > MAX_FILE) fail();
    total += originalSize; if (total > MAX_ARCHIVE) fail();
    const name = safePath(b.subarray(p + 46, p + 46 + nameSize).toString("utf8"));
    if (seen.has(name.toLowerCase())) throw new Error("duplicate-package-path"); seen.add(name.toLowerCase());
    if (l !== expectedLocal || l + 30 > start || b.readUInt32LE(l) !== 0x04034b50 ||
        b.readUInt16LE(l + 6) !== flags || b.readUInt16LE(l + 8) !== method || b.readUInt32LE(l + 14) !== crc ||
        b.readUInt32LE(l + 18) !== compressedSize || b.readUInt32LE(l + 22) !== originalSize ||
        b.readUInt16LE(l + 26) !== nameSize || b.readUInt16LE(l + 28)) fail();
    const dataStart = l + 30 + nameSize, dataEnd = dataStart + compressedSize;
    if (dataEnd > start || b.subarray(l + 30, dataStart).toString("utf8") !== name) fail();
    const packed = b.subarray(dataStart, dataEnd);
    const data = method === 0 ? Buffer.from(packed) : inflateRawSync(packed, { maxOutputLength: MAX_FILE });
    if (data.length !== originalSize || crc32(data) !== crc) fail();
    files.set(name, data); expectedLocal = dataEnd; p += 46 + nameSize;
  }
  if (p !== e || expectedLocal !== start) fail();
  return files;
}
