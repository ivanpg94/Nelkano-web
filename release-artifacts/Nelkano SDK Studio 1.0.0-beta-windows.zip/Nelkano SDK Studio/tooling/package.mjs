import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync, sign, verify } from "node:crypto";
import { readFile, writeFile, lstat, realpath } from "node:fs/promises";
import { resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { encodeZip, decodeZip, safePath, MAX_FILE, MAX_ARCHIVE } from "./zip.mjs";
import {validateHooks,validateSkins} from "./hooks.mjs";
import {networkOrigins} from './extension-connections.mjs';
import {validatePrivatePackage} from './private-package-access.mjs';
export const SDK_VERSION = "0.2.0";
const knownCapabilities = new Set(["assistant.voice","storage.files","resources.documents","storage.secrets","runtime.tasks","network.external","emulation.input","presentation.extend","storage.entities","modules.services","modules.events","emulation.game-mod","emulation.memory.read","emulation.memory.write","emulation.resources","emulation.handoff","presentation.overlay","network.multiplayer","runtime.events","storage.private.cas", "library.read","library.delete","library.launch","library.cover", "saves.read","saves.autosave","emulation.read","emulation.control","presentation.player","saves.write","saves.load","modules.hooks","presentation.appearance","environment.display","presentation.control-layouts","account.session","network.account","resources.image","input.gamepad","media.second-screen","media.streaming","resources.patch","appearance.locale"]);
const hash = data => createHash("sha256").update(data).digest("hex");
const fail = message => { throw new Error(message); };
export function validateManifest(m) {
  if (!m || typeof m.id !== "string" || m.id.length > 128 || typeof m.version !== "string" || m.version.length > 32 || m.formatVersion !== 1 || !/^[a-z][a-z0-9]*(\.[a-z][a-z0-9-]*)+$/.test(m.id) ||
      typeof m.name !== "string" || !m.name.trim() || m.name.trim().length > 256 || !/^\d+\.\d+\.\d+$/.test(m.version) ||
      !["0.1.0",SDK_VERSION].includes(m.sdkVersion) || typeof m.bundledByDefault !== "boolean") fail("incompatible-manifest");
  if (!Array.isArray(m.platforms) || !m.platforms.length || m.platforms.length > 2 || new Set(m.platforms).size !== m.platforms.length || m.platforms.some(p => !["android", "jvm-desktop"].includes(p))) fail("invalid-platforms");
  if (!Array.isArray(m.capabilities) || new Set(m.capabilities).size !== m.capabilities.length || m.capabilities.some(c => !knownCapabilities.has(c)&&!(c==='error-reports.send'&&m.id==='nelkano.error-reports'))) fail("unknown-capability");
  validateHooks(m);validateSkins(m);networkOrigins(m);
  if (!Array.isArray(m.files) || !m.files.length || m.files.length > 120 || new Set(m.files.map(p => safePath(p).toLowerCase())).size !== m.files.length) fail("invalid-package-files");
  if (m.files.some(p => ["manifest.json", "signature.json"].includes(p.toLowerCase()) || !/\.(js|json|svg|png|txt|ttf)$/.test(p))) fail("unsupported-package-file");
  safePath(m.entry); if (!m.entry.endsWith(".js") || !m.files.includes(m.entry)) fail("missing-entry");
  return m;
}
async function sourceFile(root, name) {
  const path = resolve(root, safePath(name));
  if (!path.startsWith(root + sep)) fail("unsafe-package-path");
  // Reject symbolic links at every level, even when pointing back into the root.
  let current = root;
  for (const part of name.split("/")) {
    current = resolve(current, part); if ((await lstat(current)).isSymbolicLink()) fail("package-symlink");
  }
  const stat = await lstat(path);
  if (!stat.isFile()) fail("package-file-not-regular");
  if (stat.size > MAX_FILE) fail("package-too-large");
  return readFile(path);
}
export async function buildPackage(source, privatePem) {
  const root = await realpath(resolve(source));
  const manifestBytes = await sourceFile(root, "manifest.json"), manifest = validateManifest(JSON.parse(manifestBytes));
  const payload = new Map([["manifest.json", manifestBytes]]);
  for (const name of [...manifest.files].sort()) payload.set(name, await sourceFile(root, name));
  const key = createPrivateKey(privatePem); if (key.asymmetricKeyType !== "ed25519") fail("ed25519-key-required");
  const publicDer = createPublicKey(key).export({ type: "spki", format: "der" }); validatePrivatePackage(manifest,hash(publicDer));
  const files = [...payload].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([path, bytes]) => ({ path, size: bytes.length, sha256: hash(bytes) }));
  const signature = { algorithm: "Ed25519", publicKey: publicDer.toString("base64"),
    files, signature: sign(null, Buffer.from(JSON.stringify(files)), key).toString("base64") };
  payload.set("signature.json", Buffer.from(JSON.stringify(signature) + "\n"));
  return encodeZip(payload);
}
export function validatePackage(bytes, expectedAuthorFingerprint) {
  const payload = decodeZip(bytes);
  if (!payload.has("manifest.json") || !payload.has("signature.json")) fail("missing-package-metadata");
  const manifest = validateManifest(JSON.parse(payload.get("manifest.json"))), signature = JSON.parse(payload.get("signature.json"));
  if (signature.algorithm !== "Ed25519" || typeof signature.publicKey !== "string" || typeof signature.signature !== "string" || !Array.isArray(signature.files)) fail("invalid-signature-metadata");
  const declared = new Set(["manifest.json", ...manifest.files]);
  if (payload.size !== declared.size + 1 || signature.files.length !== declared.size) fail("package-file-set-mismatch");
  const ordered = [...declared].sort();
  for (let i = 0; i < ordered.length; i++) {
    const file = signature.files[i], data = payload.get(ordered[i]);
    if (!data || file.path !== ordered[i] || file.size !== data.length || file.sha256 !== hash(data)) fail("package-content-mismatch");
  }
  const publicDer = Buffer.from(signature.publicKey, "base64");
  const publicKey = createPublicKey({ key: publicDer, type: "spki", format: "der" });
  if (publicKey.asymmetricKeyType !== "ed25519" || !verify(null, Buffer.from(JSON.stringify(signature.files)), publicKey, Buffer.from(signature.signature, "base64"))) fail("signature-verification-failed");
  const authorFingerprint = hash(publicDer); validatePrivatePackage(manifest,authorFingerprint);
  if (expectedAuthorFingerprint && authorFingerprint !== expectedAuthorFingerprint) fail("unexpected-author");
  return { id: manifest.id, version: manifest.version, sdkVersion: manifest.sdkVersion, authorFingerprint,
    authorVerified: false, capabilities: manifest.capabilities, files: ordered, archiveSha256: hash(bytes) };
}
export async function generateKeys(privatePath, publicPath) {
  if (resolve(privatePath) === resolve(publicPath)) fail("key-paths-must-differ");
  const keys = generateKeyPairSync("ed25519");
  await writeFile(privatePath, keys.privateKey.export({ type: "pkcs8", format: "pem" }), { flag: "wx", mode: 0o600 });
  await writeFile(publicPath, keys.publicKey.export({ type: "spki", format: "pem" }), { flag: "wx" });
}
async function cli() {
  const [command, ...args] = process.argv.slice(2);
  if (command === "keygen" && args.length === 2) { await generateKeys(...args); console.log("Author keys created; keep the private key outside source control."); return; }
  if (command === "pack" && args.length === 3) {
    const [source, keyPath, output] = args;
    const bytes = await buildPackage(source, await readFile(keyPath));
    const result = validatePackage(bytes); await writeFile(output, bytes, { flag: "wx" }); console.log(JSON.stringify(result, null, 2)); return;
  }
  if (command === "verify" && [1, 2].includes(args.length)) { if ((await lstat(args[0])).size > MAX_ARCHIVE) fail("package-too-large"); console.log(JSON.stringify(validatePackage(await readFile(args[0]), args[1]), null, 2)); return; }
  fail("Usage: node nelkmod.mjs keygen private.pem public.pem | pack module-dir private.pem output.nelkmod | verify package.nelkmod [author-fingerprint]");
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  cli().catch(error => { console.error(error.message); process.exitCode = 1; });
}
