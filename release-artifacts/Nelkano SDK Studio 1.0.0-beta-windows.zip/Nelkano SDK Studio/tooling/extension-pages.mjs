import {discoveryPage} from './extension-discovery.mjs';
const need=(v,m)=>{if(!v)throw Error(m)},copy=v=>JSON.parse(JSON.stringify(v));
const keys=(v,r,o=[])=>need(v&&typeof v==='object'&&!Array.isArray(v)&&r.every(k=>Object.hasOwn(v,k))&&Object.keys(v).every(k=>r.includes(k)||o.includes(k)),'invalid-extension-object');
const name=v=>need(typeof v==='string'&&/^[a-z][a-z0-9.-]{0,127}$/.test(v),'invalid-extension-name');
const target=v=>need(typeof v==='string'&&v.length<=256&&/^[a-zA-Z0-9._:/-]+$/.test(v),'invalid-ui-target');
export function validateNode(root){let count=0;const ids=new Set();const visit=(n,depth)=>{
 need(depth<=16&&++count<=512,'ui-node-limit');keys(n,['id','kind'],['text','label','value','actionId','payload','children','options','resource','style','checked','enabled','placeholder','multiline']);name(n.id);need(!ids.has(n.id),'ui-node-duplicate');ids.add(n.id);need(['column','list','row','box','text','button','field','toggle','select','tabs','modal','image','spacer','divider','canvas','rect','circle','line'].includes(n.kind),'ui-node-kind');
 for(const k of ['text','label','placeholder'])if(Object.hasOwn(n,k))need(typeof n[k]==='string'&&n[k].length<=16384,'ui-text-limit');for(const k of ['enabled','checked','multiline'])if(Object.hasOwn(n,k))need(typeof n[k]==='boolean','invalid-ui-property');if(Object.hasOwn(n,'value'))need(['string','boolean'].includes(typeof n.value)||typeof n.value==='number'&&Number.isFinite(n.value),'invalid-ui-property');if(Object.hasOwn(n,'payload'))keys(n.payload,[],Object.keys(n.payload));if(Object.hasOwn(n,'actionId'))name(n.actionId);
 if(Object.hasOwn(n,'resource'))need(typeof n.resource==='string'&&n.resource.length<=256&&(/^file:[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(n.resource)||/^standard:[a-z0-9.-]+$/.test(n.resource)||/^[a-zA-Z0-9_./-]+\.png$/.test(n.resource)&&n.resource.split('/').every(p=>p&&!['.','..'].includes(p))),'invalid-ui-resource');
 if(Object.hasOwn(n,'style')){keys(n.style,[],['width','height','padding','spacing','x','y','radius','color','background']);for(const[k,v]of Object.entries(n.style))need(['color','background'].includes(k)?typeof v==='string'&&/^#[a-fA-F0-9]{6}([a-fA-F0-9]{2})?$/.test(v):typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=4096,'invalid-ui-style')}
 if(Object.hasOwn(n,'options')){need(Array.isArray(n.options)&&n.options.length<=256,'ui-options-limit');const seen=new Set();for(const o of n.options){keys(o,['id','label']);need(typeof o.id==='string'&&o.id.length>0&&o.id.length<=128&&!seen.has(o.id)&&typeof o.label==='string'&&o.label.length>0&&o.label.length<=256,'invalid-ui-option');seen.add(o.id)}}
 if(Object.hasOwn(n,'children')){need(Array.isArray(n.children),'invalid-ui-children');n.children.forEach(c=>visit(c,depth+1))}
 };visit(root,0)}
export class ExtensionPages {
 constructor(){this.entries=new Map();this.active=new Set();this.targets=new Map();this.sequence=0;this.opened=null}
 start(o){this.active.add(o)}
 release(o){this.active.delete(o);for(const[k,e]of this.entries)if(e.owner===o)this.entries.delete(k);if(this.opened?.startsWith(o+':'))this.opened=null}
 row(e){return {...copy(e.model),kind:e.kind,moduleId:e.owner.split('@')[0],author:e.owner.split('@')[1],revision:e.revision}}
 call(owner,m,args){need(this.active.has(owner),'module-revoked');
  if(['ui.page','ui.mount','ui.patch'].includes(m)){need(args.length===1,'invalid-ui-request');const model=copy(args[0]);name(model.id);const key=owner+':'+model.id,kind=m.split('.')[1];need(this.entries.size<256||this.entries.has(key),'ui-registration-limit');need([...this.entries.values()].filter(e=>e.owner===owner).length<32||this.entries.has(key),'ui-module-registration-limit');need(!this.entries.has(key)||this.entries.get(key).kind===kind,'ui-registration-kind');
   if(kind==='page'){keys(model,['id','title','content']);need(typeof model.title==='string'&&model.title.length>0&&model.title.length<=256,'ui-title-limit');validateNode(model.content)}
   if(kind==='mount'){keys(model,['id','target','content'],['order']);target(model.target);validateNode(model.content);if(Object.hasOwn(model,'order'))need(Number.isInteger(model.order)&&model.order>=-10000&&model.order<=10000,'invalid-ui-order')}
   if(kind==='patch'){keys(model,['id','target','changes']);target(model.target);keys(model.changes,[],['text','label','hidden','enabled','actionId']);need(Object.keys(model.changes).length>0,'invalid-ui-property');for(const k of ['text','label'])if(Object.hasOwn(model.changes,k))need(typeof model.changes[k]==='string'&&model.changes[k].length<=16384,'ui-text-limit');for(const k of ['hidden','enabled'])if(Object.hasOwn(model.changes,k))need(typeof model.changes[k]==='boolean','invalid-ui-property');if(Object.hasOwn(model.changes,'actionId'))name(model.changes.actionId);need(![...this.entries.values()].some(e=>e.kind==='patch'&&e.model.target===model.target&&e.owner!==owner),'ui-target-conflict')}
   need(Buffer.byteLength(JSON.stringify(model))<=96*1024,'ui-content-size');const e={owner,kind,model,revision:++this.sequence};this.entries.set(key,e);return this.row(e)
  }
  if(m==='ui.remove'){need(args.length===1,'invalid-ui-request');const key=owner+':'+args[0];if(this.opened===key)this.opened=null;return this.entries.delete(key)}
  if(m==='ui.open'){need(args.length===1,'invalid-ui-request');const key=owner+':'+args[0];need(this.entries.get(key)?.kind==='page','ui-page-unavailable');this.opened=key;return true}
  if(m==='ui.close'){need(args.length===0,'invalid-ui-request');if(!this.opened?.startsWith(owner+':'))return false;this.opened=null;return true}
  if(m==='ui.targets'){need(args.length<=1,'invalid-ui-request');return discoveryPage([...this.targets.values()],args[0])}throw Error('unknown-ui-operation');
 }
 page(){const e=this.entries.get(this.opened);return e?this.row(e):null}
 close(){this.opened=null}
 mounts(t){return [...this.entries.values()].filter(e=>e.kind==='mount'&&e.model.target===t).sort((a,b)=>(a.model.order??0)-(b.model.order??0)||(a.owner+a.model.id<b.owner+b.model.id?-1:1)).map(e=>this.row(e))}
 resolve(t,base){target(t);if(this.targets.size<2048||this.targets.has(t))this.targets.set(t,{target:t,base:copy(base)});const e=[...this.entries.values()].filter(e=>e.kind==='patch'&&e.model.target===t).at(-1);if(!e)return copy(base);const c=e.model.changes,r={...copy(base),...copy(c),extension:this.row(e)};if(Object.hasOwn(c,'text')&&!Object.hasOwn(c,'label'))r.label=c.text;if(Object.hasOwn(c,'label')&&!Object.hasOwn(c,'text'))r.text=c.label;return r}
 ownerFor(module,id,revision){return [...this.entries.values()].find(e=>e.owner.split('@')[0]===module&&e.model.id===id&&e.revision===revision)?.owner??null}
 authorized(module,id,revision,action){const e=[...this.entries.values()].find(e=>e.owner.split('@')[0]===module&&e.model.id===id&&e.revision===revision);if(!e)return false;if(e.kind==='patch')return e.model.changes.actionId===action;const contains=n=>n.actionId===action||(n.children??[]).some(contains);return contains(e.model.content)}
 state(){return {entries:[...this.entries.values()].map(e=>this.row(e)),page:this.page()}}
}
