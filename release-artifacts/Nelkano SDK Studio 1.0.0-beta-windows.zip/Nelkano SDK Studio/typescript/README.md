# SDK Nelkano 0.2.0

## APIs de la plataforma abierta

La base incorpora APIs programables para ampliar funciones, interfaz, datos y juegos. Los módulos anteriores mantienen sus contratos. Android, Windows y SDK Studio compilan con las mismas APIs; la memoria, ROM temporal y reglas reales se verifican en GBA. Las diferencias de capacidades se indican a continuación.

- **Intervenir en servicios:** `services.intercept({id,name,method,phase,order?})` registra una transformación antes o después; `onService` recibe `phase` y `hookId`. La respuesta debe respetar el esquema del método. `removeInterceptor(id)` retira la transformación. Hasta 32 por módulo y 128 totales. Un error después de la operación no deshace sus efectos.
- **Entidades locales:** permiso `storage.entities`. `entities.define({name,version,schema,indexes?,relations?})`, `get`, `query`, `transact` y `migrate`. Esquemas de objeto, relaciones entre tipos del mismo módulo, índices de igualdad, revisiones y lotes atómicos con `expectedRevision`. Consultas con filtros AND, orden, offset y limit; páginas acotadas a 96 KiB. Hasta 64 tipos, 10.000 registros por tipo, 32 KiB por registro, 16 MiB por identidad y 128 cambios por lote. Datos locales privados por módulo y autor; nunca se suben automáticamente. Android y escritorio usan SQLite con registros separados; Studio usa JSON local. Actualizaciones fallidas restauran el estado anterior. `storage.private.cas` conserva su formato anterior.
- **Páginas y componentes:** permiso `presentation.extend`. `ui.page`, `mount`, `patch`, `remove`, `open`, `close` y `targets`. Páginas con secciones, filas, texto, botones, campos, selectores, pestañas, modales, imágenes PNG y lienzo con figuras. `dispatch` recibe las acciones y valores del formulario. Montajes en `home/library/game/saves/settings/emulation.before`, `.after` y `.content`, además de puntos de cada componente publicado. Una modificación puede cambiar texto, visibilidad, disponibilidad o `actionId`; los conflictos entre módulos se rechazan. Hasta 32 registros por módulo, 256 totales, 512 nodos y profundidad 16. Se retiran al desactivar. Es un renderer de componentes compartido, no HTML arbitrario ni un editor visual.
- **Servidores propios:** permiso `network.external` y lista firmada `origins` del manifiesto, con orígenes HTTP/HTTPS exactos. `connections.request`, `socket`, `read`, `send` y `close` trabajan con identificadores privados. `requestOrigin` solicita confirmación nativa para un servidor nuevo; la elección persiste por autor. No heredan cookies ni credenciales Nelkano y no siguen redirecciones. Android ofrece HTTPS/WSS; Windows y Studio admiten también HTTP/WS. Hasta 12 trabajos (8 HTTP y 4 sockets), 64 KiB por cuerpo/mensaje y 32 mensajes recibidos pendientes por socket. `onEvent` recibe `connection-changed` y `connection-origin-reviewed`. Desactivar cancela las conexiones. Studio ejecuta estas conexiones de verdad: usa servidores y credenciales de prueba.
- **Tareas:** permiso `runtime.tasks`. `tasks.schedule({id,delayMs,intervalMs?,payload?})`, `read`, `update` y `cancel`. `onEvent` recibe `task-due` con id, revisión, número de ocurrencias y payload. Puede actualizar progreso, resultado y estado. Hasta 32 tareas por módulo, intervalos de 100 ms a 24 h y datos de 32 KiB. Los avisos se agrupan; no garantiza ejecución puntual. Funcionan mientras vive la aplicación y se cancelan al desactivar; no ejecutan trabajos con la app cerrada.
- **Entradas en el juego:** permisos `emulation.game-mod` y `emulation.input`. `gameMod.input(session,{buttons:[{code,pressed}]})` mantiene pulsaciones propias, combinadas con el usuario y otros módulos. Desactivar libera solo las propias. Consulta `gameMod.capabilities`; cada core interpreta únicamente sus botones compatibles. Studio simula el contrato.

- **Archivos privados:** `storage.files` habilita `files.list/read/begin/write/commit/abort/remove`. begin exige el nombre y expectedRevision; write añade tramos consecutivos de hasta 64 KiB; commit publica todo o devuelve un conflicto. Hasta 16 archivos, 1 MiB por archivo, 4 MiB por identidad y dos escritores simultáneos por módulo. Las etapas sin publicar se eliminan al desactivar. `files.import/export` requieren además `resources.documents` y abren el selector del sistema en Android/escritorio, sin exponer rutas ni URI. Los archivos quedan incluidos en la recuperación de actualizaciones. Studio guarda archivos locales, pero anuncia importExport:false para el selector. Una imagen PNG privada puede aparecer en ui.page/mount con resource: `file:imagen.png`; exige storage.files, pertenencia al registro activo y dimensiones máximas de 1024×1024. No permite leer imágenes privadas de otros módulos.
- **Credenciales propias:** `storage.secrets` habilita `secrets.get/put/remove/capabilities`. Hasta 64 claves, 4 KiB por valor y 64 KiB por identidad. Android cifra con una clave Keystore separada y excluye el archivo del backup; Windows usa DPAPI; Linux usa Secret Service si está disponible y, si falla, conserva cambios únicamente en memoria. Studio mantiene secretos de prueba solo en memoria. Consulta persistent tras guardar para conocer la persistencia efectiva. El journal contiene copias cifradas o referencias opacas, nunca valores en texto plano. No incluye credenciales de la cuenta Nelkano.
- **Guardados que requieren módulos:** `gameMod.configureSave({gameId,newGame?})`, con emulation.game-mod, declara este módulo y autor como necesarios para los guardados de un juego. Regístralo antes de abrir el juego; newGame:true exige un inicio nuevo y rechaza guardados anteriores sin esa marca. Mantiene slots manuales, autoguardado y batería habituales; no crea perfiles separados. Al cargar comprueba identidad/autor y rechaza la operación sin borrar datos si falta un módulo. Los guardados sin requisitos conservan sus bytes anteriores; las cabeceras nuevas son versionadas y admiten la cabecera anterior. Al retirar un módulo que solo exige presencia, pausa sin descartar la partida y permite guardar antes de salir; no permite reanudar mientras falte. Las sesiones con requisitos se abren pausadas para preparar el módulo antes de continuar. La retirada de módulos que modificaron RAM/reglas/ROM mantiene el cierre de sesión de gameMod ya existente. Inicio nuevo disponible en CHIP-8, GB/GBC, NES, SMS/GG, NGP, GBA, MD, SNES, NDS y PS1; otros cores lo rechazan explícitamente. Studio reproduce metadatos de guardado, no SRAM real.
- **Contenido temporal GBA:** capabilities expone el espacio `rom`, con direcciones de archivo desde cero y longitud real del cartucho. read/write/readValues/writeValues/search/observe y reglas pueden usarlo, con emulation.memory.read/write y emulation.game-mod. write compara expected y admite lotes mixtos con RAM sin efectos parciales. Cambia únicamente el cartucho cargado de esa sesión; al volver a abrir se lee la ROM original. No expande su longitud ni cambia la detección inicial del tipo de guardado. Las modificaciones de ROM no se incluyen en los estados: el módulo debe declararse necesario y volver a preparar sus cambios al cargar. Studio usa ROM sintética. Scripts y recursos con nombre de proyectos RPG Maker siguen las APIs gameRuntime anteriores y sus límites; esto no añade un motor de scripts universal a otros cores.

`services.list(name?,{offset,limit})`, `entities.types({offset,limit})` y `ui.targets({offset,limit})` devuelven páginas de hasta 32 entradas por defecto (máximo 128) y 112 KiB. Avanza offset con el número de entradas recibidas hasta obtener una página vacía. Las cuotas por tamaño pueden producir una página menor que limit.

La matriz de memoria/ROM/reglas reales corresponde a GBA. Las otras familias de core no adquieren esas capacidades por compartir el SDK. El constructor visual y cualquier otra herramienta nueva se consultarán antes de desarrollarlos.

## Servicios, proveedores y eventos propios

`modules.services` permite publicar contratos dinámicos con `host.services.register({name,version,methods})`. Cada método declara esquemas input/output como los hooks existentes. `onService(request)` recibe service, method, value y caller (identidad real del módulo y autor). `host.services.call(name,method,value,{provider?,version?,author?})` llama al proveedor dentro de su runtime aislado; list(name?) descubre proveedores y unregister(name) retira solo los propios. Los contratos del mismo nombre y versión major deben tener los mismos métodos/esquemas. No se comparte código ni almacenamiento privado.

Ajustes ya no muestra el selector global de proveedores. Un consumidor puede indicar una alternativa mediante options.provider en services.call. Sin proveedor explícito ni preferencia previa, la base tiene prioridad cuando existe; un único proveedor propio se usa automáticamente. Si hay varios sin base, el consumidor debe indicar el proveedor. El host conserva las preferencias previas por identidad del autor. Límites: 256 proveedores y 32 métodos por contrato; esquemas de profundidad 8, 32 campos declarados, datos hasta 96 KiB, arrays de 256 elementos. Se rechazan ciclos y llamadas a un runtime ocupado; cambiar/retirar el proveedor invalida respuestas en curso.

La base publica `nelkano.emulation` 1.0.0 con método `execute`: input `{operation,args}`, output `{value:resultado}`. Consulta list("nelkano.emulation") para obtener/copiar el contrato exacto. Abarca snapshot, pausa/reset, presentación, guardar/cargar, library.launch y library.setCover. Las APIs anteriores delegan a este servicio conservando sus permisos. Una alternativa elegida implementa onService; para delegar a la base utiliza call con `{provider:"nelkano.base",author:"builtin",version:"1.0.0"}`. El consumidor necesita el permiso original de la operación incluso al utilizar services.call; el proveedor que delegue también necesita ese permiso. Esta sustitución afecta a operaciones solicitadas por módulos, no reemplaza automáticamente llamadas internas de la app ni cores nativos.

`modules.events` habilita `host.events.define(topic,schema)`, subscribe(topic), unsubscribe(topic) y emit(topic,value). El nombre publicado empieza por el identificador del módulo y un punto. Solo ese autor/módulo puede emitirlo; onEvent recibe `{type:"module-event",topic,value,sender:{moduleId,author}}`. Una suscripción puede preceder al proveedor. Eventos en cola se entregan en primer plano, hasta ocho por ronda aproximadamente cada 50 ms; no ofrecen entrega durable ni tiempo exacto. Hay 256 temas, 64 suscripciones y 64 eventos pendientes por módulo. Una cola llena rechaza el envío completo sin entrega parcial. Desactivar limpia servicios, temas, suscripciones y eventos propios. Los hooks anteriores siguen funcionando.


Se distribuye como @nelkano/sdk (tipos) y @nelkano/sdk-tools (CLI). No requiere clases ni imports del repositorio. El runtime de producción es Android nuevo; SDK Studio simula el host para Windows x64.

## Crear un módulo

Instala ambos paquetes .tgz con npm. Ejecuta npx nelkmod init mi-modulo, npx nelkmod check mi-modulo y npx nelkmod build mi-modulo. La entrada TypeScript puede usar import type desde @nelkano/sdk; los imports ejecutables son relativos y deben estar incluidos en el manifiesto.

Genera tu identidad con npx nelkmod keygen author.pem author-public.pem. Conserva la clave privada fuera del paquete. Empaqueta con npx nelkmod pack mi-modulo author.pem mi-modulo.nelkmod; comprueba con npx nelkmod verify mi-modulo.nelkmod. Importa desde Ajustes → Módulos y revisa firma, permisos y dependencias.

Ejemplos independientes: npx nelkmod example collections destino; npx nelkmod example hooks destino; npx nelkmod example skin destino. hooks contiene provider, icons y buttons: cada carpeta es un módulo empaquetable. Los ejemplos hooks enseñan el registro; la plantilla control-editor contiene el editor completo. Usa tu propia clave. El ejemplo Colecciones tiene identidad example.collections y convive con el incluido.

## Ganchos de Android

contributions(context) devuelve datos UiContribution: id, slot, label, actionId, order, enabled, visibility y payload. Puede incluir icon, kind (action/toggle), category (general/appearance/emulation), description y checked. Un toggle despacha checked con el nuevo estado y solo cambia al refrescar la respuesta del módulo.

LIBRARY_ACTION se dibuja junto a ordenación y vista; LIBRARY_SELECTION_ACTION en la selección. SETTINGS_SECTION y ajustes de sistema/emulación se dibujan como filas. PLAYER_SYSTEM_BUTTON se integra en el catálogo de geometría de emulación; placement contiene portrait/landscape con x/y entre 0 y 1, scale entre 0.5 y 2 y visible. Máximo 16 por módulo/contexto. Los demás slots documentados conservan sus zonas; PLAYER_OVERLAY y MODULE_PANEL siguen reservados.

icon puede ser standard:collections, standard:settings, standard:add o standard:reset, o una ruta PNG de files. Android muestra un icono estándar si falta o no puede decodificarse. PNG limitado al decodificar a 2048×2048. Si un proveedor muestra un icono de un consumidor, indica iconOwner; el host verifica que ese consumidor aportó exactamente esa ruta a un gancho del proveedor. No se admiten rutas externas. Cada icono conserva etiqueta accesible y la barra gestiona desbordamiento.

## Ganchos entre módulos

Declara la capacidad modules.hooks. provides publica name/version y tres esquemas: contribution, input y output. consumes declara provider/hook/version/optional, y author opcional (SHA-256 de la clave pública) para fijar publicador. dependencies declara id/version/optional y author opcional. El registro pertenece al host; cada runtime sigue aislado.

host.hooks.status() informa qué ganchos consumidos están disponibles. contribute(provider,hook,id,value) añade o reemplaza una aportación propia. list(provider,hook) devuelve aportaciones con moduleId, author, id y value; el proveedor puede leer sus propios ganchos. invoke(provider,hook,operation,value) llama onHook({hook,operation,value,caller:{moduleId,author}}) del proveedor y valida entrada y respuesta.

Los esquemas admiten type object/array/string/number/integer/boolean/null, properties, required, items, enum y additionalProperties. Máxima profundidad 8, 32 propiedades de esquema, 256 elementos de array y 128 KiB por mensaje. No hay JSON Schema completo ni importación de código de otro módulo.

Una versión requerida es un mínimo dentro del mismo major: 1.1.0 acepta 1.2.0 pero no 2.0.0. Una dependencia obligatoria debe estar activa y ser compatible; si desaparece se desactiva su consumidor conservando datos. Una opcional ausente retira su integración; el consumidor recibe hooks-changed y mantiene el resto. No se activan proveedores automáticamente ni se descargan dependencias. Se rechazan ciclos obligatorios y llamadas a un runtime ocupado (hook-call-cycle-or-busy), evitando llamadas circulares; el consumidor puede tratar este error. Los ganchos se retiran al desactivar o caer un módulo.

Los contratos del editor son icons (ControlIconContribution: target/icon/label) y system-buttons (SystemButtonContribution: actionId/icon/label). El proveedor almacena la elección del usuario por autor + moduleId + id; instalar alternativas no cambia la elección. Al desaparecer una alternativa usa el icono predeterminado y conserva la preferencia. El editor usa invokeContributor para ejecutar el callback del consumidor registrado. Los ejemplos anteriores siguen mostrando el patrón invoke hacia un proveedor declarado.

## Apariencia

Declara presentation.appearance y skins en el manifiesto. Cada skin contiene id/label y opcionalmente colors, background PNG, font TTF, icons, cornerRadius (0–32 dp), spacing (2–24 dp), controlHeight (36–64 dp), headerHeight (48–88 dp), navigation (bottom/top) y libraryView (grid/list inicial). Los recursos pertenecen al paquete verificado. Copia licencias de fuentes junto a los recursos.

Tokens de color: background, surface, surfaceSoft, border, text, muted, primary, primarySoft. Formato #RRGGBB o #AARRGGBB. icons usa nav.home/nav.library/nav.saves/nav.settings y standard:add/standard:reset/standard:settings. Los botones de juego mantienen su elección de iconos a través del editor; el skin no la reemplaza automáticamente.

El usuario selecciona un skin en Ajustes → Apariencia. La elección se guarda por autor y módulo; el host restaura el estilo predeterminado mientras está desactivado/desinstalado. La distribución inicial de biblioteca no reemplaza la vista que el usuario ya eligió en esa pantalla. No hay pantallas arbitrarias ni código Compose del módulo.

## Capacidades, datos y límites

storage.private.cas: documentos SQLite con CAS, privados por id y autor, hasta 96 KiB. library.read y saves.read: snapshots de solo lectura, hasta 128 KiB. Los paneles contienen campos text/select/json, filas y acciones. Los campos select usan desplegables tanto en páginas como en diálogos; presentation:tabs conserva las pestañas. El valor elegido mantiene su formato JSON. Las confirmaciones y copiar/pegar JSON se dibujan por Android. data-changed puede devolver filtros de games/saves; los de módulos activos se intersectan.

Paquete ZIP formato 1: hasta 32 MiB, 128 entradas y 8 MiB/archivo; JS/JSON/SVG/PNG/TXT/TTF, firma Ed25519 y todos los recursos declarados. SVG puede empaquetarse pero no se renderiza como icono en esta versión. SDK 0.1.0 permanece compatible. Doce runtimes QuickJS aislados, heap 32 MiB cada uno y cinco segundos por operación. Sin filesystem, red ni APIs Android expuestas a JavaScript. Una firma identifica autor, no confianza. Desinstalar conserva datos salvo elección expresa de borrarlos; actualizar requiere el mismo autor y el módulo desactivado.

## Editor de controles y lienzo declarativo

El módulo incluido nelkano.control-editor (0.1.0) usa SDK 0.2.0. Su lógica vive en modules/control-editor; el APK incorpora un .nelkmod firmado, desactivable e importable. Mantiene doce perfiles, vertical/horizontal, selección múltiple, movimiento en grupo, tamaños 0.5–2, visibilidad, cuadrícula y ajuste, zoom 1–4, desplazamiento y vista previa. Guardar confirma todos los perfiles visitados e iconos elegidos en un CAS; Cancelar conserva el diseño guardado.

Capacidad environment.display: host.environment.snapshot() devuelve width/height en píxeles, density, touchSlop y fpsVisibleByDefault. Studio devuelve métricas ficticias. No proporciona acceso a una ventana nativa.

Capacidad presentation.control-layouts: host.presentation.applyControlLayouts({moduleId,revision,profiles,layouts,icons?}) publica una capa propia. layouts usa claves PROFILE|PORTRAIT o PROFILE|LANDSCAPE y cada control admite x/y normalizados [0,1], scale [0.5,2], visible boolean. icons asocia ID de control con {moduleId,path}; el broker exige PNG declarado propio o aportado al proveedor. Se rechazan propietarios ajenos, revisiones anteriores y valores no válidos. releaseControlLayouts(moduleId) retira la capa propia; desactivar, desinstalar o fallar retira sus efectos y conserva datos. Si coinciden varias capas, la elección por perfil es determinista según el ID de módulo; se recomienda activar un único editor para cada perfil.

Respuesta dispatch: {kind:'control-editor',title,profile,orientation,profiles,nodes,viewport,grid,preview,scaleLevels,scaleLevel}. Un nodo contiene id,label,kind SCREEN/DPAD/JOYSTICK/INPUT/SYSTEM_ACTION,bounds [left,top,right,bottom] en píxeles del lienzo,value {x,y,scale,visible},selected,shown,opacity,asset e iconOwner opcional. viewport contiene virtualWidth/virtualHeight,scale,left/top; el módulo responde a resize(width,height). El host valida límites y recursos antes de mostrar el lienzo compartido por Android y Studio. No ejecuta callbacks UI del módulo. Las acciones del lienzo son switch(profile,orientation), drag(id,phase,x,y), select(id,toggle), scale-begin/scale(level)/scale-end, visibility, grid, reset, zoom, preview, save y cancel.

El editor publica icons y system-buttons 1.0.0. Un consumidor declara modules.hooks y consumes con provider nelkano.control-editor, hook, version y optional. icons acepta {target,icon,label}; target identifica el control (por ejemplo a o sys-pause). system-buttons acepta {actionId,icon,label,target?}. El editor conserva las elecciones por autor + módulo + ID. Si desaparece el consumidor, usa el icono predeterminado y retira sus botones, conservando la elección para una futura reactivación.

Para ejecutar un botón aportado, el proveedor usa host.hooks.invokeContributor(hook,moduleId,id,operation,value). Solo puede llamar a un consumidor que haya aportado ese ID a uno de sus propios ganchos. El broker comprueba identidad, disponibilidad y esquemas input/output; llama onHook del consumidor con hook,operation,value,contributionId y caller. No necesita conocer por adelantado IDs de futuros consumidores. Se mantiene el rechazo de llamadas circulares/runtime ocupado.

Crea una copia autónoma con npx nelkmod example control-editor mi-editor o la plantilla Editor de controles de Studio. La copia usa example.control-editor y una clave propia; puede coexistir, pero desactiva otros editores para probar su capa. Los perfiles se separan en src/profiles/*.js para poder abrirlos y editarlos en Studio. Guarda, verifica, exporta y prueba en Android nuevo. La receta interna bundle-control-editor.mjs empaqueta la copia incluida, con clave de desarrollo fuera del repositorio; sync-control-example.mjs sincroniza la plantilla desde las fuentes canónicas.

La asignación de teclas físicas/Bluetooth corresponde a gamepad y sigue pendiente. El lienzo no implementa funciones de grabación, reproducción ni autoguardado: los botones del catálogo solo ejecutan funciones disponibles en el jugador o acciones aportadas por otros módulos. Los SVG del catálogo se conservan en el paquete; el renderer utiliza etiquetas para ellos porque aún no decodifica SVG como icono. Studio no ejecuta ROMs ni hardware. SDK, APK y módulo mantienen sus versiones por petición de Ivan.


Secciones de Ajustes, 2026-10-04: Apariencia y Emulación son secciones de General, no pestañas. SETTINGS_SECTION admite section opcional, texto no vacío de hasta 64 caracteres sin controles, validado por ambos hosts. category conserva general/appearance/emulation como clasificación compatible; sin section se usan Funciones adicionales/Apariencia/Emulación. Colecciones declara Biblioteca y el editor Controles en pantalla; se retiran al desactivar el módulo. Tema se selecciona en General → Apariencia → Tema. BIOS conserva su pestaña; no se crean entradas de funcionalidades pendientes. Slots de ajustes de sistema y de emulación no cambian. Libro local importado y exportado; versiones e identidades de firma conservadas.

## Nelkano básicos y library.delete

La plantilla basics y el módulo modules/basics (nelkano.basics 0.1.0) añaden borrado individual en la ficha y múltiple en selección. host.library.requestDelete(gameIds) requiere library.delete, IDs existentes únicos (1–100) y devuelve {pending:true}. El host muestra confirmación nativa: cancelar conserva todo; confirmar borra biblioteca, copia importada privada y guardados. El módulo no puede aprobar ni obtiene archivos. El archivo original del selector se conserva. Studio solo modifica sus juegos ficticios, persistidos por entorno de desarrollo; Restablecer datos restaura las muestras. El nombre todavía no se puede modificar. library.setCover permite usar una captura de guardado como carátula. SDK 0.2.0 sin incremento de versión.


### Autoguardados de Nelkano básicos

`saves.autosave` permite `host.saves.setAutoSave(enabled)` con un booleano estricto. Publica una política del módulo, sin rutas, bytes de estados ni temporizadores JavaScript. Android escribe cada 60 segundos de juego continuo y sin pausa si el core admite SAVE_STATES y permite guardar. Usa el slot reservado 6, separado de los manuales 0–5, visible como Autoguardado y cargable desde ficha/Guardados. Pausar o cerrar la partida detiene el temporizador. Desactivar, desinstalar o fallar el módulo retira su solicitud; reactivar recupera la preferencia privada persistida por CAS. Con varias solicitudes basta una activa. El valor predeterminado es desactivado. Studio simula el ajuste y un slot ficticio cada minuto en su sesión de prueba, sin ejecutar ROMs ni producir estados reales.

## Operaciones de emulación

Android ejecuta las operaciones; el módulo decide cuándo usarlas. Studio implementa el mismo contrato con datos ficticios.

- emulation.read: host.emulation.snapshot() devuelve null o sesión, juego, pausa, capacidades, slots y display. También habilita eventos de partida.
- emulation.control: setPaused(session, boolean), reset(session).
- presentation.player: setFullscreen(session, boolean), setStretch(session, boolean), setScreenMode(session, 0|1|2), selectSlot(session, 0..6).
- saves.write: host.saves.save(session, 0..5).
- saves.load: host.saves.load(session, 0..6), solo guardados existentes.
- library.launch: host.library.launch(gameId, slot?), para un ID existente. Sin slot empieza de nuevo; con slot continúa.

Usa la referencia id/generation de la acción, no la de una partida posterior. El host rechaza sesiones antiguas, valores incorrectos, permisos ausentes y operaciones que el core no soporte. El slot 6 es automático y no admite escrituras manuales.

Eventos en onEvent: session-started, session-paused, session-resumed, session-closed, session-reset, save-created, save-loaded, display-changed. Incluyen session y gameId; guardados incluyen slot y automatic. No hay eventos por fotograma.

Nelkano básicos aporta los botones actuales mediante estas APIs, y la acción Continuar con payload.primaryLaunch. PLAYER_SYSTEM_BUTTON puede indicar payload.controlId para conservar posición/iconos ajustados en el editor. El editor transmite request.value.context al consumidor de system-buttons.

Guardar genera una miniatura del motor cuando hay imagen disponible. saves.list incluye hasThumbnail y library.list incluye coverSlot. library.setCover(gameId, slot) requiere library.cover y copia la captura; null restaura la portada. GAME_ARTWORK_ACTION coloca el botón sobre la imagen. Los paneles admiten preview y filas thumbnail: {gameId, slot, original?}; se validan library.read/saves.read y los IDs del catálogo. La captura independiente, su exportación y el renombrado siguen pendientes. Consulta el libro local, capítulo Emulación: operaciones y eventos, para ejemplos completos.

## Modificar un juego durante la sesión

`host.gameMod` ofrece `capabilities(session)`, `read(session, {ranges})`, `write(session, {writes})`, `installRule(session, rule)`, `removeRule(session, id)` y `listRules(session)`. Los rangos y escrituras llevan `space` y dirección absoluta; los bytes usan Base64. Consulta las capacidades antes de operar: este primer bloque conecta memoria y reglas a GBA; los demás cores no anuncian ese soporte y Studio simula una sesión.

Declara `emulation.game-mod` para el contrato nuevo. Consultar capacidades requiere además `emulation.read`; leer/listar, `emulation.memory.read`; escribir/retirar reglas, `emulation.memory.write`; instalar requiere lectura y escritura. Una escritura compara todos sus `expected` antes de aplicar y devuelve `{applied:false, conflictIndex}` si no coinciden, sin escritura parcial. Una regla comprueba sus condiciones y bytes esperados antes de cada frame del juego, sin ejecutar JavaScript en el core. Las reglas siguen registradas al reiniciar o cargar un estado de la misma sesión; vuelven a comprobar los bytes antes de actuar.

`capabilities` anuncia espacios/regiones, `memoryRead`, `memoryWrite`, `atomicWrite`, `frameRules` y los límites `maxRanges`, `maxBytes`, `maxRules`, `maxRuleBytes`. GBA admite 32 rangos y 32 KiB por operación; una regla suma hasta 32 condiciones/escrituras y toda la sesión comparte 16 reglas y 32 KiB combinados. Las condiciones y escrituras de reglas se limitan a RAM. `simulated:true` identifica memoria sintética de Studio; el host real devuelve `simulated:false`. Otros cores sin soporte anuncian espacios vacíos, funciones false y límites cero.
Las reglas y escrituras pertenecen al módulo y su autor. No se modifica la ROM original. Retirar una regla detiene su aplicación; no deshace cambios de memoria ni consecuencias en un guardado habitual. Desactivar o perder el módulo cierra la sesión que ha modificado para retirar la intervención. Este incremento no exige ni comprueba todavía dependencias de módulos al cargar un guardado.

Guía y ejemplos: [Modificar un juego, libro SDK local](http://localhost:8088/es/sdk-de-nelkano/modificar-juego). El plan de ampliaciones permanece en `brain/Android/Plataforma abierta y modificacion de juegos.md`; las funciones pendientes no se consideran disponibles. La conexión del contrato no certifica todos los juegos ni pruebas físicas.
## GBA Online y Pokémon Online

Ejemplos opcionales e independientes: `npx nelkmod example gba-online mi-gba-online` y `npx nelkmod example pokemon-online mi-pokemon-online`. Carga Amigos y ambos módulos en Studio. La memoria GBA, los checkpoints y el mundo son simulados; no se ejecuta Ruby ni se conecta a Internet. Las pruebas reales requieren exportar e importar en la aplicación. Contratos en `src/index.ts` del paquete SDK y documentación web, capítulo Online GBA.
## Números y observación de cambios

`host.gameMod.readValues(session, {values})` lee `u8`, `i8`, `u16`, `i16`, `u32`, `i32`, `f32` y `f64`. Cada entrada contiene `space`, `address`, `type` y `endian` opcional (`little`/`big`, por defecto el orden del espacio). Devuelve `value`, los mismos datos de dirección/tipo, `endian` efectivo y `data` Base64. Los floats no finitos devuelven `value:null`; `data` conserva los bits originales. Para NaN, infinito, cero con signo o comparaciones exactas de representaciones usa la API de bytes. Los enteros fuera de rango, fracciones enteras y desbordamientos float se rechazan.

`writeValues(session, {writes})` añade `value` y `expected` numéricos. Convierte todo el lote antes de escribir y utiliza los mismos permisos, comparación atómica, conflictos y retirada que `write`. Hasta 32 valores por lote. En hosts anteriores comprueba que estas funciones existan antes de llamarlas; no se ha cambiado la versión 0.2.0.

`observe(session, {id, ranges, everyFrames?})` requiere `emulation.game-mod`, `emulation.memory.read` y `runtime.events`. Consulta `memoryObserve`, `maxWatches`, `maxWatchBytes` y `maxWatchRanges`. GBA comparte 16 observaciones, 32 rangos y 16 KiB observados por sesión; `everyFrames` admite 1–600, por defecto 1. Se captura la base al registrar y se compara después de avanzar frames; pausar/capturar no produce muestras. Repetir tu id reemplaza tu observación y descarta avisos pendientes.

El módulo recibe en `onEvent` un objeto `game-memory-changed` con `session`, `watchId`, `sequence`, `frame`, `changes` y `ranges` (`space`, `address`, `before`, `data`, en Base64). Solo hay un aviso pendiente por observación: conserva el primer `before`, el último `data` y el número de muestras cambiadas agrupadas. El host entrega avisos aproximadamente cada 100 ms mientras está en primer plano; no garantiza detectar cambios transitorios entre muestras ni es una traza completa. El contador `frame` es de muestreo del adaptador; Studio cuenta pasos sintéticos, no fotogramas reales. Las observaciones permanecen en reset/load de la misma sesión y se comparan al volver a avanzar.

`unobserve(session, id)` retira únicamente tu observación y su aviso pendiente. Desactivar un módulo que solo observa conserva la partida abierta; escribir memoria o registrar reglas mantiene el cierre de la sesión al retirarlo. Cerrar/cambiar sesión elimina las observaciones anteriores. Studio simula el mismo contrato, sin ejecutar juegos. configureSave incorpora requisitos de módulo/autor y nueva partida por capacidad del core, descritos arriba.

## Buscar valores y generar código

Las búsquedas requieren `emulation.game-mod` y `emulation.memory.read`. Consulta `memorySearch`, `maxSearches`, `maxScanBytes`, `maxSearchBytes` y `maxSearchResults`. GBA y Studio comparten por sesión hasta cuatro búsquedas, 256 KiB por búsqueda y 1 MiB de capturas; cada página devuelve hasta 128 resultados. Otros cores anuncian false/cero.

```js
const search = await host.gameMod.searchStart(session, {
  space: "cpu", address: 0x02000000, length: 262144,
  type: "u16", mode: "unknown"
});
// Tras cambiar algo en el juego, conserva los candidatos que aumentaron.
const refined = await host.gameMod.searchRefine(session, {
  id: search.id, mode: "increased"
});
const page = await host.gameMod.searchRead(session, {
  id: search.id, offset: 0, limit: 32
});
await host.gameMod.searchClose(session, {id: search.id});
```

`searchStart` admite `equal` con `value` o `unknown` sin valor; tipos u8/i8/u16/i16/u32/i32/f32/f64. `endian` toma el orden del espacio por defecto. `alignment` admite 1/2/4/8 y por defecto el tamaño del tipo: es el paso entre candidatos desde la dirección inicial. El rango debe caber en una región legible.

`searchRefine` admite equal/notEqual (con value), changed/unchanged/increased/decreased (sin value). Compara solo los candidatos retenidos con la última captura y actualiza esa base cuando termina correctamente. changed/unchanged comparan bits; increased/decreased requieren números finitos. equal compara números, redondeando f32 a su representación; los no finitos se entregan como null y no coinciden con un valor finito.

La respuesta contiene id, matchCount, scannedBytes, revision, space, address, length, type, endian, alignment y paged. `searchRead` añade offset, results y hasMore. Los resultados incluyen dirección, tipo, orden, value y data Base64 de la última captura; no son lecturas nuevas en tiempo real. Conserva todos los candidatos aunque se vean por páginas. La captura usa tramos de hasta 32 KiB: con el juego en marcha no garantiza un instante simultáneo; pausa explícitamente si lo necesitas.

Las búsquedas son privadas por módulo y autor. searchClose devuelve false si no existe una búsqueda propia. Desactivar un módulo que solo busca conserva la partida abierta. Cerrar o cambiar sesión descarta las búsquedas; reset/load en la misma sesión conserva la captura anterior hasta refinarla.

En Studio pulsa **Explorar memoria**, abre GBA de prueba y elige dirección, tipo y rango. Puedes leer bytes y valores, iniciar una búsqueda conocida/desconocida, filtrarla, seleccionar un resultado y generar lectura, escritura comprobada u observación en JS/TS. **Copiar código** entrega funciones editables; debes incorporarlas a tu módulo y declarar sus permisos. La escritura generada lee primero expected y comprueba si se aplicó. La observación requiere también runtime.events. **Cambiar valor de prueba** solo modifica la RAM sintética de Studio, respetando los conflictos con módulos; cerrar el explorador libera sus búsquedas y conserva esos cambios hasta cerrar/restablecer la sesión. No conecta Studio a partidas reales ni edita automáticamente tus archivos.

## Prototipo Android: asistente por voz

La app experimental ofrece el servicio nativo `nelkano.voice-assistant` 1.0.0 mediante
`host.services.call`, con `modules.services` y `assistant.voice`. Métodos: snapshot, start,
stop, cancel, choose-model (objeto vacío) y ask ({question:string}). Son preguntas de texto;
no concede acceso a biblioteca, controles ni partidas. El modelo queda fuera de QuickJS y se
puede sustituir por un GGUF compatible mediante el selector del host. El aviso privado
assistant-state actualiza el panel de su propietario. Revocar el módulo o salir de la app
apaga la escucha y el motor. La escucha usa el servicio de Android y puede necesitar conexión;
solo se ofrece en primer plano y todavía requiere validación de voz real. Studio y Desktop no
implementan este backend. Ejemplo opcional: extensions/catalog/voice-assistant.

El prototipo local del asistente consulta extractos de un manual incluido en el host Android. Esto no añade operaciones al servicio ni entrena el modelo; no concede acceso a partidas o juegos y no sustituye la comprobación de capacidades.

Reportes de errores es una función privada del módulo oficial para cuentas Tester. Sus operaciones y transporte no forman parte del SDK público y no se conceden a módulos de terceros.

Nelkan IA incorpora en snapshot/assistant-state los campos microphoneReady (confirmación real del reconocedor) y heard (transcripción parcial/final privada). La conexión local fallida recurre al servicio configurado; los errores quedan visibles y la escucha sigue limitada al primer plano. Esto no acredita reconocimiento acústico con todas las voces.

Nelkan IA permite elegir voces del motor Android: set-voice({voice:string}) guarda el ID validado y preview-voice({}) sintetiza un ejemplo fijo. snapshot incluye voices ({id,label,network}), voice, voiceReady, voiceLoading y previewing. Se requieren los mismos permisos assistant.voice y modules.services. Catálogo hasta 64 voces españolas, excluyendo las marcadas pendientes de instalación; no es un catálogo universal de voces ni selecciona el modelo Qwen.

Nelkan IA queda dedicado a información documentada de Nelkano: Qwen devuelve un ID entre los apartados recuperados y el host valida y entrega únicamente texto local revisado o un aviso de falta de información. No se exponen respuestas generales libres, no se modifican pesos y no se ejecutan acciones. El manual de la app modular se conserva en assistant/src/main/assets/nelkano-knowledge.json.

La aplicación base incorpora su propio actualizador: comprueba versiones oficiales, descarga y verifica el paquete y entrega la instalación a Android, Windows o Linux/SteamOS tras cerrar la partida. Este mecanismo conserva los datos y módulos y no añade operaciones JavaScript al SDK. SDK Studio no consulta ni instala actualizaciones de la aplicación; su distribución se actualiza por separado. La primera aplicación con este sistema debe instalarse por el procedimiento habitual y el catálogo debe desplegarse antes de ofrecer una versión posterior.
