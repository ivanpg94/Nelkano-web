/**
 * Public SDK 0.2.0. Only declarative data and capability-limited host ports.
 * Labels match sdk/contracts; APK support is limited to the documented capabilities.
 */
export type UiSlot =
  | "HOME_SECTION" | "LIBRARY_HEADER_ACTION" | "LIBRARY_ACTION" | "LIBRARY_SELECTION_ACTION"
  | "GAME_LAUNCH_ACTION" | "GAME_HEADER_ACTION" | "GAME_ARTWORK_ACTION" | "SAVE_ACTION" | "SETTINGS_SECTION"
  | "SYSTEM_ACTION" | "SYSTEM_SETTINGS_SECTION" | "EMULATION_SETTINGS_SECTION"
  | "PLAYER_ACTION" | "PLAYER_MENU" | "PLAYER_SYSTEM_BUTTON";

/** Reuses a stable control position, for example sys-pause, without adding a duplicate. */
export interface PlayerControlPayload { controlId:string }
/** Displays this GAME_LAUNCH_ACTION beside Play; the module dispatch implements the action. */
export interface PrimaryLaunchPayload { primaryLaunch:true; gameId:string; slot:number }
export interface UiContribution {
  moduleId: string;
  id: string;
  slot: UiSlot;
  label: string;
  actionId: string;
  order?: number;
  enabled?: boolean;
  visibility?: UiVisibility;
  payload?: JsonObject;
  iconOwner?: string; // Owner must have contributed this PNG to one of your hooks.
  icon?: string; // standard:collections, standard:settings, or PNG path in this package
  kind?: 'action' | 'toggle'; category?: 'general' | 'appearance' | 'emulation';
  description?: string; checked?: boolean;
  section?: string; // SETTINGS_SECTION heading within General: 1Ã¢â‚¬â€œ64 characters, no control characters.
  placement?: { portrait?: ControlPlacement; landscape?: ControlPlacement };
}

export interface SdkSessionReference { id: string; generation: number; }
export interface UiContext {
  gameId?: string;
  systemId?: string;
  session?: SdkSessionReference;
  capabilities: readonly string[];
  connected: boolean;
  surface: string; language: string; selection: readonly string[]; saveId?: string;
}
export interface UiVisibility {
  systems?: readonly string[];
  requiresGame?: boolean;
  requiresSession?: boolean;
  requiresConnection?: boolean;
  capabilities?: readonly string[];
}
export interface ModuleAction {
  payload?: JsonObject;
  context?: UiContext;
  moduleId: string;
  actionId: string;
  session?: SdkSessionReference;
  gameId?: string;
  systemId?: string;
}

export type JsonValue = null | boolean | number | string | JsonValue[] | JsonObject;
export interface JsonObject { [key: string]: JsonValue }
export interface ControlPlacement { x:number; y:number; scale:number; visible:boolean }
export interface HookContribution { moduleId:string; author:string; provider:string; hook:string; id:string; value:JsonValue }
export interface HookStatus { provider:string; hook:string; available:boolean }
export interface HookSchema { type:'object'|'array'|'string'|'number'|'integer'|'boolean'|'null'; properties?:Record<string,HookSchema>; required?:string[]; items?:HookSchema; enum?:JsonValue[]; additionalProperties?:boolean }
export interface HookProvider {name:string;version:string;contribution:HookSchema;input:HookSchema;output:HookSchema}
export interface ServiceContract {name:string;version:string;methods:Record<string,{input:HookSchema;output:HookSchema}>}
export interface ServiceProvider extends ServiceContract {provider:string;author:string;selected:boolean}
export interface ServiceRequest {service:string;method:string;value:JsonValue;phase?:'before'|'after';hookId?:string;caller:{moduleId:string;author:string};provider:{moduleId:string;author:string}}
export interface ConnectionJob {id:string;kind:'socket'|'request';state:'running'|'connecting'|'open'|'closed'|'complete'|'failed';error?:string;response?:{status?:number;headers?:Record<string,string>;bodyBase64?:string;code?:number;reason?:string};messages?:Array<{type:'text';text:string}|{type:'binary';dataBase64:string}>;hasMore?:boolean}
export interface TaskStatus {id:string;revision:number;state:'scheduled'|'due'|'running'|'complete'|'failed';occurrences:number;progress:number;message?:string;result?:JsonValue}
export interface EntityDefinition {name:string;version:string;schema:HookSchema;indexes?:string[];relations?:Record<string,{target:string;many?:boolean}>}
export interface EntityRecord {type:string;id:string;revision:number;data:JsonObject}
export type EntityWrite={operation:'put';type:string;id:string;expectedRevision:number;data:JsonObject}|{operation:'delete';type:string;id:string;expectedRevision:number};
export interface EntityQuery {where?:JsonObject;orderBy?:string;direction?:'asc'|'desc';offset?:number;limit?:number}
export interface EntityPage {records:EntityRecord[];offset:number;matchCount:number;hasMore:boolean;revision:number}
export interface UiNode {id:string;kind:'column'|'list'|'row'|'box'|'text'|'button'|'field'|'toggle'|'select'|'tabs'|'modal'|'image'|'spacer'|'divider'|'canvas'|'rect'|'circle'|'line';text?:string;label?:string;value?:string|boolean|number;actionId?:string;payload?:JsonObject;children?:UiNode[];options?:Array<{id:string;label:string}>;resource?:string;checked?:boolean;enabled?:boolean;placeholder?:string;multiline?:boolean;style?:{width?:number;height?:number;padding?:number;spacing?:number;x?:number;y?:number;radius?:number;color?:string;background?:string}}
export interface UiPageDefinition {id:string;title:string;content:UiNode}
export interface UiMountDefinition {id:string;target:string;content:UiNode;order?:number}
export interface UiPatchDefinition {id:string;target:string;changes:{text?:string;label?:string;hidden?:boolean;enabled?:boolean;actionId?:string}}
export type UiRegistration=(UiPageDefinition|UiMountDefinition|UiPatchDefinition)&{kind:'page'|'mount'|'patch';moduleId:string;author:string;revision:number};
export interface HookConsumer {provider:string;hook:string;version:string;optional:boolean;author?:string}
export interface ModuleDependency {id:string;version:string;optional:boolean;author?:string}
export interface Skin {id:string;label:string;colors?:Record<string,string>;background?:string;font?:string;icons?:Record<string,string>;cornerRadius?:number;spacing?:number;controlHeight?:number;headerHeight?:number;navigation?:'bottom'|'top';libraryView?:'grid'|'list'}
export interface ModuleManifest {formatVersion:1;id:string;name:string;version:string;sdkVersion:'0.1.0'|'0.2.0';platforms:('android'|'jvm-desktop')[];entry:string;bundledByDefault:boolean;dependencies:ModuleDependency[];capabilities:string[];files:string[];origins?:string[];provides?:HookProvider[];consumes?:HookConsumer[];skins?:Skin[]}
export interface EmulationSnapshot { session:SdkSessionReference; gameId:string; systemId:string; paused:boolean; pauseAllowed?:boolean; capabilities:string[]; slots:number[]; canSave:boolean; display:{fullscreen:boolean;stretch:boolean;screenMode:0|1|2;selectedSlot:number} }
export interface PlayerEvent { type:'session-started'|'session-paused'|'session-resumed'|'session-closed'|'session-reset'|'save-created'|'save-loaded'|'display-changed'; session:SdkSessionReference; gameId:string; slot?:number; automatic:boolean }
export interface AccountSnapshot { uid:number; signedIn:boolean; name?:string; email?:string; friends?:boolean; role?:string; connectionError?:string }
export interface AccountLogin {email:string; password:string}
export interface AccountRegistration extends AccountLogin {name:string; password_confirm:string; terms:boolean}
export interface AccountRequest {method:"GET"|"POST";path:string;body?:JsonObject|null;accountUid:number}
export interface GamepadSnapshot {simulated?:boolean;devices:Array<{id:number;name:string;descriptor:string}>;bindings:Record<string,string>}
export interface SecondScreenSnapshot {simulated?:boolean;devices:Array<{id:string;name:string}>;remembered:Array<{id:string;name:string}>;state:string;message:string;receiver:boolean;remoteScreen?:'TOP'|'BOTTOM'}
export interface StreamingConfig {width:number;height:number;fps:number;videoBitrateKbps:number}
export interface StreamingSnapshot {simulated?:boolean;active:boolean;state:string;message:string;destination:string;config:StreamingConfig;sessionId?:string;pin?:string;joinUri?:string;relay?:{frames:number;audioChunks:number;failures:number;quality:number};stats?:{videoFrames:number;audioBuffers:number;connection:string}}
export interface MemoryRange {address:number;length:number}
export interface MemoryWrite {address:number;data:string;expected:string}
export interface CheckpointReference {checkpointId:string;gameId?:string;size:number}
export interface OnlineSnapshot {state:string;message:string;sessionId:string;role:string;events?:JsonObject[]}
/** Generic game modification tools. Addresses belong to an advertised space. */
export interface GameModRegion { id: string; start: number; length: number; readable: boolean; writable: boolean }
export interface GameModSpace { id: string; addressBits: number; byteOrder: 'little' | 'big'; regions: readonly GameModRegion[] }
export interface GameModCapabilities {
 session: SdkSessionReference; gameId: string; systemId: string; simulated: boolean;
 spaces: readonly GameModSpace[];
 memoryRead: boolean; memoryWrite: boolean; atomicWrite: boolean; frameRules: boolean;
 input:boolean;inputCodes:readonly number[];saveRequirements:boolean;newGame:boolean;
 maxRanges: number; maxBytes: number; maxRules: number; maxRuleBytes: number;
 memoryObserve: boolean; maxWatches: number; maxWatchBytes: number; maxWatchRanges: number;
 memorySearch: boolean; maxSearches: number; maxScanBytes: number; maxSearchBytes: number; maxSearchResults: number;
}
export interface GameModSearchStart {space:string;address:number;length:number;type:GameModNumberType;endian?:'little'|'big';alignment?:1|2|4|8;mode:'equal'|'unknown';value?:number}
export interface GameModSearchRefine {id:string;mode:'equal'|'notEqual'|'changed'|'unchanged'|'increased'|'decreased';value?:number}
export interface GameModSearchSummary {id:string;matchCount:number;scannedBytes:number;revision:number;space:string;address:number;length:number;type:GameModNumberType;endian:'little'|'big';alignment:number;paged:true}
export interface GameModSearchResults extends GameModSearchSummary {offset:number;hasMore:boolean;results:GameModValueRead[]}
export type GameModNumberType = 'u8' | 'i8' | 'u16' | 'i16' | 'u32' | 'i32' | 'f32' | 'f64';
export interface GameModValueRange { space: string; address: number; type: GameModNumberType; endian?: 'little' | 'big' }
export interface GameModValueWrite extends GameModValueRange { value: number; expected: number }
export interface GameModValueRead extends GameModValueRange { endian: 'little' | 'big'; value: number | null; data: string }
export interface GameModWatch { id: string; ranges: readonly GameModMemoryRange[]; everyFrames?: number }
/** Coalesced sampled changes, delivered to onEvent; this is not a complete execution trace. */
export interface GameModMemoryEvent {
 type: 'game-memory-changed'; session: SdkSessionReference; watchId: string;
 sequence: number; frame: number; changes: number;
 ranges: Array<{space: string; address: number; before: string; data: string}>;
}
export interface GameModMemoryRange { space: string; address: number; length: number }
/** data and expected are canonical base64 bytes of equal length. */
export interface GameModMemoryWrite { space: string; address: number; data: string; expected: string }
export interface GameModCondition { space: string; address: number; expected: string }
export interface GameModRule { id: string; conditions?: readonly GameModCondition[]; writes: readonly GameModMemoryWrite[] }
export interface GameModRuleSnapshot { id: string; conditions: readonly GameModCondition[]; writes: readonly GameModMemoryWrite[] }
export interface GameModWriteResult { applied: boolean; conflictIndex?: number }
export interface GameMod {
 /** Require this module and author for saves of a game. newGame rejects untagged progress. */
 configureSave(spec:{gameId:string;newGame?:boolean}):Promise<boolean>;
 /** Read-only paged captures; emulation.game-mod and emulation.memory.read. An active game can change between capture pages. */
 searchStart(session:SdkSessionReference,value:GameModSearchStart):Promise<GameModSearchSummary>;
 searchRefine(session:SdkSessionReference,value:GameModSearchRefine):Promise<GameModSearchSummary>;
 /** Returns the last captured values, not a fresh live read. Results are private and paged. */
 searchRead(session:SdkSessionReference,value:{id:string;offset?:number;limit?:number}):Promise<GameModSearchResults>;
 searchClose(session:SdkSessionReference,value:{id:string}):Promise<boolean>;
 /** Requires emulation.game-mod and emulation.read; inspect actual core capabilities first. */
 capabilities(session: SdkSessionReference): Promise<GameModCapabilities>;
 input(session:SdkSessionReference,value:{buttons:readonly {code:number;pressed:boolean}[]}):Promise<{pressedCodes:number[]}>;
 /** Numeric reads use the advertised byte order by default. Non-finite floats return null and retain raw data. */
 readValues(session: SdkSessionReference, value: {values: readonly GameModValueRange[]}): Promise<{values: GameModValueRead[]}>;
 /** Same atomic expected-value and ownership checks as write. */
 writeValues(session: SdkSessionReference, value: {writes: readonly GameModValueWrite[]}): Promise<GameModWriteResult>;
 /** Requires emulation.game-mod, emulation.memory.read and runtime.events. Read-only sampling never claims writes. */
 observe(session: SdkSessionReference, value: GameModWatch): Promise<{id: string}>;
 /** Removing a watch discards its pending event and does not close the game. */
 unobserve(session: SdkSessionReference, id: string): Promise<boolean>;
 /** Requires emulation.game-mod and emulation.memory.read. */
 read(session: SdkSessionReference, value: { ranges: readonly GameModMemoryRange[] }): Promise<{ ranges: Array<{ space: string; address: number; data: string }> }>;
 /** Requires emulation.game-mod and emulation.memory.write. All expected bytes match or nothing is written. */
 write(session: SdkSessionReference, value: { writes: readonly GameModMemoryWrite[] }): Promise<GameModWriteResult>;
 /** Requires emulation.game-mod, emulation.memory.read and emulation.memory.write. Conditions/writes run at core frame boundaries, without calling JavaScript per frame. */
 installRule(session: SdkSessionReference, value: GameModRule): Promise<{ id: string }>;
 /** Only removes this module author's rule. Removing a rule does not undo earlier gameplay effects. */
 removeRule(session: SdkSessionReference, id: string): Promise<boolean>;
 /** Requires emulation.game-mod and emulation.memory.read; only returns rules owned by this module author. */
 listRules(session: SdkSessionReference): Promise<GameModRuleSnapshot[]>;
}
export interface Host {
 secrets: {
  capabilities():Promise<{persistent:boolean;maxKeys:number;maxValueBytes:number;maxTotalBytes:number}>;
  get(key:string):Promise<string|null>;put(key:string,value:string):Promise<boolean>;remove(key:string):Promise<boolean>;
 };
 files: {
  capabilities():Promise<{importExport:boolean;maxFiles:number;maxFileBytes:number;maxTotalBytes:number;maxChunkBytes:number}>;
  list(options?:{offset?:number;limit?:number}):Promise<Array<{name:string;revision:number;size:number;mimeType:string}>>;
  read(name:string,range:{offset:number;length:number}):Promise<{name:string;revision:number;size:number;mimeType:string;dataBase64:string}>;
  begin(spec:{name:string;expectedRevision:number;mimeType?:string}):Promise<{id:string}>;
  write(id:string,chunk:{offset:number;dataBase64:string}):Promise<{size:number}>;
  commit(id:string):Promise<{applied:boolean;revision?:number;file?:{name:string;revision:number;size:number;mimeType:string}}>;
  abort(id:string):Promise<boolean>;remove(name:string,expectedRevision:number):Promise<boolean>;
  import(spec:{name:string;expectedRevision:number;mimeType?:string}):Promise<{cancelled?:boolean;applied?:boolean;revision?:number;file?:{name:string;revision:number;size:number;mimeType:string}}>;
  export(name:string):Promise<{saved:boolean;cancelled:boolean}>;
 };

 tasks: {
  capabilities():Promise<{persistent:false;closedApp:false;maxTasks:number;minIntervalMs:number}>;
  schedule(spec:{id:string;delayMs:number;intervalMs?:number;payload?:JsonValue}):Promise<TaskStatus>;
  read(id:string):Promise<TaskStatus>;
  update(id:string,value:{state?:'running'|'complete'|'failed';progress?:number;message?:string;result?:JsonValue}):Promise<TaskStatus>;
  cancel(id:string):Promise<boolean>;
 };
 connections: {
  capabilities():Promise<{http:boolean;https:boolean;ws:boolean;wss:boolean;maxResponseBytes:number;maxJobs:number;maxSockets:number}>;
  origins():Promise<string[]>;
  requestOrigin(origin:string):Promise<{allowed:boolean;pending:boolean}>;
  request(spec:{url:string;method?:'GET'|'HEAD'|'POST'|'PUT'|'PATCH'|'DELETE'|'OPTIONS';headers?:Record<string,string>;bodyBase64?:string;contentType?:string;timeoutMs?:number}):Promise<ConnectionJob>;
  socket(spec:{url:string;headers?:Record<string,string>;protocols?:string[]}):Promise<ConnectionJob>;
  read(id:string):Promise<ConnectionJob>;
  send(id:string,message:{text:string}|{dataBase64:string}):Promise<boolean>;
  close(id:string):Promise<boolean>;
 };
 ui: {
  page(definition:UiPageDefinition):Promise<UiRegistration>;
  mount(definition:UiMountDefinition):Promise<UiRegistration>;
  patch(definition:UiPatchDefinition):Promise<UiRegistration>;
  remove(id:string):Promise<boolean>;
  open(id:string):Promise<boolean>;
  close():Promise<boolean>;
  targets(options?:{offset?:number;limit?:number}):Promise<Array<{target:string;base:JsonObject}>>;
 };
 entities: {
  define(definition:EntityDefinition):Promise<EntityDefinition>;
  types(options?:{offset?:number;limit?:number}):Promise<EntityDefinition[]>;
  get(type:string,id:string):Promise<EntityRecord|null>;
  query(type:string,query?:EntityQuery):Promise<EntityPage>;
  transact(operations:EntityWrite[]):Promise<{applied:boolean;revision?:number;records?:Array<EntityRecord|{type:string;id:string;revision:number;deleted:true}>;conflictIndex?:number}>;
  migrate(migration:{name:string;fromVersion:string;definition:EntityDefinition;updates:Array<{id:string;expectedRevision:number;data:JsonObject}>}):Promise<{applied:true;version:string}>;
 };
 services: {
  intercept(hook:{id:string;name:string;method:string;phase:'before'|'after';order?:number}):Promise<boolean>;
  removeInterceptor(id:string):Promise<boolean>;
  register(contract:ServiceContract):Promise<ServiceProvider>;
  unregister(name:string):Promise<boolean>;
  list(name?:string|null,options?:{offset?:number;limit?:number}):Promise<ServiceProvider[]>;
  call(name:string,method:string,value:JsonValue,options?:{provider?:string;version?:string;author?:string}):Promise<JsonValue>;
 };
 events: {
  define(topic:string,schema:HookSchema):Promise<boolean>;
  subscribe(topic:string):Promise<boolean>;
  unsubscribe(topic:string):Promise<boolean>;
  emit(topic:string,value:JsonValue):Promise<{delivered:number}>;
 };
 gameMod: GameMod;
 gameRuntime:{frame(session:SdkSessionReference,value?:{width?:number;height?:number}):Promise<{width:number;height:number;argb:string}>;read(session:SdkSessionReference,value:{ranges:MemoryRange[]}):Promise<{ranges:{address:number;data:string}[]}>;rom(session:SdkSessionReference,value:{offset:number;length:number}):Promise<{data:string;size:number}>;romSearch(session:SdkSessionReference,value:{pattern:string;alignment?:1|2|4;maximum?:number;offset?:number;end?:number}):Promise<{offsets:number[]}>;patch(session:SdkSessionReference,value:{writes:MemoryWrite[]}):Promise<boolean>;checkpoint(session:SdkSessionReference):Promise<CheckpointReference>;checkpointRead(value:{checkpointId:string;offset:number;length:number}):Promise<{data:string;size:number}>;checkpointPatch(value:{checkpointId:string;offset:number;data:string;expected:string}):Promise<CheckpointReference>;restore(session:SdkSessionReference,value:{checkpointId:string}):Promise<boolean>;projectLaunch(value:{gameId:string}):Promise<boolean>;projectActive(session:SdkSessionReference,options:{gameId:string}):Promise<{active:boolean}>;projectWrite(value:{gameId:string;path:string;data:string;offset?:number;final?:boolean}):Promise<boolean>;projectRead(value:{gameId:string;path:string;offset?:number;length?:number}):Promise<{data:string;size:number}>;subscribe(session:SdkSessionReference,enabled:boolean,options?:{intervalMs?:number}):Promise<boolean>;overlay(session:SdkSessionReference,nodes:RuntimeOverlayNode[]):Promise<boolean>;invoke(session:SdkSessionReference,value:{receiver:string;method:string}):Promise<{result:string}>;external(session:SdkSessionReference,value:JsonObject):Promise<{outgoing:string[]}>};
 online:{connect(value:{accountUid:number;friendUid:number;role:'host'|'guest';system:string;mode:string;romHash:string}):Promise<OnlineSnapshot>;snapshot():Promise<OnlineSnapshot>;send(value:{type:string;payload:JsonObject}):Promise<boolean>;disconnect(options?:{reason?:string}):Promise<OnlineSnapshot>};

 /** media.streaming: native host confirmation is required before credentials or remote I/O. */
 streaming:{snapshot():Promise<StreamingSnapshot>;start(config:StreamingConfig):Promise<StreamingSnapshot|{cancelled:true}>;stop():Promise<StreamingSnapshot>};
 /** input.gamepad: Android receives keys natively. Only one active module owns the mappings. */
 input:{importProfile():Promise<{state?:JsonObject;cancelled?:boolean;simulated?:boolean}>;exportProfile(state:JsonObject):Promise<{saved?:boolean;cancelled?:boolean;simulated?:boolean}>;snapshot():Promise<GamepadSnapshot>;configure(bindings:Record<string,string>,ps1Bindings?:Record<string,number>):Promise<boolean>;capture(device?:number):Promise<{token?:string;cancelled:boolean}>;settings():Promise<boolean>;release():Promise<boolean>};
 /** media.second-screen: discovered LAN receivers only; never an arbitrary URL. */
 secondScreen:{snapshot():Promise<SecondScreenSnapshot>;discover():Promise<SecondScreenSnapshot>;connect(id:string):Promise<SecondScreenSnapshot>;disconnect():Promise<SecondScreenSnapshot>;receiver(enabled:boolean):Promise<SecondScreenSnapshot>;pair(enabled:boolean):Promise<SecondScreenSnapshot>;swap():Promise<SecondScreenSnapshot>;forget(id:string):Promise<SecondScreenSnapshot>};
 /** appearance.locale plus presentation.appearance. Themes are declared in manifest.skins. */
 appearance:{snapshot():Promise<{language:string;skinId:string;skins:Array<{id:string;label:string}>}>;apply(value:{language:string;skinId:string;strings:Record<string,string>}):Promise<boolean>;release():Promise<boolean>};
 /** resources.patch: opaque picker references expire in ten minutes and belong to their module. */
 patches:{pick():Promise<{resourceId?:string;name?:string;cancelled?:boolean}>;apply(value:{resourceId:string;gameId:string;title?:string}):Promise<{gameId:string;title:string}>};
 /** account.session: token-free identity, login, registration and logout. Android stores and renews the signed session; no tokens are exposed. */
 account:{snapshot():Promise<AccountSnapshot>;login(value:AccountLogin):Promise<AccountSnapshot>;register(value:AccountRegistration):Promise<JsonObject>;logout():Promise<boolean>};
 /** network.account: approved account endpoints only, never a token or arbitrary origin. */
 network:{request(value:AccountRequest):Promise<{status:number;body:JsonObject}>;image(url:string):Promise<string>};
 /** resources.image: host-owned image reference, not a filesystem path. */
 resources:{pickImage():Promise<{resourceId?:string;preview?:string;cancelled?:boolean}>};
 emulation:{snapshot():Promise<EmulationSnapshot|null>;setPaused(session:SdkSessionReference,paused:boolean):Promise<boolean>;reset(session:SdkSessionReference):Promise<boolean>;setFullscreen(session:SdkSessionReference,enabled:boolean):Promise<boolean>;setStretch(session:SdkSessionReference,enabled:boolean):Promise<boolean>;setScreenMode(session:SdkSessionReference,mode:0|1|2):Promise<boolean>;selectSlot(session:SdkSessionReference,slot:number):Promise<boolean>};
 environment:{snapshot():Promise<DisplayEnvironment>};
 presentation:{applyControlLayouts(value:ControlLayoutDocument):Promise<boolean>;releaseControlLayouts(moduleId:string):Promise<boolean>};
 hooks: { invokeContributor(hook:string,moduleId:string,id:string,operation:string,value:JsonValue):Promise<JsonValue>;status():Promise<HookStatus[]>;list(provider:string,hook:string):Promise<HookContribution[]>;contribute(provider:string,hook:string,id:string,value:JsonValue):Promise<boolean>;invoke(provider:string,hook:string,operation:string,value:JsonValue):Promise<JsonValue> };
 storage: { read(key: string): Promise<{ revision: number; value: JsonValue }>;
 compareAndSwap(key: string, revision: number, value: JsonValue): Promise<boolean> };
 /** library.delete requests host confirmation; it never grants filesystem access. */
 library: { setCover(gameId:string,slot:number|null):Promise<boolean>; launch(gameId:string,slot?:number):Promise<boolean>; list(): Promise<Array<{ id: string; title: string; systemId: string; kind: 'local';coverSlot?:number|null }>>; requestDelete(gameIds:string[]):Promise<{pending:boolean}> };
 /** saves.autosave publishes a module-owned policy; host writes a separate automatic slot every minute. */
 saves: { save(session:SdkSessionReference,slot:number):Promise<boolean>; load(session:SdkSessionReference,slot:number):Promise<boolean>; setAutoSave(enabled:boolean):Promise<boolean>; list(): Promise<Array<{ id: string; gameId: string; slot: number;hasThumbnail?:boolean }>> };
}
export interface PanelAction { actionId: string; label: string; payload?: JsonObject; confirm?: boolean; primary?:boolean; enabled?:boolean; submitFields?:boolean; placement?:"header"|"footer" }
export interface Panel { kind: 'panel' | 'page'; layout?:'settings'; id?:string; text?:string; title: string; preview?:{gameId:string;slot:number|null};
 fields: Array<{ id: string; kind: 'text' | 'select' | 'json' | 'password' | 'email' | 'checkbox'; label: string; initial?: string | boolean; multiline?:boolean; presentation?:'tabs'; onChangeAction?:string; onChangeMinLength?:number; required?: boolean; options?: Array<{ value: JsonValue; label: string }> }>;
 rows: Array<{ id: string; label: string; selected?: boolean;subtitle?:string;presentation?:'section'|'actions'|'setting'|'list';badge?:string;icon?:string;value?:string;position?:"header";avatar?:{initial:string;color:string;image?:string;url?:string};thumbnail?:{gameId:string;slot:number|null;original?:boolean}; actions: PanelAction[] }>;
 actions: PanelAction[];
}
export interface ClosePanel { kind: 'close-panel' }
export interface Extension {
 activate(): Promise<void>; deactivate(): Promise<void>;
 contributions(context: UiContext): Promise<UiContribution[]>;
 dispatch(action: string, payload: JsonObject, context: UiContext): Promise<JsonValue | Panel | ControlEditorCanvas | ClosePanel>;
 onHook?(request:{hook:string;operation:string;value:JsonValue;contributionId?:string;caller:{moduleId:string;author:string}}):Promise<JsonValue>;
 onService?(request:ServiceRequest):Promise<JsonValue>;
 onEvent?(event: JsonObject): Promise<JsonValue | { filters: { games?: string[]; saves?: string[] } }>;
}

/** Hooks to publish from a controls editor. The provider id is chosen by its author. */
export interface ControlIconContribution { target:string; icon:string; label:string }
export interface SystemButtonContribution { actionId:string; icon:string; label:string; target?:string }
// Hook names: icons (ControlIconContribution), system-buttons (SystemButtonContribution).
// The provider stores the selected moduleId/contribution id, and restores defaults when unavailable.

/** HOME_SECTION payload.section renders host-owned game cards; IDs must belong to the host catalog. */
export interface GameCarouselSection { kind: "game-carousel"; gameIds: string[]; emptyLabel: string }

/** Capability environment.display: physical display metrics (simulated in Studio). */
export interface DisplayEnvironment {width:number;height:number;density:number;touchSlop:number;fpsVisibleByDefault:boolean}
export interface ControlLayoutDocument {moduleId:string;revision:number;profiles:JsonObject[];layouts:Record<string,Record<string,Partial<ControlPlacement>>>;icons?:Record<string,{moduleId:string;path:string}>}
export interface ControlCanvasNode {id:string;label:string;kind:'SCREEN'|'DPAD'|'JOYSTICK'|'INPUT'|'SYSTEM_ACTION';bounds:[number,number,number,number];value:ControlPlacement;selected:boolean;shown:boolean;opacity:number;asset:string|null;iconOwner?:string}
/** Declarative canvas events: resize/switch/drag/select/visibility/scale/grid/zoom/preview/save/cancel. */
export interface ControlEditorCanvas {kind:'control-editor';title:string;profile:string;orientation:'PORTRAIT'|'LANDSCAPE';profiles:{key:string;label:string}[];nodes:ControlCanvasNode[];viewport:JsonObject;grid:JsonObject|null;preview:boolean;scaleLevels:number[];scaleLevel:number}

/** Public hooks of nelkano.friends. Declare modules.hooks and the relevant consumes entry (1.0.0). */
export interface FriendHookUser {uid:number;name:string;statusText:string;avatarColor:string;avatarUrl:string}
export interface FriendsHookSnapshot {revision:number;account:{uid:number;signedIn:boolean;name:string};friends:FriendHookUser[];incoming:FriendHookUser[];outgoing:FriendHookUser[]}
export interface FriendActionContribution {label:string;scope?:'friends'|'incoming'|'outgoing'|'search'}
export interface FriendActionInvocation {accountUid:number;friend:FriendHookUser;scope:'friends'|'incoming'|'outgoing'|'search'}
export interface FriendsHookEvent extends FriendsHookSnapshot {type:'session-changed'|'friends-updated'|'profile-updated'}

/** Built-in editor profiles; modules can continue using their own string keys. */
export type BuiltinControlProfile = "GAME_BOY"|"GBA"|"NDS"|"N3DS"|"NES"|"MEGADRIVE"|"MASTER_SYSTEM"|"GAME_GEAR"|"NEO_GEO_POCKET"|"PS1"|"CHIP8"|"RPG_MAKER"|"SWITCH"|"PSP"|"GAMECUBE";
export type StickControlInput = "LEFT_STICK"|"RIGHT_STICK";

/** Camera origins are in world pixels; modulus handles wrapped hardware scroll registers. */
export interface RuntimeOverlayNode {id?:string;x:number;y:number;width?:number;height?:number;image?:string;label?:string;camera?:{xAddress:number;yAddress:number;x:number;y:number;modulus:number}}
